import { useState, useEffect } from "react";
import { EVENTS as DEFAULT_STATIC_EVENTS, StepEvent } from "./step-data";

export interface ExtendedStepEvent extends StepEvent {
  imageUrl?: string;
  description?: string;
  reportingTime?: string;
  musterPoint?: string;
  coordinatorPhone?: string;
}

const STORAGE_EVENTS = "steplive_events_db_v2";

export const PRESET_EVENT_IMAGES = [
  {
    label: "Festival Stage Rigging & Lighting",
    url: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&auto=format&fit=crop&q=80",
  },
  {
    label: "Marathon Expo & Stadium",
    url: "https://images.unsplash.com/photo-1530549387789-4c1017266635?w=800&auto=format&fit=crop&q=80",
  },
  {
    label: "Tech Summit & AI Conference Hall",
    url: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&auto=format&fit=crop&q=80",
  },
  {
    label: "Charity Gala & Grand Ballroom",
    url: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=800&auto=format&fit=crop&q=80",
  },
  {
    label: "Beach Arena & Music Festival",
    url: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=800&auto=format&fit=crop&q=80",
  },
  {
    label: "Cultural Heritage Pavilion & Literature Fest",
    url: "https://images.unsplash.com/photo-1524368535928-5b5e00ddc76b?w=800&auto=format&fit=crop&q=80",
  },
  {
    label: "Mobility Expo & Convention Center",
    url: "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?w=800&auto=format&fit=crop&q=80",
  },
];

// Default event seed with rich banner imagery
const SEED_EVENTS: ExtendedStepEvent[] = DEFAULT_STATIC_EVENTS.map((ev, index) => ({
  ...ev,
  imageUrl: PRESET_EVENT_IMAGES[index % PRESET_EVENT_IMAGES.length].url,
  description: `Official volunteer deployment for ${ev.title} in ${ev.location}. Volunteer crews handle operations, check-in desks, safety protocols, and stage logistics.`,
  reportingTime: "45 mins before designated shift",
  musterPoint: `${ev.location} — Volunteer Command Gate`,
  coordinatorPhone: "+91 98101 " + Math.floor(10000 + Math.random() * 90000),
}));

export function getAllEvents(): ExtendedStepEvent[] {
  if (typeof window === "undefined") return SEED_EVENTS;
  try {
    const raw = window.localStorage.getItem(STORAGE_EVENTS);
    if (!raw) {
      window.localStorage.setItem(STORAGE_EVENTS, JSON.stringify(SEED_EVENTS));
      return SEED_EVENTS;
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      window.localStorage.setItem(STORAGE_EVENTS, JSON.stringify(SEED_EVENTS));
      return SEED_EVENTS;
    }
    return parsed;
  } catch {
    return SEED_EVENTS;
  }
}

export function saveAllEvents(events: ExtendedStepEvent[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_EVENTS, JSON.stringify(events));
    window.dispatchEvent(new CustomEvent("steplive:events-change", { detail: events }));
  } catch (err) {
    console.error("Failed to save events:", err);
  }
}

export function getEventById(id: string): ExtendedStepEvent | undefined {
  const events = getAllEvents();
  return events.find((e) => e.id === id);
}

export function createEvent(
  eventData: Omit<ExtendedStepEvent, "id">,
): ExtendedStepEvent {
  const events = getAllEvents();
  const newId = `evt-${Date.now().toString().slice(-4)}`;

  const newEvent: ExtendedStepEvent = {
    ...eventData,
    id: newId,
    imageUrl: eventData.imageUrl || PRESET_EVENT_IMAGES[0].url,
    reportingTime: eventData.reportingTime || "45 mins before deployment",
    musterPoint: eventData.musterPoint || `${eventData.location} — Volunteer Station`,
    coordinatorPhone: eventData.coordinatorPhone || "+91 98765 43210",
  };

  events.unshift(newEvent);
  saveAllEvents(events);
  return newEvent;
}

export function updateEvent(id: string, updates: Partial<ExtendedStepEvent>): ExtendedStepEvent | null {
  const events = getAllEvents();
  const idx = events.findIndex((e) => e.id === id);
  if (idx === -1) return null;

  events[idx] = {
    ...events[idx],
    ...updates,
  };

  saveAllEvents(events);
  return events[idx];
}

export function deleteEvent(id: string): boolean {
  const events = getAllEvents();
  const filtered = events.filter((e) => e.id !== id);
  if (filtered.length !== events.length) {
    saveAllEvents(filtered);
    return true;
  }
  return false;
}

export function useEvents() {
  const [events, setEvents] = useState<ExtendedStepEvent[]>(() => getAllEvents());

  useEffect(() => {
    function handleEventsChange(e: Event) {
      const custom = e as CustomEvent<ExtendedStepEvent[]>;
      setEvents(custom.detail || getAllEvents());
    }

    window.addEventListener("steplive:events-change", handleEventsChange);
    return () => window.removeEventListener("steplive:events-change", handleEventsChange);
  }, []);

  return {
    events,
    refreshEvents: () => setEvents(getAllEvents()),
  };
}
