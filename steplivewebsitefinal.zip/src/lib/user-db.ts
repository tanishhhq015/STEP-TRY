import { useState, useEffect } from "react";
import { VOLUNTEER, getRegionById } from "./step-data";
import { ExtendedStepEvent } from "./events-db";

export interface AppNotification {
  id: string;
  message: string;
  date: string;
  read: boolean;
}

export interface VolunteerExperience {
  years: string;
  pastOrganizations: string;
  highlights: string;
}

export interface BasicDetails {
  dob?: string;
  emergencyContactName: string;
  emergencyContactRelation: string;
  emergencyContactPhone: string;
  tshirtSize: "S" | "M" | "L" | "XL" | "XXL";
  languages: string[];
  medicalNotes?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  password?: string;
  role: "volunteer" | "admin";
  roleTitle: string;
  initials: string;
  regionId: string;
  regionName: string;
  city: string;
  avatarUrl?: string;
  memberSince: string;
  verifiedHours: number;
  eventsCompleted: number;
  basicDetails: BasicDetails;
  experience: VolunteerExperience;
  notifications?: AppNotification[];
}

export type ApplicationStatus = "Pending" | "Approved" | "Declined";

export interface StepApplication {
  applicationId: string;
  userId: string;
  userName?: string;
  userEmail?: string;
  userPhone?: string;
  userCity?: string;
  userExperienceYears?: string;
  userPastOrganizations?: string;
  userHighlights?: string;
  userAvatarUrl?: string;
  eventId: string;
  eventTitle: string;
  eventDate: string;
  eventLocation: string;
  eventRegion: string;
  status: ApplicationStatus;
  appliedAt: string;
  adminNotes?: string;
  reviewedAt?: string;
  reviewedBy?: string;
}

const STORAGE_USERS = "steplive_users_db_v3";
const STORAGE_CURRENT_USER = "steplive_current_user_id";
const STORAGE_APPLICATIONS = "steplive_applications_v3";

// Default volunteer account
export const DEFAULT_USER: UserProfile = {
  id: "usr-001",
  name: VOLUNTEER.name,
  email: VOLUNTEER.email,
  phone: VOLUNTEER.phone,
  password: "password123",
  role: "volunteer",
  roleTitle: "Senior Volunteer",
  initials: VOLUNTEER.initials,
  regionId: VOLUNTEER.regionId,
  regionName: VOLUNTEER.regionName,
  city: VOLUNTEER.city,
  memberSince: "2024",
  verifiedHours: VOLUNTEER.verifiedHours,
  eventsCompleted: VOLUNTEER.eventsCompleted,
  basicDetails: {
    dob: "1999-08-14",
    emergencyContactName: "Rakesh Kalra",
    emergencyContactRelation: "Father",
    emergencyContactPhone: "9811099881",
    tshirtSize: "L",
    languages: ["English", "Hindi", "Punjabi"],
    medicalNotes: "No allergies",
  },
  experience: {
    years: "3+ Years",
    pastOrganizations: "Delhi Half Marathon, Sunburn Arena, Rotary Youth Wing",
    highlights: "Led a 24-volunteer stage setup team at Jawaharlal Nehru Stadium with zero safety infractions.",
  },
  notifications: [],
};

// Default secure Admin account
export const ADMIN_USER: UserProfile = {
  id: "usr-admin",
  name: "Operations Admin",
  email: "admin@steplive.org",
  phone: "9810011000",
  password: "admin2026",
  role: "admin",
  roleTitle: "Chief Operations Officer",
  initials: "AD",
  regionId: "delhi-ncr",
  regionName: "National Operations HQ",
  city: "New Delhi",
  memberSince: "2023",
  verifiedHours: 350,
  eventsCompleted: 45,
  basicDetails: {
    dob: "1988-03-21",
    emergencyContactName: "Command Control Desk",
    emergencyContactRelation: "Operations Hub",
    emergencyContactPhone: "011-23344556",
    tshirtSize: "XL",
    languages: ["English", "Hindi"],
  },
  experience: {
    years: "8+ Years",
    pastOrganizations: "National Games, Formula E Hyderabad, Sunburn Festival",
    highlights: "Designed safety SOPs deployed across 45 national festivals and expos.",
  },
  notifications: [],
};

export function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) {
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }
  return (name.slice(0, 2) || "VO").toUpperCase();
}

export function getAllUsers(): UserProfile[] {
  if (typeof window === "undefined") return [DEFAULT_USER, ADMIN_USER];
  try {
    const raw = window.localStorage.getItem(STORAGE_USERS);
    if (!raw) {
      const initial = [DEFAULT_USER, ADMIN_USER];
      window.localStorage.setItem(STORAGE_USERS, JSON.stringify(initial));
      return initial;
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      const initial = [DEFAULT_USER, ADMIN_USER];
      window.localStorage.setItem(STORAGE_USERS, JSON.stringify(initial));
      return initial;
    }
    // Ensure admin user exists
    if (!parsed.some((u: UserProfile) => u.email.toLowerCase() === "admin@steplive.org")) {
      parsed.push(ADMIN_USER);
      window.localStorage.setItem(STORAGE_USERS, JSON.stringify(parsed));
    }
    return parsed;
  } catch {
    return [DEFAULT_USER, ADMIN_USER];
  }
}

export function saveAllUsers(users: UserProfile[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_USERS, JSON.stringify(users));
  } catch (err) {
    console.error("Failed to save users:", err);
  }
}

export function getCurrentUser(): UserProfile {
  if (typeof window === "undefined") return DEFAULT_USER;
  const users = getAllUsers();
  const currentId = window.localStorage.getItem(STORAGE_CURRENT_USER);
  if (!currentId) {
    return users[0] || DEFAULT_USER;
  }
  const found = users.find((u) => u.id === currentId || u.email.toLowerCase() === currentId.toLowerCase());
  return found || users[0] || DEFAULT_USER;
}

export function setCurrentUser(user: UserProfile) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(STORAGE_CURRENT_USER, user.id);
  window.dispatchEvent(new CustomEvent("steplive:auth-change", { detail: user }));
}

export function registerVolunteerUser(params: {
  name: string;
  email: string;
  phone: string;
  password?: string;
  regionId: string;
  city?: string;
  basicDetails?: Partial<BasicDetails>;
  experience?: Partial<VolunteerExperience>;
}): UserProfile {
  const users = getAllUsers();
  const existing = users.find((u) => u.email.toLowerCase() === params.email.toLowerCase());
  if (existing) {
    existing.name = params.name;
    existing.phone = params.phone;
    if (params.password) existing.password = params.password;
    if (params.regionId) {
      existing.regionId = params.regionId;
      existing.regionName = getRegionById(params.regionId)?.name || params.regionId;
    }
    if (params.city) existing.city = params.city;
    if (params.basicDetails) {
      existing.basicDetails = { ...existing.basicDetails, ...params.basicDetails };
    }
    if (params.experience) {
      existing.experience = { ...existing.experience, ...params.experience };
    }
    saveAllUsers(users);
    setCurrentUser(existing);
    return existing;
  }

  const regionObj = getRegionById(params.regionId);
  const newUser: UserProfile = {
    id: `usr-${Date.now()}`,
    name: params.name,
    email: params.email,
    phone: params.phone,
    password: params.password || "pass123",
    role: "volunteer",
    roleTitle: "Volunteer Trainee",
    initials: getInitials(params.name),
    regionId: params.regionId || "delhi-ncr",
    regionName: regionObj?.name || "Delhi NCR",
    city: params.city || regionObj?.name || "Delhi NCR",
    memberSince: "2026",
    verifiedHours: 0,
    eventsCompleted: 0,
    basicDetails: {
      dob: params.basicDetails?.dob || "2000-01-01",
      emergencyContactName: params.basicDetails?.emergencyContactName || "Parent / Guardian",
      emergencyContactRelation: params.basicDetails?.emergencyContactRelation || "Family",
      emergencyContactPhone: params.basicDetails?.emergencyContactPhone || params.phone,
      tshirtSize: params.basicDetails?.tshirtSize || "M",
      languages: params.basicDetails?.languages || ["English", "Hindi"],
      medicalNotes: params.basicDetails?.medicalNotes || "",
    },
    experience: {
      years: params.experience?.years || "Fresh Volunteer (0-1 yr)",
      pastOrganizations: params.experience?.pastOrganizations || "Local College / Community Drives",
      highlights: params.experience?.highlights || "Active participant in community events.",
    },
    notifications: [],
  };

  users.push(newUser);
  saveAllUsers(users);
  setCurrentUser(newUser);
  return newUser;
}

export function updateUserProfile(userId: string, updates: Partial<UserProfile>): UserProfile | null {
  const users = getAllUsers();
  const idx = users.findIndex((u) => u.id === userId);
  if (idx === -1) return null;

  users[idx] = {
    ...users[idx],
    ...updates,
    initials: updates.name ? getInitials(updates.name) : users[idx].initials,
    basicDetails: {
      ...users[idx].basicDetails,
      ...(updates.basicDetails || {}),
    },
    experience: {
      ...users[idx].experience,
      ...(updates.experience || {}),
    },
  };

  saveAllUsers(users);
  const current = getCurrentUser();
  if (current.id === userId) {
    setCurrentUser(users[idx]);
  }

  // Synchronize avatarUrl and userName in existing applications
  if (updates.avatarUrl !== undefined || updates.name !== undefined) {
    const apps = getAllApplications();
    let changed = false;
    apps.forEach((a) => {
      if (a.userId === userId) {
        if (updates.avatarUrl !== undefined) {
          a.userAvatarUrl = updates.avatarUrl || undefined;
          changed = true;
        }
        if (updates.name !== undefined) {
          a.userName = updates.name;
        }
      }
    });
    if (changed) {
      saveAllApplications(apps);
    }
  }

  return users[idx];
}

export function logoutUser() {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(STORAGE_CURRENT_USER);
  window.dispatchEvent(new CustomEvent("steplive:auth-change", { detail: null }));
}

// ─── EVENT APPLICATION DATABASE ──────────────────────────────────────────────

export function getAllApplications(): StepApplication[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_APPLICATIONS);
    if (!raw) {
      const initial: StepApplication[] = [
        {
          applicationId: "APP-2026-084",
          userId: "usr-001",
          userName: "Tanishq Kalra",
          userEmail: "tanishq@steplive.org",
          userPhone: "8796049860",
          userCity: "New Delhi",
          userExperienceYears: "3+ Years",
          userPastOrganizations: "Delhi Half Marathon, Sunburn Arena, Rotary Youth Wing",
          userHighlights: "Led a 24-volunteer stage setup team at Jawaharlal Nehru Stadium with zero safety infractions.",
          eventId: "evt-001",
          eventTitle: "Summer Music Festival 2026",
          eventDate: "Sep 12–14, 2026",
          eventLocation: "JLN Stadium Grounds, New Delhi",
          eventRegion: "delhi-ncr",
          status: "Approved",
          appliedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
          adminNotes: "Approved by National Operations Command.",
          reviewedAt: new Date(Date.now() - 86400000).toISOString(),
          reviewedBy: "Operations Admin",
        },
      ];
      window.localStorage.setItem(STORAGE_APPLICATIONS, JSON.stringify(initial));
      return initial;
    }
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveAllApplications(apps: StepApplication[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_APPLICATIONS, JSON.stringify(apps));
    window.dispatchEvent(new CustomEvent("steplive:applications-change", { detail: apps }));
  } catch (err) {
    console.error("Failed to save applications:", err);
  }
}

export function getUserApplications(userId: string): StepApplication[] {
  const all = getAllApplications();
  return all.filter((a) => a.userId === userId);
}

export function submitApplication(
  user: UserProfile,
  event: ExtendedStepEvent
): StepApplication {
  const apps = getAllApplications();
  const applicationId = `APP-${new Date().getFullYear()}-${String(Math.floor(100 + Math.random() * 900))}`;

  const entry: StepApplication = {
    applicationId,
    userId: user.id,
    userName: user.name,
    userEmail: user.email,
    userPhone: user.phone,
    userCity: user.city,
    userAvatarUrl: user.avatarUrl,
    userExperienceYears: user.experience?.years || "1+ Year",
    userPastOrganizations: user.experience?.pastOrganizations || "",
    userHighlights: user.experience?.highlights || "",
    eventId: event.id,
    eventTitle: event.title,
    eventDate: event.date,
    eventLocation: event.location,
    eventRegion: event.region,
    status: "Pending",
    appliedAt: new Date().toISOString(),
  };

  apps.unshift(entry);
  saveAllApplications(apps);
  return entry;
}

export function withdrawApplication(applicationId: string): boolean {
  const apps = getAllApplications();
  const filtered = apps.filter((a) => a.applicationId !== applicationId);
  if (filtered.length !== apps.length) {
    saveAllApplications(filtered);
    return true;
  }
  return false;
}

// ─── ADMIN APPROVAL & DISAPPROVAL FUNCTIONS ─────────────────────────────

function addNotificationToUser(userId: string, message: string) {
  const users = getAllUsers();
  const idx = users.findIndex(u => u.id === userId);
  if (idx !== -1) {
    if (!users[idx].notifications) {
      users[idx].notifications = [];
    }
    users[idx].notifications!.unshift({
      id: `notif-${Date.now()}`,
      message,
      date: new Date().toISOString(),
      read: false
    });
    saveAllUsers(users);
    
    // Dispatch auth change so the UI updates
    const current = getCurrentUser();
    if (current.id === userId) {
      setCurrentUser(users[idx]);
    }
  }
}

export function markNotificationsAsRead(userId: string) {
  const users = getAllUsers();
  const idx = users.findIndex(u => u.id === userId);
  if (idx !== -1 && users[idx].notifications) {
    users[idx].notifications!.forEach(n => n.read = true);
    saveAllUsers(users);
    const current = getCurrentUser();
    if (current.id === userId) {
      setCurrentUser(users[idx]);
    }
  }
}

export function approveApplication(applicationId: string, notes?: string): StepApplication | null {
  const apps = getAllApplications();
  const item = apps.find((a) => a.applicationId === applicationId);
  if (!item) return null;

  item.status = "Approved";
  item.adminNotes = notes || "Application approved by Admin.";
  item.reviewedAt = new Date().toISOString();
  item.reviewedBy = "Operations Admin";

  saveAllApplications(apps);
  addNotificationToUser(item.userId, `You have been selected for ${item.eventTitle}. Please check the event details.`);
  return item;
}

export function declineApplication(applicationId: string, notes?: string): StepApplication | null {
  const apps = getAllApplications();
  const item = apps.find((a) => a.applicationId === applicationId);
  if (!item) return null;

  item.status = "Declined";
  item.adminNotes = notes || "Application declined by Admin.";
  item.reviewedAt = new Date().toISOString();
  item.reviewedBy = "Operations Admin";

  saveAllApplications(apps);
  addNotificationToUser(item.userId, `Your application for ${item.eventTitle} was declined${notes ? `: ${notes}` : ""}.`);
  return item;
}

export function resetApplication(applicationId: string): StepApplication | null {
  const apps = getAllApplications();
  const item = apps.find((a) => a.applicationId === applicationId);
  if (!item) return null;

  item.status = "Pending";
  item.adminNotes = undefined;
  item.reviewedAt = undefined;
  item.reviewedBy = undefined;

  saveAllApplications(apps);
  return item;
}

// ─── REACT HOOKS ────────────────────────────────────────────────────────

export function useCurrentUser() {
  const [user, setUser] = useState<UserProfile>(() => getCurrentUser());

  useEffect(() => {
    function handleAuthChange(e: Event) {
      const custom = e as CustomEvent<UserProfile | null>;
      setUser(custom.detail || getCurrentUser());
    }

    window.addEventListener("steplive:auth-change", handleAuthChange);
    return () => window.removeEventListener("steplive:auth-change", handleAuthChange);
  }, []);

  return {
    user,
    setCurrentUser,
    refreshUser: () => setUser(getCurrentUser()),
    isAdmin: user?.role === "admin",
  };
}

export function useUserApplications(userId: string) {
  const [apps, setApps] = useState<StepApplication[]>(() => getUserApplications(userId));

  useEffect(() => {
    setApps(getUserApplications(userId));

    function handleAppChange() {
      setApps(getUserApplications(userId));
    }

    window.addEventListener("steplive:applications-change", handleAppChange);
    return () => window.removeEventListener("steplive:applications-change", handleAppChange);
  }, [userId]);

  return {
    applications: apps,
    refresh: () => setApps(getUserApplications(userId)),
  };
}

export function useAllApplications() {
  const [apps, setApps] = useState<StepApplication[]>(() => getAllApplications());

  useEffect(() => {
    function handleAppChange() {
      setApps(getAllApplications());
    }

    window.addEventListener("steplive:applications-change", handleAppChange);
    return () => window.removeEventListener("steplive:applications-change", handleAppChange);
  }, []);

  return {
    applications: apps,
    refresh: () => setApps(getAllApplications()),
  };
}
