// STEP LIVE — data layer (mirrors the StepApp localStorage store)
export type EventStatus = "Approved" | "Pending" | "Completed";

export interface RegionOption {
  id: string;
  name: string;
  state: string;
  hubName: string;
  isPopular?: boolean;
}

export const REGIONS: RegionOption[] = [
  { id: "all", name: "All India", state: "Pan-India Grid", hubName: "National Operations", isPopular: false },
  { id: "delhi-ncr", name: "Delhi NCR", state: "Delhi / Gurgaon / Noida", hubName: "North Zone Operations", isPopular: true },
  { id: "mumbai", name: "Mumbai", state: "Maharashtra", hubName: "Western Seaboard Hub", isPopular: true },
  { id: "kolkata", name: "Kolkata", state: "West Bengal", hubName: "Eastern Cultural Circle", isPopular: true },
  { id: "bengaluru", name: "Bengaluru", state: "Karnataka", hubName: "Tech Capital Grid", isPopular: true },
  { id: "hyderabad", name: "Hyderabad", state: "Telangana", hubName: "Deccan Operations Hub", isPopular: true },
  { id: "chandigarh", name: "Chandigarh", state: "Punjab / Haryana", hubName: "Tricity Metro Base", isPopular: true },
  { id: "chennai", name: "Chennai", state: "Tamil Nadu", hubName: "Southern Coastal Wing", isPopular: true },
  { id: "pune", name: "Pune", state: "Maharashtra", hubName: "Deccan Plateau Unit", isPopular: true },
  { id: "jaipur", name: "Jaipur", state: "Rajasthan", hubName: "Heritage Operations Wing", isPopular: true },
  { id: "goa", name: "Goa", state: "Goa", hubName: "Coastal Events Squad", isPopular: true },
  { id: "ahmedabad", name: "Ahmedabad", state: "Gujarat", hubName: "Gujarat Region Base", isPopular: true },
  { id: "kochi", name: "Kochi", state: "Kerala", hubName: "Malabar Hub", isPopular: true },
  { id: "lucknow", name: "Lucknow", state: "Uttar Pradesh", hubName: "Awadh Central Wing", isPopular: false },
  { id: "indore", name: "Indore", state: "Madhya Pradesh", hubName: "Central India Operations", isPopular: false },
  { id: "bhopal", name: "Bhopal", state: "Madhya Pradesh", hubName: "Central Operations", isPopular: false },
  { id: "surat", name: "Surat", state: "Gujarat", hubName: "Western Hub", isPopular: false },
  { id: "patna", name: "Patna", state: "Bihar", hubName: "Eastern Zone", isPopular: false },
  { id: "varanasi", name: "Varanasi", state: "Uttar Pradesh", hubName: "Purvanchal Base", isPopular: false },
  { id: "nagpur", name: "Nagpur", state: "Maharashtra", hubName: "Vidarbha Center", isPopular: false },
  { id: "visakhapatnam", name: "Visakhapatnam", state: "Andhra Pradesh", hubName: "Bay Coast Operations", isPopular: false },
  { id: "coimbatore", name: "Coimbatore", state: "Tamil Nadu", hubName: "Kongu Region Hub", isPopular: false },
];

export interface StepEvent {
  id: string;
  title: string;
  date: string;
  location: string;
  region: string;
  role: string;
  category: string;
  status: EventStatus;
  capacity: number;
  eventLead: string;
  coverImage?: string;
  tags: string[];
}

export const EVENTS: StepEvent[] = [
  {
    id: "evt-001",
    title: "Summer Music Festival 2026",
    date: "Sep 12–14, 2026",
    location: "JLN Stadium Grounds, New Delhi",
    region: "delhi-ncr",
    role: "Stage Crew Lead",
    category: "Festival",
    status: "Approved",
    capacity: 24,
    eventLead: "R. Sharma",
    tags: ["Outdoor", "Multi-day", "Night Shift"],
  },
  {
    id: "evt-002",
    title: "City Marathon Expo 2026",
    date: "Sep 20, 2026",
    location: "Bandra-Kurla Complex (BKC), Mumbai",
    region: "mumbai",
    role: "Registration Desk",
    category: "Sports",
    status: "Approved",
    capacity: 12,
    eventLead: "M. Fernandes",
    tags: ["Indoor", "Morning Shift"],
  },
  {
    id: "evt-003",
    title: "Charity Gala Dinner",
    date: "Oct 03, 2026",
    location: "The Leela Palace, Bengaluru",
    region: "bengaluru",
    role: "Guest Relations",
    category: "Fundraiser",
    status: "Pending",
    capacity: 18,
    eventLead: "A. Kapoor",
    tags: ["Formal", "Evening Shift"],
  },
  {
    id: "evt-004",
    title: "Tech Summit: Future of AI",
    date: "Oct 18–19, 2026",
    location: "HICC Novotel, Hitec City, Hyderabad",
    region: "hyderabad",
    role: "AV Support",
    category: "Conference",
    status: "Pending",
    capacity: 30,
    eventLead: "J. Mathew",
    tags: ["Indoor", "Technical"],
  },
  {
    id: "evt-005",
    title: "Street Food & Cultural Carnival",
    date: "Aug 09, 2026",
    location: "Sunder Nursery Heritage Grounds, Delhi",
    region: "delhi-ncr",
    role: "Crowd Management",
    category: "Festival",
    status: "Completed",
    capacity: 20,
    eventLead: "P. Nair",
    tags: ["Outdoor", "Day Shift"],
  },
  {
    id: "evt-006",
    title: "Sunburn Beach Stage Ops",
    date: "Dec 28–30, 2026",
    location: "Vagator Beach Arena, Goa",
    region: "goa",
    role: "Stage Operations",
    category: "Festival",
    status: "Approved",
    capacity: 36,
    eventLead: "D. D'Souza",
    tags: ["Beachfront", "Production", "Multi-day"],
  },
  {
    id: "evt-007",
    title: "Heritage Literature Festival",
    date: "Jan 22–26, 2027",
    location: "Diggi Palace, Jaipur",
    region: "jaipur",
    role: "Author Liaison & Front-of-House",
    category: "Cultural",
    status: "Pending",
    capacity: 22,
    eventLead: "V. Rathore",
    tags: ["Heritage", "Speaker Escort"],
  },
  {
    id: "evt-008",
    title: "Auto Expo & Clean Mobility Summit",
    date: "Feb 05–08, 2027",
    location: "India Expo Mart, Greater Noida (Delhi NCR)",
    region: "delhi-ncr",
    role: "VIP Delegate Logistics",
    category: "Conference",
    status: "Approved",
    capacity: 28,
    eventLead: "K. Singhania",
    tags: ["Electric Vehicles", "VIP Protocol"],
  },
  {
    id: "evt-009",
    title: "International Kite Festival Ops",
    date: "Jan 12–14, 2027",
    location: "Sabarmati Riverfront, Ahmedabad",
    region: "ahmedabad",
    role: "Crowd & Safety Logistics",
    category: "Festival",
    status: "Completed",
    capacity: 16,
    eventLead: "H. Patel",
    tags: ["Riverfront", "Day Shift"],
  },
  {
    id: "evt-010",
    title: "Kolkata Film & Arts Conclave",
    date: "Nov 14–17, 2026",
    location: "Nandan Cultural Complex, Kolkata",
    region: "kolkata",
    role: "Screening Coordinator",
    category: "Cultural",
    status: "Approved",
    capacity: 14,
    eventLead: "T. Banerjee",
    tags: ["Cinema", "Evening Shift"],
  },
];


export interface SopSection {
  title: string;
  icon: string;
  points: string[];
}

export const SOPS: SopSection[] = [
  {
    title: "Dress Code",
    icon: "checkroom",
    points: [
      "Formal Events: Formal white/black shirt, formal trousers, formal shoes and blazer where specified.",
      "Cashless Events: White shirt, blue/black jeans and closed footwear, unless otherwise instructed.",
      "Always report in clean, ironed and presentable attire.",
    ],
  },
  {
    title: "Strict Timings",
    icon: "schedule",
    points: [
      "Reporting time is mandatory and non-negotiable.",
      "Late reporting, early departure or unauthorised absence may lead to payment deductions.",
    ],
  },
  {
    title: "Follow Your POC",
    icon: "support_agent",
    points: [
      "Your assigned STEP POC is your primary point of contact.",
      "Communicate all event-related queries/issues through your POC and follow their instructions.",
      "Stay reachable throughout your duty.",
    ],
  },
  {
    title: "Professional Conduct",
    icon: "verified_user",
    points: [
      "Maintain respectful and professional behaviour with clients, guests, vendors and fellow volunteers.",
      "Fighting, abusive behaviour, harassment, misbehaviour or indiscipline will not be tolerated.",
    ],
  },
  {
    title: "Stay at Your Duty Area",
    icon: "pin_drop",
    points: [
      "Do not leave your assigned position without informing your POC.",
      "Take breaks only when permitted.",
      "Do not enter restricted/VIP/backstage areas without authorisation.",
    ],
  },
  {
    title: "Cashless Events",
    icon: "credit_card",
    points: [
      "Handle cashless devices, cards, tokens, inventory and transactions responsibly.",
      "Any shortage or loss attributable to your duty must be settled on the spot, as per event policy.",
      "Fraud, theft, manipulation or unauthorised transactions may result in immediate removal and payment deduction.",
    ],
  },
  {
    title: "Zero Tolerance for Illegal Activities",
    icon: "gavel",
    points: [
      "Theft, fraud, violence, harassment, substance use or any illegal activity during an event is strictly prohibited.",
      "Such actions may lead to immediate removal, payment deduction and further legal action where applicable.",
    ],
  },
  {
    title: "Attendance & Check-in",
    icon: "fact_check",
    points: [
      "Complete your check-in/check-out as instructed.",
      "Never mark attendance for another volunteer.",
      "Report any attendance issue to your POC immediately.",
    ],
  },
  {
    title: "Take Care of Equipment",
    icon: "inventory_2",
    points: [
      "Handle all STEP/client equipment and materials responsibly.",
      "Loss or damage due to negligence may be recoverable as per event policy.",
    ],
  },
  {
    title: "Social Media & Confidentiality",
    icon: "lock",
    points: [
      "Do not share confidential event, client, guest or backstage information without permission.",
      "Follow all event-specific SOPs and instructions given during briefing.",
    ],
  },
];

export interface RuleSection {
  title: string;
  icon: string;
  points?: string[];
  intro?: string;
  subPoints?: string[];
}

export const RULES_AND_REGULATIONS: RuleSection[] = [
  {
    title: "Eligibility",
    icon: "verified_user",
    points: [
      "The Website shall be used only by persons who are legally competent to enter into binding arrangements under applicable law.",
      "Certain events, programs, or opportunities may be subject to specific eligibility requirements, including age, educational, geographical, or other criteria. Such requirements shall be complied with by the concerned user.",
    ],
  },
  {
    title: "Registration and Information",
    icon: "app_registration",
    points: [
      "Any information submitted through the Website shall be true, accurate, complete, and not misleading.",
      "STEP Events Live reserves the right to verify information submitted by a user where reasonably necessary for registration, eligibility, event administration, safety, prevention of fraud, or compliance with applicable law.",
      "Submission of an application or registration shall not by itself constitute confirmation of participation, selection, or appointment. Participation or selection shall be subject to confirmation by STEP Events Live.",
      "STEP Events Live may reject, suspend, or cancel an application or registration where the information provided is materially false, misleading, or incomplete; where eligibility requirements are not satisfied; or where such action is reasonably necessary for safety, security, operational, or legal reasons.",
    ],
  },
  {
    title: "Privacy and Personal Data",
    icon: "privacy_tip",
    points: [
      "STEP Events Live may collect and process personal information provided by users for purposes connected with registration, event administration, volunteer or participant management, communication, verification, safety, security, and other purposes disclosed to the user.",
    ],
  },
  {
    title: "Safety and Compliance",
    icon: "security",
    points: [
      "Every participant, volunteer, and other person associated with an event shall comply with all reasonable safety instructions issued by STEP Events Live, the venue, authorised personnel, security personnel, and relevant authorities.",
      "No person shall undertake any act which may endanger themselves, another person, property, or the safe and orderly conduct of an event.",
      "STEP Events Live may restrict or terminate the participation of any person whose conduct creates a reasonable safety, security, or legal risk.",
    ],
  },
  {
    title: "Suspension and Termination",
    icon: "gavel",
    intro: "STEP Events Live may suspend or terminate a person’s access to the Website or participation in an event where the person:",
    subPoints: [
      "a. materially breaches these Terms;",
      "b. provides materially false or fraudulent information;",
      "c. engages in unlawful conduct;",
      "d. violates event rules or safety requirements;",
      "e. threatens the safety or security of another person or the event; or",
      "f. otherwise engages in conduct warranting such action under applicable law.",
    ],
  },
];

export const VOLUNTEER = {
  name: "Tanishq Kalra",
  initials: "TK",
  roleTitle: "Senior Volunteer",
  email: "tanishq@steplive.org",
  phone: "8796049860",
  regionId: "delhi-ncr",
  regionName: "Delhi NCR",
  city: "New Delhi",
  memberSince: "2024",
  verifiedHours: 48,
  eventsCompleted: 12,
};

// LocalStorage helpers for user applications and region preference
const KEY_APPS = "stepapp.applications";
const KEY_REGION = "stepapp.region";

export function getActiveRegionId(): string {
  if (typeof window === "undefined") return "delhi-ncr";
  try {
    return window.localStorage.getItem(KEY_REGION) || "delhi-ncr";
  } catch {
    return "delhi-ncr";
  }
}

export function setActiveRegionId(regionId: string) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(KEY_REGION, regionId);
    window.dispatchEvent(new CustomEvent("stepapp:region-change", { detail: regionId }));
  } catch {
    // Ignore write errors
  }
}

export function getRegionById(id: string): RegionOption {
  return (
    REGIONS.find((r) => r.id === id) ||
    REGIONS.find((r) => r.id === "delhi-ncr") ||
    REGIONS[1]
  );
}

export function loadApplications(): Array<Record<string, string>> {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(window.localStorage.getItem(KEY_APPS) || "[]");
  } catch {
    return [];
  }
}

export function saveApplication(app: Record<string, string>) {
  const all = loadApplications();
  all.push({ ...app, submittedAt: new Date().toISOString() });
  try {
    window.localStorage.setItem(KEY_APPS, JSON.stringify(all));
  } catch {
    // Ignore write errors
  }
}
