export type BadgeTier = "Bronze" | "Silver" | "Gold" | "Platinum" | "Diamond";

export interface TierDefinition {
  tier: BadgeTier;
  name: string;
  minEvents: number;
  maxEvents: number;
  color: string;
  accentColor: string;
  borderColor: string;
  icon: string;
  tagline: string;
  description: string;
  perks: string[];
}

export const TIER_DEFINITIONS: Record<BadgeTier, TierDefinition> = {
  Bronze: {
    tier: "Bronze",
    name: "Bronze",
    minEvents: 10,
    maxEvents: 19,
    color: "#d97706",
    accentColor: "#f59e0b",
    borderColor: "rgba(217, 119, 6, 0.4)",
    icon: "military_tech",
    tagline: "10+ Events",
    description: "Foundational recognized volunteer tier with verified contributions and event stipends.",
    perks: [
      "Certificate",
      "Stipend Increment",
      "Special Event Opportunities",
    ],
  },
  Silver: {
    tier: "Silver",
    name: "Silver",
    minEvents: 20,
    maxEvents: 29,
    color: "#94a3b8",
    accentColor: "#e2e8f0",
    borderColor: "rgba(148, 163, 184, 0.4)",
    icon: "workspace_premium",
    tagline: "20+ Events",
    description: "Advanced volunteer tier with elevated event access, priority rosters, and spotlight features.",
    perks: [
      "Higher Stipend",
      "Premium Event Priority",
      "STEP Spotlight",
    ],
  },
  Gold: {
    tier: "Gold",
    name: "Gold",
    minEvents: 30,
    maxEvents: 39,
    color: "#d4af37",
    accentColor: "#fbbf24",
    borderColor: "rgba(212, 175, 55, 0.5)",
    icon: "stars",
    tagline: "30+ Events",
    description: "Leadership volunteer tier coordinating major deployments and participating directly in event planning.",
    perks: [
      "Premium Stipend",
      "Operations Lead Role",
      "Event Planning Exposure",
    ],
  },
  Platinum: {
    tier: "Platinum",
    name: "Platinum",
    minEvents: 40,
    maxEvents: 49,
    color: "#38bdf8",
    accentColor: "#7dd3fc",
    borderColor: "rgba(56, 189, 248, 0.45)",
    icon: "diamond",
    tagline: "40+ Events",
    description: "Core leadership member leading major deployments with exclusive merchandise and career opportunities.",
    perks: [
      "Higher Stipend",
      "Deployment Lead Role",
      "STEP Core Member",
      "Long-Term Role Priority",
      "STEP Merch",
    ],
  },
  Diamond: {
    tier: "Diamond",
    name: "Diamond",
    minEvents: 50,
    maxEvents: 999,
    color: "#c084fc",
    accentColor: "#e879f9",
    borderColor: "rgba(192, 132, 252, 0.5)",
    icon: "award_star",
    tagline: "50+ Events",
    description: "Elite executive tier leading major event operations with direct access to senior leadership.",
    perks: [
      "Highest Stipend Tier",
      "Full Operations Command",
      "Senior Management Access",
      "Lead Major Event Operations",
    ],
  },
};

export const ALL_TIERS: TierDefinition[] = [
  TIER_DEFINITIONS.Bronze,
  TIER_DEFINITIONS.Silver,
  TIER_DEFINITIONS.Gold,
  TIER_DEFINITIONS.Platinum,
  TIER_DEFINITIONS.Diamond,
];

export interface VolunteerBadgeProgress {
  eventsCompleted: number;
  currentTier: BadgeTier;
  currentTierDef: TierDefinition;
  nextTier: BadgeTier | null;
  nextTierDef: TierDefinition | null;
  eventsToNextTier: number;
  tierProgressPercent: number;
  overallProgressPercent: number;
  isMaxTier: boolean;
  allTiers: TierDefinition[];
}

export function getVolunteerBadgeProgress(eventsCompleted: number): VolunteerBadgeProgress {
  const count = Math.max(0, eventsCompleted);
  let currentTier: BadgeTier = "Bronze";
  let nextTier: BadgeTier | null = null;
  let eventsToNextTier = 0;
  let tierProgressPercent = 0;

  if (count < 10) {
    currentTier = "Bronze";
    nextTier = "Bronze";
    eventsToNextTier = 10 - count;
    tierProgressPercent = Math.min(100, Math.round((count / 10) * 100));
  } else if (count < 20) {
    currentTier = "Bronze";
    nextTier = "Silver";
    eventsToNextTier = 20 - count;
    tierProgressPercent = Math.min(100, Math.round(((count - 10) / 10) * 100));
  } else if (count < 30) {
    currentTier = "Silver";
    nextTier = "Gold";
    eventsToNextTier = 30 - count;
    tierProgressPercent = Math.min(100, Math.round(((count - 20) / 10) * 100));
  } else if (count < 40) {
    currentTier = "Gold";
    nextTier = "Platinum";
    eventsToNextTier = 40 - count;
    tierProgressPercent = Math.min(100, Math.round(((count - 30) / 10) * 100));
  } else if (count < 50) {
    currentTier = "Platinum";
    nextTier = "Diamond";
    eventsToNextTier = 50 - count;
    tierProgressPercent = Math.min(100, Math.round(((count - 40) / 10) * 100));
  } else {
    currentTier = "Diamond";
    nextTier = null;
    eventsToNextTier = 0;
    tierProgressPercent = 100;
  }

  const currentTierDef = TIER_DEFINITIONS[currentTier];
  const nextTierDef = nextTier ? TIER_DEFINITIONS[nextTier] : null;
  const overallProgressPercent = Math.min(100, Math.round((count / 50) * 100));

  return {
    eventsCompleted: count,
    currentTier,
    currentTierDef,
    nextTier,
    nextTierDef,
    eventsToNextTier,
    tierProgressPercent,
    overallProgressPercent,
    isMaxTier: count >= 50,
    allTiers: ALL_TIERS,
  };
}
