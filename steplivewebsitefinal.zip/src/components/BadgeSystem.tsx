import { useState } from "react";
import { Icon } from "@/components/step";
import {
  getVolunteerBadgeProgress,
  TIER_DEFINITIONS,
  type BadgeTier,
} from "@/lib/badge-system";

interface BadgeEmblemProps {
  tier?: BadgeTier;
  size?: number | string;
  className?: string;
}

/* ─────────────────────────────────────────────────────────────
   CUSTOM VECTOR BADGE EMBLEMS (Bronze, Silver, Gold, Platinum, Diamond)
   ───────────────────────────────────────────────────────────── */

export function BronzeBadgeLogo({ size = 44, className = "" }: { size?: number | string; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`badge-vector-logo badge-logo-bronze ${className}`}
      aria-label="Bronze Tier Badge Emblem"
    >
      <defs>
        <linearGradient id="brz-shield-grad" x1="15" y1="10" x2="85" y2="90" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#d97706" />
          <stop offset="45%" stopColor="#9a3412" />
          <stop offset="85%" stopColor="#451a03" />
          <stop offset="100%" stopColor="#78350f" />
        </linearGradient>
        <linearGradient id="brz-rim-grad" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#fbbf24" />
          <stop offset="35%" stopColor="#d97706" />
          <stop offset="70%" stopColor="#78350f" />
          <stop offset="100%" stopColor="#f59e0b" />
        </linearGradient>
        <linearGradient id="brz-star-grad" x1="50" y1="30" x2="50" y2="65" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#fef3c7" />
          <stop offset="40%" stopColor="#f59e0b" />
          <stop offset="100%" stopColor="#b45309" />
        </linearGradient>
        <filter id="brz-shadow" x="-10%" y="-10%" width="125%" height="125%">
          <feDropShadow dx="0" dy="3" stdDeviation="2.5" floodColor="#451a03" floodOpacity="0.45" />
        </filter>
      </defs>

      {/* Outer Glow & Laurel Base */}
      <circle cx="50" cy="50" r="46" fill="#78350f" fillOpacity="0.15" />

      {/* Bronze Shield Body */}
      <path
        d="M50 12 C68 12, 82 17, 84 32 C84 60, 68 78, 50 88 C32 78, 16 60, 16 32 C18 17, 32 12, 50 12 Z"
        fill="url(#brz-shield-grad)"
        stroke="url(#brz-rim-grad)"
        strokeWidth="3.5"
        strokeLinejoin="round"
        filter="url(#brz-shadow)"
      />

      {/* Inner Inset Rim */}
      <path
        d="M50 20 C64 20, 75 24, 76 35 C76 57, 63 71, 50 79 C37 71, 24 57, 24 35 C25 24, 36 20, 50 20 Z"
        fill="none"
        stroke="#fbbf24"
        strokeWidth="1.2"
        strokeOpacity="0.5"
      />

      {/* Laurel Garland Leaves on Sides */}
      <path d="M28 42 Q23 37 26 31 Q30 36 30 42" fill="#f59e0b" fillOpacity="0.75" />
      <path d="M27 54 Q21 50 23 44 Q28 48 29 54" fill="#f59e0b" fillOpacity="0.75" />
      <path d="M72 42 Q77 37 74 31 Q70 36 70 42" fill="#f59e0b" fillOpacity="0.75" />
      <path d="M73 54 Q79 50 77 44 Q72 48 71 54" fill="#f59e0b" fillOpacity="0.75" />

      {/* Triple Chevron Bars */}
      <path d="M38 65 L50 73 L62 65" stroke="#f59e0b" strokeWidth="2.2" strokeLinecap="round" fill="none" />
      <path d="M41 59 L50 65 L59 59" stroke="#fbbf24" strokeWidth="1.8" strokeLinecap="round" fill="none" />

      {/* Central Bronze Crest Star */}
      <polygon
        points="50,28 54.5,39 66,40.5 57.5,48.5 60,60 50,54 40,60 42.5,48.5 34,40.5 45.5,39"
        fill="url(#brz-star-grad)"
        stroke="#451a03"
        strokeWidth="1"
        strokeLinejoin="round"
      />

      {/* Bronze Ribbon Banner at bottom */}
      <path d="M30 84 L50 89 L70 84 L64 94 L50 91 L36 94 Z" fill="#78350f" stroke="#d97706" strokeWidth="1" />
      <circle cx="50" cy="50" r="2.5" fill="#fff" />
    </svg>
  );
}

export function SilverBadgeLogo({ size = 44, className = "" }: { size?: number | string; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`badge-vector-logo badge-logo-silver ${className}`}
      aria-label="Silver Tier Badge Emblem"
    >
      <defs>
        <linearGradient id="slv-body-grad" x1="20" y1="10" x2="80" y2="90" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#f1f5f9" />
          <stop offset="25%" stopColor="#94a3b8" />
          <stop offset="55%" stopColor="#334155" />
          <stop offset="85%" stopColor="#64748b" />
          <stop offset="100%" stopColor="#e2e8f0" />
        </linearGradient>
        <linearGradient id="slv-chrome-rim" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="30%" stopColor="#cbd5e1" />
          <stop offset="60%" stopColor="#475569" />
          <stop offset="100%" stopColor="#f8fafc" />
        </linearGradient>
        <linearGradient id="slv-star-grad" x1="50" y1="25" x2="50" y2="75" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="50%" stopColor="#e2e8f0" />
          <stop offset="100%" stopColor="#64748b" />
        </linearGradient>
        <filter id="slv-shadow" x="-10%" y="-10%" width="125%" height="125%">
          <feDropShadow dx="0" dy="3" stdDeviation="3" floodColor="#0f172a" floodOpacity="0.4" />
        </filter>
      </defs>

      {/* Silver 8-Point Starburst Base */}
      <g filter="url(#slv-shadow)">
        <polygon
          points="50,6 62,24 84,16 76,38 94,50 76,62 84,84 62,76 50,94 38,76 16,84 24,62 6,50 24,38 16,16 38,24"
          fill="url(#slv-body-grad)"
          stroke="url(#slv-chrome-rim)"
          strokeWidth="2.5"
          strokeLinejoin="round"
        />
      </g>

      {/* Inner Polished Silver Ring */}
      <circle cx="50" cy="50" r="28" fill="#1e293b" stroke="url(#slv-chrome-rim)" strokeWidth="2" />
      <circle cx="50" cy="50" r="25" fill="none" stroke="#e2e8f0" strokeWidth="0.8" strokeDasharray="2 2" />

      {/* Winged Silver Crest Star */}
      <polygon
        points="50,26 55.5,39.5 70,41 59,51 62.5,65 50,57.5 37.5,65 41,51 30,41 44.5,39.5"
        fill="url(#slv-star-grad)"
        stroke="#1e293b"
        strokeWidth="1"
        strokeLinejoin="round"
      />

      {/* Dual Silver Prongs */}
      <circle cx="50" cy="50" r="3.5" fill="#ffffff" />
      <circle cx="50" cy="50" r="1.5" fill="#475569" />
    </svg>
  );
}

export function GoldBadgeLogo({ size = 44, className = "" }: { size?: number | string; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`badge-vector-logo badge-logo-gold ${className}`}
      aria-label="Gold Tier Badge Emblem"
    >
      <defs>
        <linearGradient id="gld-body-grad" x1="10" y1="10" x2="90" y2="90" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#fef08a" />
          <stop offset="25%" stopColor="#eab308" />
          <stop offset="60%" stopColor="#713f12" />
          <stop offset="85%" stopColor="#a16207" />
          <stop offset="100%" stopColor="#fef9c3" />
        </linearGradient>
        <linearGradient id="gld-gold-rim" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#fffbeb" />
          <stop offset="35%" stopColor="#fbbf24" />
          <stop offset="70%" stopColor="#b45309" />
          <stop offset="100%" stopColor="#fef08a" />
        </linearGradient>
        <linearGradient id="gld-star-grad" x1="50" y1="20" x2="50" y2="80" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="30%" stopColor="#fde047" />
          <stop offset="70%" stopColor="#ca8a04" />
          <stop offset="100%" stopColor="#854d0e" />
        </linearGradient>
        <filter id="gld-shadow" x="-10%" y="-10%" width="125%" height="125%">
          <feDropShadow dx="0" dy="4" stdDeviation="3.5" floodColor="#713f12" floodOpacity="0.5" />
        </filter>
      </defs>

      {/* 24K Gold Octagonal Medallion Base */}
      <g filter="url(#gld-shadow)">
        <polygon
          points="32,8 68,8 92,32 92,68 68,92 32,92 8,68 8,32"
          fill="url(#gld-body-grad)"
          stroke="url(#gld-gold-rim)"
          strokeWidth="3.5"
          strokeLinejoin="round"
        />
      </g>

      {/* Imperial Crown Arch Top */}
      <path
        d="M28 26 L38 18 L50 28 L62 18 L72 26 L68 34 L32 34 Z"
        fill="url(#gld-gold-rim)"
        stroke="#713f12"
        strokeWidth="1"
      />
      <circle cx="38" cy="18" r="2.5" fill="#fef08a" />
      <circle cx="50" cy="28" r="2.5" fill="#fff" />
      <circle cx="62" cy="18" r="2.5" fill="#fef08a" />

      {/* Inner Polished Royal Gold Bezel */}
      <circle cx="50" cy="55" r="25" fill="#451a03" stroke="url(#gld-gold-rim)" strokeWidth="2.5" />
      <circle cx="50" cy="55" r="22" fill="none" stroke="#fde047" strokeWidth="1" strokeDasharray="3 2" />

      {/* Central 24K Gold Star */}
      <polygon
        points="50,34 54.5,46.5 68,48 57.5,57 61,70.5 50,63.5 39,70.5 42.5,57 32,48 45.5,46.5"
        fill="url(#gld-star-grad)"
        stroke="#713f12"
        strokeWidth="1.2"
        strokeLinejoin="round"
      />

      {/* Center Gem Sparkle */}
      <circle cx="50" cy="55" r="3" fill="#ffffff" />
    </svg>
  );
}

export function PlatinumBadgeLogo({ size = 44, className = "" }: { size?: number | string; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`badge-vector-logo badge-logo-platinum ${className}`}
      aria-label="Platinum Tier Badge Emblem"
    >
      <defs>
        <linearGradient id="plt-top-grad" x1="20" y1="12" x2="80" y2="42" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#bae6fd" />
          <stop offset="50%" stopColor="#7dd3fc" />
          <stop offset="100%" stopColor="#0284c7" />
        </linearGradient>
        <linearGradient id="plt-center-grad" x1="50" y1="36" x2="50" y2="88" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#e0f2fe" />
          <stop offset="35%" stopColor="#38bdf8" />
          <stop offset="70%" stopColor="#0369a1" />
          <stop offset="100%" stopColor="#082f49" />
        </linearGradient>
        <linearGradient id="plt-rim-grad" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="30%" stopColor="#38bdf8" />
          <stop offset="70%" stopColor="#0284c7" />
          <stop offset="100%" stopColor="#e0f2fe" />
        </linearGradient>
        <filter id="plt-shadow" x="-10%" y="-10%" width="125%" height="125%">
          <feDropShadow dx="0" dy="4" stdDeviation="3.5" floodColor="#0c4a6e" floodOpacity="0.55" />
        </filter>
      </defs>

      {/* Hexagonal Brilliant-Cut Platinum Gem */}
      <g filter="url(#plt-shadow)">
        {/* Crown Table (Top Facet) */}
        <polygon points="30,14 70,14 88,38 12,38" fill="url(#plt-top-grad)" stroke="url(#plt-rim-grad)" strokeWidth="2.5" />

        {/* Top Triangle Facets */}
        <polygon points="30,14 50,38 12,38" fill="#e0f2fe" fillOpacity="0.85" stroke="url(#plt-rim-grad)" strokeWidth="1.2" />
        <polygon points="30,14 70,14 50,38" fill="#bae6fd" fillOpacity="0.9" stroke="url(#plt-rim-grad)" strokeWidth="1.2" />
        <polygon points="70,14 88,38 50,38" fill="#38bdf8" fillOpacity="0.75" stroke="url(#plt-rim-grad)" strokeWidth="1.2" />

        {/* Pavilion (Lower Body Facets) */}
        <polygon points="12,38 32,64 50,88 12,38" fill="#0284c7" fillOpacity="0.9" stroke="url(#plt-rim-grad)" strokeWidth="1.2" />
        <polygon points="12,38 50,38 32,64" fill="#38bdf8" fillOpacity="0.8" stroke="url(#plt-rim-grad)" strokeWidth="1.2" />
        <polygon points="50,38 88,38 68,64" fill="#0369a1" fillOpacity="0.85" stroke="url(#plt-rim-grad)" strokeWidth="1.2" />
        <polygon points="88,38 68,64 50,88 88,38" fill="#082f49" fillOpacity="0.95" stroke="url(#plt-rim-grad)" strokeWidth="1.2" />
        <polygon points="50,38 68,64 50,88 32,64" fill="url(#plt-center-grad)" stroke="url(#plt-rim-grad)" strokeWidth="1.5" />
      </g>

      {/* Crystalline Sparkles & Highlights */}
      <polygon points="50,22 52,28 58,30 52,32 50,38 48,32 42,30 48,28" fill="#ffffff" />
      <polygon points="74,48 75.5,52 80,53.5 75.5,55 74,59 72.5,55 68,53.5 72.5,52" fill="#ffffff" />
      <polygon points="26,48 27.5,52 32,53.5 27.5,55 26,59 24.5,55 20,53.5 24.5,52" fill="#e0f2fe" />
    </svg>
  );
}

export function DiamondBadgeLogo({ size = 44, className = "" }: { size?: number | string; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`badge-vector-logo badge-logo-diamond ${className}`}
      aria-label="Diamond Tier Badge Emblem"
    >
      <defs>
        <linearGradient id="diam-crown-grad" x1="15" y1="10" x2="85" y2="90" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#fae8ff" />
          <stop offset="25%" stopColor="#c084fc" />
          <stop offset="60%" stopColor="#7e22ce" />
          <stop offset="85%" stopColor="#3b0764" />
          <stop offset="100%" stopColor="#e879f9" />
        </linearGradient>
        <linearGradient id="diam-rim-grad" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="30%" stopColor="#f5d0fe" />
          <stop offset="70%" stopColor="#a855f7" />
          <stop offset="100%" stopColor="#ffd700" />
        </linearGradient>
        <linearGradient id="diam-jewel-grad" x1="50" y1="35" x2="50" y2="75" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="40%" stopColor="#e879f9" />
          <stop offset="80%" stopColor="#9333ea" />
          <stop offset="100%" stopColor="#581c87" />
        </linearGradient>
        <filter id="diam-shadow" x="-10%" y="-10%" width="125%" height="125%">
          <feDropShadow dx="0" dy="4" stdDeviation="4" floodColor="#581c87" floodOpacity="0.6" />
        </filter>
      </defs>

      {/* Royal Apex Imperial Crown with Jewels */}
      <g filter="url(#diam-shadow)">
        {/* Crown Spikes & Crest */}
        <path
          d="M14 66 L20 28 L38 48 L50 16 L62 48 L80 28 L86 66 Z"
          fill="url(#diam-crown-grad)"
          stroke="url(#diam-rim-grad)"
          strokeWidth="3"
          strokeLinejoin="round"
        />

        {/* Crown Velvet Headband Base */}
        <path
          d="M12 66 C12 66, 30 72, 50 72 C70 72, 88 66, 88 66 L86 84 C86 84, 68 89, 50 89 C32 89, 14 84, 14 84 Z"
          fill="#3b0764"
          stroke="url(#diam-rim-grad)"
          strokeWidth="2.5"
        />
      </g>

      {/* Jewels on Crown Spike Tips */}
      <circle cx="20" cy="28" r="4.5" fill="#f5d0fe" stroke="#fff" strokeWidth="1.5" />
      <circle cx="50" cy="16" r="6" fill="#ffffff" stroke="#ffd700" strokeWidth="2" />
      <circle cx="80" cy="28" r="4.5" fill="#f5d0fe" stroke="#fff" strokeWidth="1.5" />

      {/* Crown Base Jewels Row */}
      <circle cx="26" cy="76" r="3" fill="#38bdf8" stroke="#fff" strokeWidth="1" />
      <polygon points="50,71 54,77 50,83 46,77" fill="url(#diam-jewel-grad)" stroke="#fff" strokeWidth="1" />
      <circle cx="74" cy="76" r="3" fill="#38bdf8" stroke="#fff" strokeWidth="1" />

      {/* Large Center Solitaire Diamond Gem */}
      <polygon
        points="50,38 64,52 50,66 36,52"
        fill="url(#diam-jewel-grad)"
        stroke="url(#diam-rim-grad)"
        strokeWidth="2"
      />
      <polygon points="50,42 58,52 50,62 42,52" fill="#ffffff" fillOpacity="0.6" />
      <circle cx="50" cy="52" r="2.5" fill="#ffffff" />

      {/* Top Star Sparkle */}
      <polygon points="50,8 52,14 58,16 52,18 50,24 48,18 42,16 48,14" fill="#ffffff" />
    </svg>
  );
}

export function BadgeTierEmblem({ tier = "Bronze", size = 44, className = "" }: BadgeEmblemProps) {
  switch (tier) {
    case "Bronze":
      return <BronzeBadgeLogo size={size} className={className} />;
    case "Silver":
      return <SilverBadgeLogo size={size} className={className} />;
    case "Gold":
      return <GoldBadgeLogo size={size} className={className} />;
    case "Platinum":
      return <PlatinumBadgeLogo size={size} className={className} />;
    case "Diamond":
      return <DiamondBadgeLogo size={size} className={className} />;
    default:
      return <BronzeBadgeLogo size={size} className={className} />;
  }
}

interface BadgePillProps {
  tier?: BadgeTier;
  events?: number;
  showEvents?: boolean;
  size?: "sm" | "md" | "lg";
  className?: string;
}

export function VolunteerBadgePill({
  tier = "Bronze",
  events,
  showEvents = false,
  size = "md",
  className = "",
}: BadgePillProps) {
  const tierDef = TIER_DEFINITIONS[tier] || TIER_DEFINITIONS.Bronze;
  const iconSize = size === "sm" ? 18 : size === "lg" ? 28 : 22;

  return (
    <span
      className={`tier-badge-pill tier-${tier.toLowerCase()} tier-size-${size} ${className}`}
      title={`${tierDef.name} Tier (${tierDef.tagline})`}
    >
      <BadgeTierEmblem tier={tier} size={iconSize} className="pill-emblem" />
      <span className="tier-badge-pill-text">
        {tier} Tier
        {showEvents && typeof events === "number" ? ` · ${events} Events` : ""}
      </span>
    </span>
  );
}

export function VolunteerBadgeRoadmap({
  initialEvents = 12,
}: {
  initialEvents?: number;
}) {
  const progress = getVolunteerBadgeProgress(initialEvents);

  return (
    <div className="badge-roadmap-container" aria-label="Volunteer Tier & Badge Progress System">
      {/* Top Banner with Active Status & Progress */}
      <div className="badge-header-panel">
        <div className="badge-hero-info">
          <div className={`badge-emblem-large tier-${progress.currentTier.toLowerCase()}`}>
            <BadgeTierEmblem tier={progress.currentTier} size={64} className="hero-emblem-svg" />
            <span className="badge-emblem-tier-label">{progress.currentTier}</span>
          </div>
          <div className="badge-hero-text">
            <div className="badge-kicker">
              <span>VOLUNTEER STATUS</span>
              <VolunteerBadgePill tier={progress.currentTier} size="sm" />
            </div>
            <h3 className="badge-hero-title">
              {progress.currentTier} Volunteer — {progress.currentTierDef.tagline}
            </h3>
            <p className="badge-hero-desc">
              {progress.currentTierDef.description}
            </p>
            <div className="badge-hero-stats">
              <div className="b-stat">
                <span className="b-stat-num">{progress.eventsCompleted}</span>
                <span className="b-stat-lbl">Events Completed</span>
              </div>
              <div className="b-stat">
                <span className="b-stat-num">{progress.currentTier}</span>
                <span className="b-stat-lbl">Active Tier</span>
              </div>
              <div className="b-stat">
                <span className="b-stat-num">
                  {progress.nextTier ? `${progress.eventsToNextTier} more` : "Pinnacle"}
                </span>
                <span className="b-stat-lbl">
                  {progress.nextTier ? `To ${progress.nextTier} (${progress.nextTierDef?.tagline})` : "Max Tier Reached"}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Current Tier Progress Bar */}
        <div className="badge-progress-card">
          <div className="badge-progress-head">
            <span>
              <strong>Tier Progress:</strong> {progress.eventsCompleted} Events Completed
            </span>
            <span className="badge-progress-milestone">
              {progress.isMaxTier
                ? "Diamond Tier (50+ Events)"
                : progress.eventsCompleted < 10
                ? `${progress.eventsCompleted} / 10 to Bronze`
                : `${progress.eventsCompleted} / ${progress.nextTierDef?.minEvents} to ${progress.nextTier}`}
            </span>
          </div>
          <div className="badge-progress-bar-track">
            <div
              className={`badge-progress-bar-fill tier-fill-${progress.currentTier.toLowerCase()}`}
              style={{ width: `${progress.isMaxTier ? 100 : progress.tierProgressPercent}%` }}
            />
          </div>
          <div className="badge-progress-hint">
            {progress.nextTier ? (
              <>
                <Icon name="arrow_upward" />
                <span>
                  Complete <strong>{progress.eventsToNextTier} more event{progress.eventsToNextTier > 1 ? "s" : ""}</strong> to unlock <strong>{progress.nextTier} Tier ({progress.nextTierDef?.tagline})</strong>!
                </span>
              </>
            ) : (
              <>
                <Icon name="verified" fill />
                <span>Maximum Diamond tier achieved. Full executive event privileges active.</span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* 5-Tier Simple, Sorted, Structured Cards Grid */}
      <div className="badge-tier-grid">
        {progress.allTiers.map((tDef) => {
          const isCompleted = progress.eventsCompleted >= (tDef.tier === "Diamond" ? 50 : (tDef.maxEvents + 1));
          const isCurrent = progress.eventsCompleted >= tDef.minEvents && (tDef.tier === "Diamond" || progress.eventsCompleted <= tDef.maxEvents);
          const isLocked = progress.eventsCompleted < tDef.minEvents;

          let statusBadge = "Locked";
          let statusClass = "locked";
          if (isCurrent) {
            statusBadge = "Active Tier";
            statusClass = "current";
          } else if (isCompleted) {
            statusBadge = "Unlocked ✓";
            statusClass = "completed";
          }

          return (
            <div
              key={tDef.tier}
              className={`tier-card tier-card-${tDef.tier.toLowerCase()} ${
                isCurrent ? "is-current" : ""
              } ${isCompleted ? "is-completed" : ""} ${isLocked ? "is-locked" : ""}`}
            >
              <div className="tier-card-top">
                <div className={`tier-card-icon tier-icon-${tDef.tier.toLowerCase()}`}>
                  <BadgeTierEmblem tier={tDef.tier} size={36} />
                </div>
                <span className={`tier-status-pill status-${statusClass}`}>
                  {statusBadge}
                </span>
              </div>

              <h4 className="tier-card-name">{tDef.name.toUpperCase()}</h4>
              <div className="tier-card-tagline">{tDef.tagline}</div>

              <div className="tier-card-perks">
                <span className="tier-perks-title">Tier Benefits:</span>
                <ul>
                  {tDef.perks.map((perk, idx) => (
                    <li key={idx}>
                      <Icon name={isLocked ? "lock" : "check_circle"} fill={!isLocked} />
                      <span>{perk}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="tier-card-footer">
                <span className="tier-range-lbl">{tDef.tagline}</span>
                {isCurrent && <span className="tier-active-indicator">Your Rank</span>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
