interface LandmarkProps {
  size?: number | string;
  className?: string;
  color?: string;
}

export function IndiaGateIcon({ size = 52, className = "", color = "currentColor" }: LandmarkProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`landmark-svg ${className}`}
      aria-label="India Gate, Delhi NCR"
    >
      {/* Top Stepped Pediment */}
      <rect x="22" y="10" width="20" height="3" rx="0.5" stroke={color} strokeWidth="1.5" />
      <rect x="18" y="13" width="28" height="3" rx="0.5" stroke={color} strokeWidth="1.5" />
      <rect x="14" y="16" width="36" height="5" rx="0.5" stroke={color} strokeWidth="1.5" />
      <line x1="16" y1="21" x2="48" y2="21" stroke={color} strokeWidth="1.5" />

      {/* Main Pillars */}
      <rect x="17" y="21" width="10" height="34" stroke={color} strokeWidth="1.5" />
      <rect x="37" y="21" width="10" height="34" stroke={color} strokeWidth="1.5" />

      {/* Center Archway */}
      <path
        d="M27 55 V35 C27 28 37 28 37 35 V55"
        stroke={color}
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      {/* Upper Arch Inset */}
      <path
        d="M29 35 C29 30 35 30 35 35"
        stroke={color}
        strokeWidth="1.2"
        strokeLinecap="round"
      />

      {/* Pillar Inner Grooves */}
      <line x1="22" y1="24" x2="22" y2="52" stroke={color} strokeWidth="1" strokeDasharray="2 2" />
      <line x1="42" y1="24" x2="42" y2="52" stroke={color} strokeWidth="1" strokeDasharray="2 2" />

      {/* Base Foundation */}
      <line x1="10" y1="55" x2="54" y2="55" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
      <line x1="6" y1="58" x2="58" y2="58" stroke={color} strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

export function GatewayOfIndiaIcon({ size = 52, className = "", color = "currentColor" }: LandmarkProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`landmark-svg ${className}`}
      aria-label="Gateway of India, Mumbai"
    >
      {/* Central Upper Dome & Parapet */}
      <path d="M26 18 C26 13 38 13 38 18 Z" stroke={color} strokeWidth="1.5" />
      <line x1="32" y1="10" x2="32" y2="13" stroke={color} strokeWidth="1.5" />
      <rect x="22" y="18" width="20" height="4" stroke={color} strokeWidth="1.5" />

      {/* Four Turret Pinnacles */}
      <line x1="13" y1="14" x2="13" y2="22" stroke={color} strokeWidth="1.5" />
      <circle cx="13" cy="14" r="1.5" fill={color} />
      <line x1="51" y1="14" x2="51" y2="22" stroke={color} strokeWidth="1.5" />
      <circle cx="51" cy="14" r="1.5" fill={color} />

      {/* Side Towers & Main Structure */}
      <rect x="10" y="22" width="9" height="33" stroke={color} strokeWidth="1.5" />
      <rect x="45" y="22" width="9" height="33" stroke={color} strokeWidth="1.5" />
      <rect x="19" y="22" width="26" height="7" stroke={color} strokeWidth="1.5" />

      {/* Grand Central Arch */}
      <path
        d="M24 55 V36 C24 28 40 28 40 36 V55"
        stroke={color}
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      {/* Side Arches */}
      <path d="M12 55 V42 C12 38 17 38 17 42 V55" stroke={color} strokeWidth="1.2" />
      <path d="M47 55 V42 C47 38 52 38 52 42 V55" stroke={color} strokeWidth="1.2" />

      {/* Base Line */}
      <line x1="6" y1="55" x2="58" y2="55" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
      <line x1="4" y1="58" x2="60" y2="58" stroke={color} strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

export function VictoriaMemorialIcon({ size = 52, className = "", color = "currentColor" }: LandmarkProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`landmark-svg ${className}`}
      aria-label="Victoria Memorial, Kolkata"
    >
      {/* Central Grand Dome */}
      <path d="M25 24 C25 15 39 15 39 24 Z" stroke={color} strokeWidth="1.5" />
      <line x1="32" y1="11" x2="32" y2="15" stroke={color} strokeWidth="1.5" />
      <circle cx="32" cy="10" r="1.5" fill={color} />
      <rect x="23" y="24" width="18" height="4" stroke={color} strokeWidth="1.5" />

      {/* Corner Pavilions (Left & Right Small Domes) */}
      <path d="M10 28 C10 23 18 23 18 28 Z" stroke={color} strokeWidth="1.2" />
      <line x1="14" y1="20" x2="14" y2="23" stroke={color} strokeWidth="1.2" />
      <path d="M46 28 C46 23 54 23 54 28 Z" stroke={color} strokeWidth="1.2" />
      <line x1="50" y1="20" x2="50" y2="23" stroke={color} strokeWidth="1.2" />

      {/* Main Colonnade Facade */}
      <rect x="8" y="28" width="48" height="26" stroke={color} strokeWidth="1.5" />

      {/* Central Portico Pillars */}
      <line x1="26" y1="28" x2="26" y2="54" stroke={color} strokeWidth="1.2" />
      <line x1="32" y1="28" x2="32" y2="54" stroke={color} strokeWidth="1.2" />
      <line x1="38" y1="28" x2="38" y2="54" stroke={color} strokeWidth="1.2" />

      {/* Central Entrance Arch */}
      <path d="M28 54 V42 C28 38 36 38 36 42 V54" stroke={color} strokeWidth="1.4" />

      {/* Base Foundation */}
      <line x1="4" y1="54" x2="60" y2="54" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
      <line x1="2" y1="57" x2="62" y2="57" stroke={color} strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

export function VidhanaSoudhaIcon({ size = 52, className = "", color = "currentColor" }: LandmarkProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`landmark-svg ${className}`}
      aria-label="Vidhana Soudha, Bengaluru"
    >
      {/* Central Grand Dome with Spire */}
      <path d="M26 21 C26 14 38 14 38 21 Z" stroke={color} strokeWidth="1.5" />
      <line x1="32" y1="9" x2="32" y2="14" stroke={color} strokeWidth="1.5" />
      <circle cx="32" cy="8" r="1.5" fill={color} />
      <rect x="24" y="21" width="16" height="4" stroke={color} strokeWidth="1.5" />

      {/* Side Chhatri Pavilions */}
      <path d="M9 25 C9 21 16 21 16 25 Z" stroke={color} strokeWidth="1.2" />
      <line x1="12.5" y1="18" x2="12.5" y2="21" stroke={color} strokeWidth="1.2" />
      <path d="M48 25 C48 21 55 21 55 25 Z" stroke={color} strokeWidth="1.2" />
      <line x1="51.5" y1="18" x2="51.5" y2="21" stroke={color} strokeWidth="1.2" />

      {/* Main Palace Building */}
      <rect x="8" y="25" width="48" height="29" stroke={color} strokeWidth="1.5" />

      {/* Colonnade Pillars */}
      <line x1="15" y1="25" x2="15" y2="54" stroke={color} strokeWidth="1.2" />
      <line x1="22" y1="25" x2="22" y2="54" stroke={color} strokeWidth="1.2" />
      <line x1="42" y1="25" x2="42" y2="54" stroke={color} strokeWidth="1.2" />
      <line x1="49" y1="25" x2="49" y2="54" stroke={color} strokeWidth="1.2" />

      {/* Central Dravidian Arch Entrance */}
      <path d="M27 54 V36 C27 30 37 30 37 36 V54" stroke={color} strokeWidth="1.5" />
      <path d="M29 36 C29 33 35 33 35 36" stroke={color} strokeWidth="1" />

      {/* Base Steps */}
      <line x1="4" y1="54" x2="60" y2="54" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
      <line x1="2" y1="57" x2="62" y2="57" stroke={color} strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

export function CharminarIcon({ size = 52, className = "", color = "currentColor" }: LandmarkProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`landmark-svg ${className}`}
      aria-label="Charminar, Hyderabad"
    >
      {/* Four Tall Corner Minarets */}
      {/* Left Outer Minaret */}
      <rect x="10" y="14" width="6" height="41" stroke={color} strokeWidth="1.5" />
      <path d="M10 14 C10 9 16 9 16 14 Z" stroke={color} strokeWidth="1.5" />
      <line x1="13" y1="5" x2="13" y2="9" stroke={color} strokeWidth="1.2" />
      <line x1="9" y1="26" x2="17" y2="26" stroke={color} strokeWidth="1.5" />
      <line x1="9" y1="38" x2="17" y2="38" stroke={color} strokeWidth="1.5" />

      {/* Right Outer Minaret */}
      <rect x="48" y="14" width="6" height="41" stroke={color} strokeWidth="1.5" />
      <path d="M48 14 C48 9 54 9 54 14 Z" stroke={color} strokeWidth="1.5" />
      <line x1="51" y1="5" x2="51" y2="9" stroke={color} strokeWidth="1.2" />
      <line x1="47" y1="26" x2="55" y2="26" stroke={color} strokeWidth="1.5" />
      <line x1="47" y1="38" x2="55" y2="38" stroke={color} strokeWidth="1.5" />

      {/* Upper Gallery & Balconies */}
      <rect x="16" y="22" width="32" height="10" stroke={color} strokeWidth="1.5" />
      <circle cx="24" cy="27" r="1.5" stroke={color} strokeWidth="1" />
      <circle cx="32" cy="27" r="1.5" stroke={color} strokeWidth="1" />
      <circle cx="40" cy="27" r="1.5" stroke={color} strokeWidth="1" />

      {/* Central Monument Body */}
      <rect x="16" y="32" width="32" height="23" stroke={color} strokeWidth="1.5" />

      {/* Grand Center Arch */}
      <path
        d="M24 55 V42 C24 33 40 33 40 42 V55"
        stroke={color}
        strokeWidth="1.5"
        strokeLinecap="round"
      />

      {/* Base Line */}
      <line x1="6" y1="55" x2="58" y2="55" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}

export function ChandigarhHandIcon({ size = 52, className = "", color = "currentColor" }: LandmarkProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`landmark-svg ${className}`}
      aria-label="Open Hand Monument, Chandigarh"
    >
      {/* Le Corbusier's Open Hand Outline Silhouette */}
      <path
        d="M22 36 C18 34 16 30 18 25 C20 20 25 18 27 23 C28 25 29 27 30 22 C31 16 36 15 38 20 C39 23 40 25 41 18 C43 12 48 13 49 19 C50 23 50 26 51 22 C53 17 58 19 56 26 C54 34 48 40 40 42 L34 43 L34 49 L30 49 L30 43 C26 41 24 39 22 36 Z"
        stroke={color}
        strokeWidth="1.6"
        strokeLinejoin="round"
        strokeLinecap="round"
      />

      {/* Hand Palm Contour Lines */}
      <path d="M26 30 C30 32 38 32 44 28" stroke={color} strokeWidth="1.2" strokeLinecap="round" />
      <path d="M30 35 C34 37 40 37 46 34" stroke={color} strokeWidth="1.2" strokeLinecap="round" />

      {/* Vertical Revolving Shaft / Axis */}
      <line x1="32" y1="43" x2="32" y2="52" stroke={color} strokeWidth="2.2" strokeLinecap="round" />

      {/* Monument Podium & Platform */}
      <rect x="22" y="52" width="20" height="4" rx="0.5" stroke={color} strokeWidth="1.5" />
      <rect x="14" y="56" width="36" height="3" rx="0.5" stroke={color} strokeWidth="1.5" />

      {/* Base Line */}
      <line x1="8" y1="59" x2="56" y2="59" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}

export function ChennaiLandmarkIcon({ size = 52, className = "", color = "currentColor" }: LandmarkProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`landmark-svg ${className}`}
      aria-label="Chennai Central / Ripon Building"
    >
      {/* Central Gothic Clock Tower */}
      <path d="M28 20 L32 10 L36 20 Z" stroke={color} strokeWidth="1.5" />
      <line x1="32" y1="6" x2="32" y2="10" stroke={color} strokeWidth="1.5" />
      <rect x="27" y="20" width="10" height="35" stroke={color} strokeWidth="1.5" />
      <circle cx="32" cy="27" r="3" stroke={color} strokeWidth="1.2" />

      {/* Side Wings & Turrets */}
      <rect x="10" y="32" width="17" height="23" stroke={color} strokeWidth="1.5" />
      <rect x="37" y="32" width="17" height="23" stroke={color} strokeWidth="1.5" />

      {/* Left & Right Roof Pitches */}
      <path d="M10 32 L18.5 24 L27 32 Z" stroke={color} strokeWidth="1.2" />
      <path d="M37 32 L45.5 24 L54 32 Z" stroke={color} strokeWidth="1.2" />

      {/* Arched Windows */}
      <path d="M14 44 V39 C14 36 18 36 18 39 V44" stroke={color} strokeWidth="1.2" />
      <path d="M46 44 V39 C46 36 50 36 50 39 V44" stroke={color} strokeWidth="1.2" />
      <path d="M29 55 V45 C29 41 35 41 35 45 V55" stroke={color} strokeWidth="1.4" />

      {/* Base */}
      <line x1="6" y1="55" x2="58" y2="55" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}

export function JaipurHawaMahalIcon({ size = 52, className = "", color = "currentColor" }: LandmarkProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`landmark-svg ${className}`}
      aria-label="Hawa Mahal, Jaipur"
    >
      {/* Top Crown Dome */}
      <path d="M28 14 C28 10 36 10 36 14 Z" stroke={color} strokeWidth="1.5" />
      <line x1="32" y1="6" x2="32" y2="10" stroke={color} strokeWidth="1.5" />

      {/* Tiered Honeycomb Jharokhas */}
      {/* Top Tier (3 pods) */}
      <path d="M26 21 C26 17 32 17 32 21 C32 17 38 17 38 21" stroke={color} strokeWidth="1.2" />
      <rect x="24" y="21" width="16" height="6" stroke={color} strokeWidth="1.2" />

      {/* Mid Tier (5 pods) */}
      <path d="M18 33 C18 29 25 29 25 33 C25 29 32 29 32 33 C32 29 39 29 39 33 C39 29 46 29 46 33" stroke={color} strokeWidth="1.2" />
      <rect x="16" y="33" width="32" height="9" stroke={color} strokeWidth="1.3" />

      {/* Lower Tier (7 pods) */}
      <path d="M12 47 C12 43 18 43 18 47 C18 43 25 43 25 47 C25 43 32 43 32 47 C32 43 39 43 39 47 C39 43 46 43 46 47 C46 43 52 43 52 47" stroke={color} strokeWidth="1.2" />
      <rect x="10" y="47" width="44" height="8" stroke={color} strokeWidth="1.5" />

      {/* Jharokha Windows */}
      <circle cx="32" cy="24" r="1.5" fill={color} />
      <circle cx="23" cy="37" r="1.5" fill={color} />
      <circle cx="32" cy="37" r="1.5" fill={color} />
      <circle cx="41" cy="37" r="1.5" fill={color} />

      {/* Base */}
      <line x1="6" y1="55" x2="58" y2="55" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}

export function GoaChurchIcon({ size = 52, className = "", color = "currentColor" }: LandmarkProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`landmark-svg ${className}`}
      aria-label="Goa Church"
    >
      {/* Central Pediment with Cross */}
      <line x1="32" y1="8" x2="32" y2="16" stroke={color} strokeWidth="1.5" />
      <line x1="29" y1="11" x2="35" y2="11" stroke={color} strokeWidth="1.5" />
      <path d="M24 24 L32 16 L40 24 Z" stroke={color} strokeWidth="1.5" />

      {/* Twin Bell Towers (Left & Right) */}
      <rect x="10" y="20" width="10" height="35" stroke={color} strokeWidth="1.5" />
      <path d="M10 20 L15 14 L20 20 Z" stroke={color} strokeWidth="1.2" />
      <rect x="44" y="20" width="10" height="35" stroke={color} strokeWidth="1.5" />
      <path d="M44 20 L49 14 L54 20 Z" stroke={color} strokeWidth="1.2" />

      {/* Belfry Arches */}
      <path d="M13 28 V24 C13 22 17 22 17 24 V28" stroke={color} strokeWidth="1.2" />
      <path d="M47 28 V24 C47 22 51 22 51 24 V28" stroke={color} strokeWidth="1.2" />

      {/* Center Facade */}
      <rect x="20" y="24" width="24" height="31" stroke={color} strokeWidth="1.5" />
      <circle cx="32" cy="32" r="3" stroke={color} strokeWidth="1.2" />

      {/* Main Entrance Portal */}
      <path d="M28 55 V42 C28 38 36 38 36 42 V55" stroke={color} strokeWidth="1.5" />

      {/* Base */}
      <line x1="6" y1="55" x2="58" y2="55" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}

export function PuneLandmarkIcon({ size = 52, className = "", color = "currentColor" }: LandmarkProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`landmark-svg ${className}`}
      aria-label="Shaniwar Wada, Pune"
    >
      {/* Maratha Bastion Towers */}
      <rect x="10" y="18" width="13" height="37" stroke={color} strokeWidth="1.5" />
      <path d="M10 18 L16.5 12 L23 18 Z" stroke={color} strokeWidth="1.2" />

      <rect x="41" y="18" width="13" height="37" stroke={color} strokeWidth="1.5" />
      <path d="M41 18 L47.5 12 L54 18 Z" stroke={color} strokeWidth="1.2" />

      {/* Central Dilli Darwaza Wall */}
      <rect x="23" y="22" width="18" height="33" stroke={color} strokeWidth="1.5" />
      <line x1="23" y1="26" x2="41" y2="26" stroke={color} strokeWidth="1.2" />

      {/* Fortified Gate Arch */}
      <path d="M27 55 V36 C27 30 37 30 37 36 V55" stroke={color} strokeWidth="1.6" />
      <line x1="32" y1="36" x2="32" y2="55" stroke={color} strokeWidth="1" strokeDasharray="2 2" />

      {/* Battlements & Arrow Slits */}
      <line x1="16.5" y1="26" x2="16.5" y2="34" stroke={color} strokeWidth="1.2" />
      <line x1="47.5" y1="26" x2="47.5" y2="34" stroke={color} strokeWidth="1.2" />

      {/* Base */}
      <line x1="6" y1="55" x2="58" y2="55" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}

export function GenericCityIcon({ size = 52, className = "", color = "currentColor" }: LandmarkProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`landmark-svg ${className}`}
      aria-label="City Skyline"
    >
      <rect x="12" y="24" width="10" height="31" stroke={color} strokeWidth="1.5" />
      <rect x="24" y="14" width="16" height="41" stroke={color} strokeWidth="1.5" />
      <line x1="32" y1="6" x2="32" y2="14" stroke={color} strokeWidth="1.5" />
      <rect x="42" y="20" width="10" height="35" stroke={color} strokeWidth="1.5" />

      {/* Windows */}
      <line x1="28" y1="22" x2="36" y2="22" stroke={color} strokeWidth="1" />
      <line x1="28" y1="28" x2="36" y2="28" stroke={color} strokeWidth="1" />
      <line x1="28" y1="34" x2="36" y2="34" stroke={color} strokeWidth="1" />
      <line x1="28" y1="40" x2="36" y2="40" stroke={color} strokeWidth="1" />

      {/* Base */}
      <line x1="6" y1="55" x2="58" y2="55" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}

export function CityLandmarkIcon({ cityId, size = 52, className = "", color = "currentColor" }: { cityId: string; size?: number | string; className?: string; color?: string }) {
  switch (cityId) {
    case "delhi-ncr":
      return <IndiaGateIcon size={size} className={className} color={color} />;
    case "mumbai":
      return <GatewayOfIndiaIcon size={size} className={className} color={color} />;
    case "kolkata":
      return <VictoriaMemorialIcon size={size} className={className} color={color} />;
    case "bengaluru":
      return <VidhanaSoudhaIcon size={size} className={className} color={color} />;
    case "hyderabad":
      return <CharminarIcon size={size} className={className} color={color} />;
    case "chandigarh":
      return <ChandigarhHandIcon size={size} className={className} color={color} />;
    case "chennai":
      return <ChennaiLandmarkIcon size={size} className={className} color={color} />;
    case "jaipur":
      return <JaipurHawaMahalIcon size={size} className={className} color={color} />;
    case "goa":
      return <GoaChurchIcon size={size} className={className} color={color} />;
    case "pune":
      return <PuneLandmarkIcon size={size} className={className} color={color} />;
    default:
      return <GenericCityIcon size={size} className={className} color={color} />;
  }
}
