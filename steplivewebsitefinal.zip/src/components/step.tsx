import { Link, useRouterState } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import {
  VOLUNTEER,
  REGIONS,
  getActiveRegionId,
  setActiveRegionId,
  getRegionById,
  type EventStatus,
  type RegionOption,
} from "../lib/step-data";
import { useCurrentUser, logoutUser, markNotificationsAsRead } from "../lib/user-db";
import { CityLandmarkIcon } from "./CityLandmarks";

/* ─── Region Management Hook ────────────────────────────────── */
export function useActiveRegion() {
  const [regionId, setRegionId] = useState<string>("delhi-ncr");

  useEffect(() => {
    setRegionId(getActiveRegionId());

    const handleRegionChange = (e: Event) => {
      const customEvent = e as CustomEvent<string>;
      setRegionId(customEvent.detail || getActiveRegionId());
    };

    window.addEventListener("stepapp:region-change", handleRegionChange);
    return () => window.removeEventListener("stepapp:region-change", handleRegionChange);
  }, []);

  const selectRegion = useCallback((newId: string) => {
    setActiveRegionId(newId);
    setRegionId(newId);
  }, []);

  const currentRegion = getRegionById(regionId);

  return {
    regionId,
    currentRegion,
    selectRegion,
    regions: REGIONS,
  };
}

/* ─── Reference-Style Location Modal ────────────────────────── */
export function RegionSelectModal({
  isOpen,
  onClose,
  onSelected,
}: {
  isOpen: boolean;
  onClose: () => void;
  onSelected?: (region: RegionOption) => void;
}) {
  const { regionId, selectRegion, regions } = useActiveRegion();
  const [search, setSearch] = useState("");

  if (!isOpen) return null;

  const popularCities = regions.filter((r) => r.isPopular && r.id !== "all");
  const otherCities = regions.filter((r) => !r.isPopular || r.id === "all");

  const query = search.trim().toLowerCase();
  const isSearching = query.length > 0;

  const searchResults = regions.filter(
    (r) =>
      r.name.toLowerCase().includes(query) ||
      r.state.toLowerCase().includes(query) ||
      r.hubName.toLowerCase().includes(query)
  );

  return (
    <div className="loc-modal-backdrop" onClick={onClose}>
      <div
        className="loc-modal-sheet"
        role="dialog"
        aria-modal="true"
        aria-label="Location Selection"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header matching reference */}
        <div className="loc-sheet-header">
          <button className="loc-sheet-back-btn" onClick={onClose} aria-label="Close location picker">
            <span className="ms">expand_more</span>
          </button>
          <h3 className="loc-sheet-title">Location</h3>
          <button className="loc-sheet-close-btn" onClick={onClose} aria-label="Close">
            ✕
          </button>
        </div>

        {/* Search Bar matching reference */}
        <div className="loc-search-box">
          <span className="ms loc-search-icon">search</span>
          <input
            type="text"
            placeholder="Search city, area or locality"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="loc-search-input"
            autoFocus
          />
          {search && (
            <button className="loc-search-clear" onClick={() => setSearch("")} aria-label="Clear search">
              ✕
            </button>
          )}
        </div>

        <div className="loc-sheet-body">
          {!isSearching ? (
            <>
              {/* Use Current Location Blue Card matching reference */}
              <button
                type="button"
                className="loc-current-card"
                onClick={() => {
                  selectRegion("delhi-ncr");
                  if (onSelected) onSelected(getRegionById("delhi-ncr"));
                  onClose();
                }}
              >
                <div className="loc-current-target-icon">
                  <span className="loc-target-dot" />
                </div>
                <div className="loc-current-text">
                  <strong className="loc-current-title">Use current location</strong>
                  <span className="loc-current-sub">Deenpur, Durga Vihar I, Najafgarh, New Delhi</span>
                </div>
                <span className="ms loc-current-arrow">chevron_right</span>
              </button>

              {/* Popular Cities Section matching reference with Landmark SVGs */}
              <div className="loc-section-wrap">
                <h4 className="loc-section-heading">Popular cities</h4>
                <div className="loc-popular-grid">
                  {popularCities.map((city) => {
                    const isSelected = city.id === regionId;
                    return (
                      <button
                        key={city.id}
                        type="button"
                        className={`loc-city-tile ${isSelected ? "is-selected" : ""}`}
                        onClick={() => {
                          selectRegion(city.id);
                          if (onSelected) onSelected(city);
                          onClose();
                        }}
                      >
                        <div className="loc-landmark-wrap">
                          <CityLandmarkIcon cityId={city.id} size={44} />
                        </div>
                        <span className="loc-city-name">{city.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Other Regional Hubs */}
              <div className="loc-section-wrap" style={{ marginTop: 18 }}>
                <h4 className="loc-section-heading">Other cities &amp; hubs</h4>
                <div className="loc-other-cities-list">
                  {otherCities.map((city) => {
                    const isSelected = city.id === regionId;
                    return (
                      <button
                        key={city.id}
                        type="button"
                        className={`loc-other-city-item ${isSelected ? "is-selected" : ""}`}
                        onClick={() => {
                          selectRegion(city.id);
                          if (onSelected) onSelected(city);
                          onClose();
                        }}
                      >
                        <span className="loc-other-city-name">{city.name}</span>
                        <span className="loc-other-city-state">{city.state}</span>
                        {isSelected && <span className="loc-active-pill">Active</span>}
                      </button>
                    );
                  })}
                </div>
              </div>
            </>
          ) : (
            /* Search Results */
            <div className="loc-section-wrap">
              <h4 className="loc-section-heading">Matching locations ({searchResults.length})</h4>
              <div className="loc-other-cities-list">
                {searchResults.map((city) => {
                  const isSelected = city.id === regionId;
                  return (
                    <button
                      key={city.id}
                      type="button"
                      className={`loc-other-city-item ${isSelected ? "is-selected" : ""}`}
                      onClick={() => {
                        selectRegion(city.id);
                        if (onSelected) onSelected(city);
                        onClose();
                      }}
                    >
                      <div className="loc-sr-left">
                        <span className="ms loc-sr-pin">location_on</span>
                        <div>
                          <strong className="loc-other-city-name">{city.name}</strong>
                          <span className="loc-other-city-state">{city.state} · {city.hubName}</span>
                        </div>
                      </div>
                      {isSelected ? (
                        <span className="loc-active-pill">Active</span>
                      ) : (
                        <span className="ms loc-current-arrow">chevron_right</span>
                      )}
                    </button>
                  );
                })}
                {searchResults.length === 0 && (
                  <div className="loc-no-results">
                    <span className="ms">search_off</span>
                    <p>No cities found matching &quot;{search}&quot;</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ─── Location Region Selector Pill (TopNav & Everywhere) ────── */
export function LocationRegionPill({ className = "" }: { className?: string }) {
  const { currentRegion } = useActiveRegion();
  const [modalOpen, setModalOpen] = useState(false);

  return (
    <>
      <button
        type="button"
        className={`location-region-pill ${className}`}
        onClick={() => setModalOpen(true)}
        title={`Current Location: ${currentRegion.name} (${currentRegion.state}). Click to change.`}
      >
        <span className="location-pin-icon">
          <Icon name="location_on" fill />
        </span>
        <span className="location-name">{currentRegion.name}</span>
        <span className="location-caret ms">expand_more</span>
      </button>

      <RegionSelectModal isOpen={modalOpen} onClose={() => setModalOpen(false)} />
    </>
  );
}

/* ─── Brand ─────────────────────────────────────────────────── */
export function Brand() {
  return (
    <Link to="/" className="brand" aria-label="STEP LIVE home">
      <img
        src="/logo.png"
        alt="STEP LIVE"
        className="brand-logo"
        width={136}
        height={58}
      />
    </Link>
  );
}

const NAV_ITEMS = [
  { to: "/", label: "Overview", icon: "grid_view" },
  { to: "/events", label: "Events", icon: "event" },
  { to: "/guidelines", label: "Volunteer Guidelines", icon: "menu_book" },
  { to: "/profile", label: "Profile", icon: "person" },
] as const;

function useCurrentPath() {
  return useRouterState({ select: (s) => s.location.pathname });
}

/* ─── Top navigation (home page) ────────────────────────────── */
export function TopNav() {
  const path = useCurrentPath();
  const [open, setOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [regionModalOpen, setRegionModalOpen] = useState(false);
  const { currentRegion } = useActiveRegion();
  const { user } = useCurrentUser();

  useEffect(() => {
    setOpen(false);
    setNotifOpen(false);
  }, [path]);

  const notifications = user?.notifications || [];
  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <>
      <header className="topnav">
        <div className="topnav-brand-wrap">
          <Brand />
          <LocationRegionPill className="topnav-region-pill" />
        </div>
        <nav className="topnav-links" aria-label="Primary">
          {NAV_ITEMS.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={path === item.to ? "active" : undefined}
            >
              {item.label}
            </Link>
          ))}
          {user?.role === "admin" && (
            <Link
              to="/admin"
              className={path === "/admin" ? "active" : undefined}
              style={{ color: "var(--olive)", fontWeight: 800 }}
            >
              ★ Admin CMS
            </Link>
          )}
        </nav>

        <div className="topnav-actions" style={{ position: "relative" }}>
          {user?.role === "admin" && (
            <Link
              to="/admin"
              className="btn btn-sm btn-accent"
              style={{ display: "inline-flex", alignItems: "center", gap: 4, padding: "4px 10px", fontSize: 12 }}
            >
              <span className="ms" style={{ fontSize: 16 }}>admin_panel_settings</span> Admin CMS
            </Link>
          )}

          {/* Notifications button & popover */}
          <div style={{ position: "relative" }}>
            <button
              className="icon-btn"
              aria-label="Notifications"
              onClick={() => setNotifOpen(!notifOpen)}
              style={{ position: "relative" }}
            >
              <span className="ms">notifications</span>
              {unreadCount > 0 && <span className="dot" aria-hidden="true" />}
            </button>

            {notifOpen && (
              <div
                style={{
                  position: "absolute",
                  top: "calc(100% + 8px)",
                  right: 0,
                  width: 320,
                  background: "#FAF8F2",
                  border: "1px solid #D7CDBB",
                  borderRadius: 8,
                  boxShadow: "0 10px 30px rgba(0,0,0,0.15)",
                  zIndex: 999,
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    padding: "10px 14px",
                    borderBottom: "1px solid #D7CDBB",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    background: "#EDE6D8",
                  }}
                >
                  <strong style={{ fontSize: 13, color: "#1F2928" }}>Notifications ({unreadCount} unread)</strong>
                  {unreadCount > 0 && (
                    <button
                      type="button"
                      onClick={() => markNotificationsAsRead(user.id)}
                      style={{
                        background: "none",
                        border: "none",
                        color: "#0F4C4C",
                        fontSize: 11,
                        cursor: "pointer",
                        fontWeight: 600,
                      }}
                    >
                      Mark all read
                    </button>
                  )}
                </div>
                <div style={{ maxHeight: 280, overflowY: "auto" }}>
                  {notifications.length === 0 ? (
                    <div style={{ padding: "20px 14px", textAlign: "center", color: "#5F6965", fontSize: 13 }}>
                      No notifications yet
                    </div>
                  ) : (
                    notifications.map((n) => (
                      <Link
                        key={n.id}
                        to="/events"
                        onClick={() => {
                          markNotificationsAsRead(user.id);
                          setNotifOpen(false);
                        }}
                        style={{
                          display: "block",
                          padding: "12px 14px",
                          borderBottom: "1px solid #EDE6D8",
                          textDecoration: "none",
                          color: "#1F2928",
                          background: n.read ? "#FAF8F2" : "#F4EFE6",
                          borderLeft: n.read ? "3px solid transparent" : "3px solid #0F4C4C",
                        }}
                      >
                        <p style={{ margin: 0, fontSize: 13, fontWeight: n.read ? 500 : 700, lineHeight: 1.4 }}>
                          {n.message}
                        </p>
                        <span style={{ fontSize: 11, color: "#5F6965", marginTop: 4, display: "block" }}>
                          {new Date(n.date).toLocaleDateString("en-IN", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                        </span>
                      </Link>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          <Link
            to="/profile"
            aria-label="Profile"
            style={{ display: "flex", alignItems: "center", gap: 8, textDecoration: "none" }}
            title={`Logged in as ${user.name} (${user.roleTitle})`}
          >
            {user.avatarUrl ? (
              <img
                src={user.avatarUrl}
                alt={`${user.name} profile photo`}
                className="avatar"
                style={{ objectFit: "cover", width: 34, height: 34, borderRadius: "50%", border: "1.5px solid var(--deep-teal)", display: "block" }}
              />
            ) : (
              <span className="avatar">{user.initials}</span>
            )}
            <span className="topnav-user-name" style={{ fontSize: 13, fontWeight: 700, color: "var(--charcoal)" }}>
              {user.name.split(" ")[0]}
            </span>
          </Link>
          <Link
            to="/login"
            className="btn btn-primary btn-sm btn-signout"
            onClick={() => {
              logoutUser();
            }}
          >
            Sign Out
          </Link>
          <button
            className="icon-btn hamburger"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            aria-controls="mobile-navigation"
            onClick={() => setOpen((v) => !v)}
          >
            <span className="ms">{open ? "close" : "menu"}</span>
            <span className="menu-label">Menu</span>
          </button>
        </div>
      </header>

      {/* Mobile Drawer */}
      {open && (
        <nav id="mobile-navigation" className="mobile-drawer" aria-label="Mobile">
          <div className="mobile-drawer-head">
            <img
              src="/logo.png"
              alt="STEP LIVE"
              className="mobile-drawer-logo"
              width={112}
              height={48}
            />
            <button
              className="mobile-drawer-region-btn"
              onClick={() => {
                setOpen(false);
                setRegionModalOpen(true);
              }}
            >
              <span className="ms" style={{ color: "#dc2626", fontSize: 16 }}>location_on</span>
              <span>{currentRegion.name}</span>
              <span className="ms">expand_more</span>
            </button>
          </div>
          <div className="mobile-nav-grid">
            {NAV_ITEMS.map((item, index) => (
              <Link
                key={item.to}
                to={item.to}
                className={path === item.to ? "active" : undefined}
                onClick={() => setOpen(false)}
              >
                <span className="ms">{item.icon}</span>
                <span>{item.label}</span>
                <small>0{index + 1}</small>
              </Link>
            ))}
            {user?.role === "admin" && (
              <Link
                to="/admin"
                className={path === "/admin" ? "active" : undefined}
                onClick={() => setOpen(false)}
                style={{ gridColumn: "span 2", background: "var(--charcoal)", color: "#fff" }}
              >
                <span className="ms">admin_panel_settings</span>
                <span>Admin CMS Portal</span>
                <small>CMS</small>
              </Link>
            )}
          </div>
          <Link
            className="mobile-account"
            to="/profile"
            onClick={() => {
              setOpen(false);
            }}
          >
            {user.avatarUrl ? (
              <img
                src={user.avatarUrl}
                alt={`${user.name} profile photo`}
                className="avatar"
                style={{ objectFit: "cover", width: 40, height: 40, borderRadius: "50%", border: "1.5px solid var(--deep-teal)", display: "block" }}
              />
            ) : (
              <span className="avatar">{user.initials}</span>
            )}
            <span>
              <strong>{user.name}</strong>
              <small>{user.roleTitle} · {currentRegion.name}</small>
            </span>
            <span className="ms">arrow_forward</span>
          </Link>
        </nav>
      )}

      <RegionSelectModal isOpen={regionModalOpen} onClose={() => setRegionModalOpen(false)} />
    </>
  );
}

/* ─── Shared page layout ────────────────────────────────────── */
export function SidebarLayout({ children }: { children: ReactNode }) {
  return (
    <>
      <TopNav />
      <main className="page inner-page">{children}</main>
    </>
  );
}

/* ─── Status pill ───────────────────────────────────────────── */
export function StatusPill({ status }: { status: EventStatus }) {
  const cls =
    status === "Approved"
      ? "pill-approved"
      : status === "Pending"
        ? "pill-pending"
        : "pill-completed";
  const mark = status === "Approved" ? "✓" : status === "Pending" ? "⏳" : "✦";
  return (
    <span className={`pill ${cls}`}>
      {mark} {status}
    </span>
  );
}

/* ─── Icon helper ───────────────────────────────────────────── */
export function Icon({ name, fill }: { name: string; fill?: boolean }) {
  return <span className={`ms${fill ? " fill" : ""}`} aria-hidden="true">{name}</span>;
}

/* ─── Toasts ────────────────────────────────────────────────── */
export type ToastKind = "success" | "info" | "warning" | "error";
interface ToastItem {
  id: number;
  kind: ToastKind;
  message: string;
}

export function useToasts() {
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const idRef = useRef(0);

  const push = useCallback((kind: ToastKind, message: string) => {
    const id = ++idRef.current;
    setToasts((t) => [...t, { id, kind, message }]);
    window.setTimeout(() => {
      setToasts((t) => t.filter((x) => x.id !== id));
    }, 4000);
  }, []);

  const host = (
    <div className="toast-stack" role="status" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className={`toast ${t.kind}`}>
          <span className="t-dot" />
          {t.message}
        </div>
      ))}
    </div>
  );

  return { push, host };
}

/* ─── Modal ─────────────────────────────────────────────────── */
export function Modal({
  title,
  onClose,
  children,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-label={title}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="modal-head">
          <h3>{title}</h3>
          <button onClick={onClose} aria-label="Close dialog">
            ×
          </button>
        </div>
        <div className="modal-body">{children}</div>
      </div>
    </div>
  );
}

/* ─── Profile Photo Full-Size Lightbox Modal ────────────────── */
export function ProfilePhotoLightbox({
  isOpen,
  photoUrl,
  volunteerName,
  onClose,
}: {
  isOpen: boolean;
  photoUrl: string | null | undefined;
  volunteerName: string;
  onClose: () => void;
}) {
  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [isOpen, onClose]);

  if (!isOpen || !photoUrl) return null;

  return (
    <div
      className="photo-lightbox-backdrop"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label={`${volunteerName} profile photo`}
    >
      <div className="photo-lightbox-content" onClick={(e) => e.stopPropagation()}>
        <div className="photo-lightbox-header">
          <div>
            <h3 className="photo-lightbox-title" style={{ margin: 0, fontSize: 16, fontWeight: 800 }}>
              {volunteerName}
            </h3>
            <span style={{ fontSize: 12, color: "#5F6965", display: "block" }}>Volunteer Profile Photo</span>
          </div>
          <button
            type="button"
            className="photo-lightbox-close"
            onClick={onClose}
            aria-label="Close photo viewer"
          >
            ✕
          </button>
        </div>
        <div className="photo-lightbox-body">
          <img
            src={photoUrl}
            alt={`${volunteerName} profile photo`}
            className="photo-lightbox-img"
          />
        </div>
      </div>
    </div>
  );
}

/* ─── Footer ────────────────────────────────────────────────── */
export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="site-footer-brand">
        <Link to="/" aria-label="STEP LIVE home">
          <img
            src="/logo-white.png"
            alt="STEP LIVE"
            className="footer-logo"
            width={112}
            height={48}
          />
        </Link>
        <span className="footer-tagline">— Volunteer Hub</span>
      </div>
      <nav aria-label="Footer">
        <a href="mailto:support@steplive.org">Support</a>
        <Link to="/guidelines">SOPs</Link>
        <Link to="/login">Sign In</Link>
      </nav>
    </footer>
  );
}

/* ─── Provider ──────────────────────────────────────────────── */
export function StepProvider({ children }: { children: ReactNode }) {
  useEffect(() => {
    if (typeof document === "undefined") return;

    const links: Array<Partial<HTMLLinkElement> & { href: string; rel: string }> = [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Archivo+Black&family=Hind:wght@400;500;600;700&display=swap",
      },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200",
      },
    ];

    for (const link of links) {
      if (document.querySelector(`link[href="${link.href}"]`)) continue;
      const el = document.createElement("link");
      Object.assign(el, link);
      document.head.appendChild(el);
    }
  }, []);

  return <>{children}</>;
}
