import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect, useRef } from "react";
import {
  SidebarLayout,
  Icon,
  useToasts,
  LocationRegionPill,
  useActiveRegion,
  ProfilePhotoLightbox,
} from "@/components/step";
import { REGIONS, getRegionById } from "@/lib/step-data";
import { VolunteerBadgePill, VolunteerBadgeRoadmap } from "@/components/BadgeSystem";
import { useCurrentUser, updateUserProfile, useUserApplications } from "@/lib/user-db";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Volunteer Profile & Experience — STEP LIVE" },
      {
        name: "description",
        content:
          "View and update your STEP LIVE volunteer profile, emergency contacts, experience details, and verified hours.",
      },
      { property: "og:title", content: "Volunteer Profile & Experience — STEP LIVE" },
      {
        property: "og:description",
        content: "Verified volunteer service records and experience details.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const { user, refreshUser } = useCurrentUser();
  const { applications } = useUserApplications(user.id);
  const { push, host } = useToasts();
  const { selectRegion, currentRegion } = useActiveRegion();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(user.avatarUrl || null);
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);

  const [form, setForm] = useState({
    name: user.name,
    email: user.email,
    phone: user.phone,
    selectedRegionId: user.regionId || "delhi-ncr",
    city: user.city || "New Delhi",
    dob: user.basicDetails?.dob || "2000-01-01",
    emergencyContactName: user.basicDetails?.emergencyContactName || "",
    emergencyContactRelation: user.basicDetails?.emergencyContactRelation || "Family",
    emergencyContactPhone: user.basicDetails?.emergencyContactPhone || "",
    tshirtSize: user.basicDetails?.tshirtSize || "M",
    yearsExperience: user.experience?.years || "1–2 Years",
    pastOrganizations: user.experience?.pastOrganizations || "Festivals, Sports Marathons, Community NGO Drives",
    highlights: user.experience?.highlights || "Active deployment team lead for high-capacity venue gates.",
  });

  // Keep form and photo in sync if current user changes
  useEffect(() => {
    setForm({
      name: user.name,
      email: user.email,
      phone: user.phone,
      selectedRegionId: user.regionId || "delhi-ncr",
      city: user.city || "New Delhi",
      dob: user.basicDetails?.dob || "2000-01-01",
      emergencyContactName: user.basicDetails?.emergencyContactName || "",
      emergencyContactRelation: user.basicDetails?.emergencyContactRelation || "Family",
      emergencyContactPhone: user.basicDetails?.emergencyContactPhone || "",
      tshirtSize: user.basicDetails?.tshirtSize || "M",
      yearsExperience: user.experience?.years || "1–2 Years",
      pastOrganizations: user.experience?.pastOrganizations || "",
      highlights: user.experience?.highlights || "",
    });
    setPhotoPreview(user.avatarUrl || null);
  }, [user]);

  function handlePhotoSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate type: JPG, JPEG, PNG, WebP only
    const validTypes = ["image/jpeg", "image/jpg", "image/png", "image/webp"];
    if (!validTypes.includes(file.type)) {
      push("error", "Invalid file format. Please upload a JPG, JPEG, PNG, or WebP image.");
      if (fileInputRef.current) fileInputRef.current.value = "";
      return;
    }

    // Validate size: max 5 MB
    const maxSize = 5 * 1024 * 1024;
    if (file.size > maxSize) {
      push("error", "File is too large. Maximum allowed size is 5 MB.");
      if (fileInputRef.current) fileInputRef.current.value = "";
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        setPhotoPreview(dataUrl);
        updateUserProfile(user.id, { avatarUrl: dataUrl });
        refreshUser();
        push("success", "Profile picture uploaded and updated successfully!");
      }
    };
    reader.onerror = () => {
      push("error", "Failed to process photo upload. Please try again.");
    };
    reader.readAsDataURL(file);

    // Reset input value so re-selecting the same file works
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  function handleRemovePhoto() {
    setPhotoPreview(null);
    updateUserProfile(user.id, { avatarUrl: "" });
    refreshUser();
    push("info", "Profile photo removed. Initials avatar restored.");
  }

  function handleSave(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    selectRegion(form.selectedRegionId);
    const reg = getRegionById(form.selectedRegionId);

    updateUserProfile(user.id, {
      name: form.name,
      email: form.email,
      phone: form.phone,
      regionId: form.selectedRegionId,
      regionName: reg.name,
      city: form.city,
      basicDetails: {
        dob: form.dob,
        emergencyContactName: form.emergencyContactName,
        emergencyContactRelation: form.emergencyContactRelation,
        emergencyContactPhone: form.emergencyContactPhone,
        tshirtSize: form.tshirtSize,
        languages: ["English", "Hindi"],
      },
      experience: {
        years: form.yearsExperience,
        pastOrganizations: form.pastOrganizations,
        highlights: form.highlights,
      },
    });

    refreshUser();
    push("success", `Volunteer profile & experience updated successfully!`);
  }

  const pStats = [
    { label: "Active Applications", num: applications.length, icon: "assignment", cls: "green" },
    { label: "Verified Service Hours", num: user.verifiedHours, icon: "schedule", cls: "blue" },
    { label: "Completed Deployments", num: user.eventsCompleted, icon: "military_tech", cls: "purple" },
    { label: "Experience Level", num: form.yearsExperience.split(" ")[0] || "1+ Yr", icon: "history_edu", cls: "amber" },
  ];

  const currentPhoto = photoPreview || user.avatarUrl;

  return (
    <SidebarLayout>
      <div className="page-head">
        <div className="section-label">Volunteer Identity · Database Profile</div>
        <h1>Volunteer Profile &amp; Experience</h1>
        <p>Manage your profile picture, basic contact details, emergency contacts, and past volunteer experience.</p>
      </div>

      <div className="profile-head">
        {/* Profile Photo Area */}
        <div className="profile-photo-area">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handlePhotoSelect}
            accept="image/jpeg,image/jpg,image/png,image/webp"
            style={{ display: "none" }}
            aria-label="Upload profile photo"
          />

          {currentPhoto ? (
            <div style={{ position: "relative", display: "inline-block" }}>
              <button
                type="button"
                className="profile-avatar-btn"
                onClick={() => setIsLightboxOpen(true)}
                title="Click to view full-size photo"
                aria-label={`View ${user.name} full-size profile photo`}
              >
                <img
                  src={currentPhoto}
                  alt={`${user.name} profile photo`}
                  className="profile-avatar-img"
                />
                <div className="profile-avatar-overlay">
                  <Icon name="zoom_in" />
                  <span>View</span>
                </div>
              </button>
              <button
                type="button"
                className="avatar-cam-badge"
                onClick={(e) => {
                  e.stopPropagation();
                  fileInputRef.current?.click();
                }}
                title="Change profile photo"
                aria-label="Change profile photo"
              >
                <Icon name="photo_camera" />
              </button>
            </div>
          ) : (
            <div style={{ position: "relative", display: "inline-block" }}>
              <div className="profile-avatar-initials-wrap">
                <span className="profile-avatar-initials">{user.initials}</span>
              </div>
              <button
                type="button"
                className="avatar-cam-badge"
                onClick={() => fileInputRef.current?.click()}
                title="Upload profile photo"
                aria-label="Upload profile photo"
              >
                <Icon name="add_a_photo" />
              </button>
            </div>
          )}

          {/* Photo Action Buttons */}
          <div className="profile-avatar-actions">
            {currentPhoto ? (
              <>
                <button
                  type="button"
                  className="btn btn-outline btn-sm"
                  onClick={() => fileInputRef.current?.click()}
                  style={{ fontSize: 11, padding: "3px 8px" }}
                >
                  <Icon name="edit" /> Change Photo
                </button>
                <button
                  type="button"
                  className="btn btn-outline btn-sm"
                  onClick={handleRemovePhoto}
                  style={{ fontSize: 11, padding: "3px 8px", color: "#dc2626", borderColor: "#fca5a5" }}
                >
                  <Icon name="delete" /> Remove Photo
                </button>
              </>
            ) : (
              <button
                type="button"
                className="btn btn-primary btn-sm"
                onClick={() => fileInputRef.current?.click()}
                style={{ fontSize: 11, padding: "4px 10px" }}
              >
                <Icon name="upload" /> Upload Photo
              </button>
            )}
          </div>
        </div>

        <div style={{ flex: 1 }}>
          <h2 style={{ fontSize: 22, fontWeight: 900 }}>{user.name}</h2>
          <div style={{ color: "var(--on-surface-variant)", fontSize: 14 }}>
            {user.roleTitle} · {currentRegion.name} ({user.city}) · Member since {user.memberSince}
          </div>
          <div style={{ marginTop: 8, display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
            <VolunteerBadgePill tier="Bronze" size="md" />
            <span className="verified-badge">
              <Icon name="verified" fill /> Verified Volunteer
            </span>
            <LocationRegionPill />
            <span className="tag">{user.email}</span>
            <span className="tag">{user.phone}</span>
          </div>
        </div>
      </div>

      <div className="stat-grid" style={{ marginBottom: 20 }}>
        {pStats.map((s) => (
          <div key={s.label} className="stat-card" style={{ cursor: "default" }}>
            <div className={`stat-icon ${s.cls}`}>
              <Icon name={s.icon} fill />
            </div>
            <div className="stat-num">{s.num}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div style={{ marginBottom: 32 }}>
        <section className="panel" aria-label="Edit volunteer profile and experience">
          <h3>Volunteer Profile &amp; Experience Details</h3>
          <p style={{ marginBottom: 18 }}>
            Keep your profile and experience history current for upcoming event applications.
          </p>

          <form onSubmit={handleSave}>
            {/* Section 1: Basic Details & Contact */}
            <h4 style={{ margin: "0 0 10px", fontSize: 13, textTransform: "uppercase", color: "var(--olive)", fontWeight: 800 }}>
              1. Basic Information &amp; Emergency Contact
            </h4>

            <div className="form-row">
              <div className="field">
                <label htmlFor="p-name">Full Name</label>
                <input
                  id="p-name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  required
                />
              </div>
              <div className="field">
                <label htmlFor="p-email">Email Address</label>
                <input
                  id="p-email"
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="form-row">
              <div className="field">
                <label htmlFor="p-phone">Phone Number</label>
                <input
                  id="p-phone"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                />
              </div>
              <div className="field">
                <label htmlFor="p-dob">Date of Birth</label>
                <input
                  id="p-dob"
                  type="date"
                  value={form.dob}
                  onChange={(e) => setForm({ ...form, dob: e.target.value })}
                />
              </div>
            </div>

            <div className="form-row">
              <div className="field">
                <label htmlFor="p-tshirt">T-Shirt Size</label>
                <select
                  id="p-tshirt"
                  value={form.tshirtSize}
                  onChange={(e) => setForm({ ...form, tshirtSize: e.target.value as "S" | "M" | "L" | "XL" | "XXL" })}
                >
                  <option value="S">Small (S)</option>
                  <option value="M">Medium (M)</option>
                  <option value="L">Large (L)</option>
                  <option value="XL">Extra Large (XL)</option>
                  <option value="XXL">Double XL (XXL)</option>
                </select>
              </div>
              <div className="field">
                <label htmlFor="p-emg-name">Emergency Contact Name</label>
                <input
                  id="p-emg-name"
                  value={form.emergencyContactName}
                  onChange={(e) => setForm({ ...form, emergencyContactName: e.target.value })}
                  placeholder="e.g. Sunil Sharma"
                />
              </div>
            </div>

            <div className="form-row">
              <div className="field">
                <label htmlFor="p-emg-rel">Contact Relationship</label>
                <input
                  id="p-emg-rel"
                  value={form.emergencyContactRelation}
                  onChange={(e) => setForm({ ...form, emergencyContactRelation: e.target.value })}
                  placeholder="e.g. Parent / Spouse / Sibling"
                />
              </div>
              <div className="field">
                <label htmlFor="p-emg-phone">Emergency Contact Phone</label>
                <input
                  id="p-emg-phone"
                  value={form.emergencyContactPhone}
                  onChange={(e) => setForm({ ...form, emergencyContactPhone: e.target.value })}
                  placeholder="e.g. 9811099881"
                />
              </div>
            </div>

            {/* Region / City Selector Field */}
            <div className="form-row">
              <div className="field">
                <label htmlFor="p-region">Primary Location / Hub</label>
                <select
                  id="p-region"
                  value={form.selectedRegionId}
                  onChange={(e) => setForm({ ...form, selectedRegionId: e.target.value })}
                  style={{
                    padding: "8px 10px",
                    border: "1px solid var(--outline)",
                    background: "var(--surface)",
                    fontFamily: "var(--font-head)",
                    fontSize: 13,
                  }}
                >
                  {REGIONS.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.name} — {r.state}
                    </option>
                  ))}
                </select>
              </div>
              <div className="field">
                <label htmlFor="p-city">Local City / Area</label>
                <input
                  id="p-city"
                  value={form.city}
                  onChange={(e) => setForm({ ...form, city: e.target.value })}
                  placeholder="e.g. South Delhi, Bandra, Koramangala"
                />
              </div>
            </div>

            {/* Section 2: Experience Section */}
            <h4 style={{ margin: "16px 0 10px", fontSize: 13, textTransform: "uppercase", color: "var(--olive)", fontWeight: 800 }}>
              2. Volunteer Experience
            </h4>

            <div className="form-row">
              <div className="field">
                <label htmlFor="p-years">Years of Volunteering</label>
                <select
                  id="p-years"
                  value={form.yearsExperience}
                  onChange={(e) => setForm({ ...form, yearsExperience: e.target.value })}
                >
                  <option value="Fresh Volunteer (0-1 yr)">Fresh Volunteer (0–1 yr)</option>
                  <option value="1–2 Years">1–2 Years</option>
                  <option value="3+ Years">3+ Years (Senior)</option>
                  <option value="5+ Years Operations Lead">5+ Years Operations Lead</option>
                </select>
              </div>
              <div className="field">
                <label htmlFor="p-orgs">Past Events / Organizations Worked With</label>
                <input
                  id="p-orgs"
                  value={form.pastOrganizations}
                  onChange={(e) => setForm({ ...form, pastOrganizations: e.target.value })}
                  placeholder="e.g. Sunburn Festival, Delhi Marathon, College Fest"
                />
              </div>
            </div>

            <div className="field">
              <label htmlFor="p-high">Key Past Volunteer Highlight / Achievement</label>
              <textarea
                id="p-high"
                rows={2}
                value={form.highlights}
                onChange={(e) => setForm({ ...form, highlights: e.target.value })}
                placeholder="Share a key achievement or highlight from past volunteer deployments..."
              />
            </div>

            <button type="submit" className="btn btn-primary" style={{ marginTop: 8 }}>
              Save Profile &amp; Experience
            </button>
          </form>
        </section>
      </div>

      <div style={{ marginTop: 24, marginBottom: 40 }}>
        <div className="section-head-row">
          <div>
            <div className="section-label">Ranks &amp; Privileges</div>
            <h2 className="section-title" style={{ marginBottom: 0 }}>
              Volunteer Badges &amp; Progression
            </h2>
          </div>
          <VolunteerBadgePill tier="Bronze" size="md" />
        </div>
        <VolunteerBadgeRoadmap initialEvents={user.eventsCompleted} />
      </div>

      <ProfilePhotoLightbox
        isOpen={isLightboxOpen}
        photoUrl={currentPhoto}
        volunteerName={user.name}
        onClose={() => setIsLightboxOpen(false)}
      />

      {host}
    </SidebarLayout>
  );
}
