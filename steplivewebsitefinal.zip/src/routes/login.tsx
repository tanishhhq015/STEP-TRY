import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { TopNav, useToasts, Icon } from "@/components/step";
import { REGIONS, getRegionById } from "@/lib/step-data";
import {
  getAllUsers,
  setCurrentUser,
  registerVolunteerUser,
} from "@/lib/user-db";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Sign In & Volunteer Registration — STEP LIVE" },
      {
        name: "description",
        content:
          "Secure volunteer login and registration for STEP LIVE event operations across India.",
      },
      { property: "og:title", content: "Sign In & Volunteer Registration — STEP LIVE" },
      {
        property: "og:description",
        content: "Secure login and volunteer registration portal.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const [tab, setTab] = useState<"signin" | "register">("signin");
  const [regStep, setRegStep] = useState<1 | 2>(1);

  // Sign in state
  const [signInEmail, setSignInEmail] = useState("");
  const [signInPassword, setSignInPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Registration step 1 state
  const [regForm, setRegForm] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    regionId: "delhi-ncr",
    city: "New Delhi",
  });

  // Registration step 2 state (Profile & Experience)
  const [profileForm, setProfileForm] = useState({
    dob: "2001-05-12",
    emergencyContactName: "",
    emergencyContactRelation: "Parent",
    emergencyContactPhone: "",
    tshirtSize: "L" as "S" | "M" | "L" | "XL" | "XXL",
    languages: "English, Hindi",
    yearsExperience: "1–2 Years",
    pastOrganizations: "College Annual Fest, City Marathon, Local NGO Youth Wing",
    highlights: "Assisted entry gate logistics and spectator safety at campus fest with 3,000+ attendees.",
  });

  const { push, host } = useToasts();
  const navigate = useNavigate();

  function handleSignIn(e: React.FormEvent) {
    e.preventDefault();
    setIsSubmitting(true);

    const emailTrimmed = signInEmail.trim().toLowerCase();
    const passTrimmed = signInPassword.trim();

    const users = getAllUsers();
    const match = users.find((u) => u.email.toLowerCase() === emailTrimmed);

    if (!match) {
      push("error", "Account not found. Please verify your email or register below.");
      setIsSubmitting(false);
      return;
    }

    // Verify password securely
    if (match.password && match.password !== passTrimmed) {
      push("error", "Incorrect password. Please try again.");
      setIsSubmitting(false);
      return;
    }

    setCurrentUser(match);

    if (match.role === "admin") {
      push("success", `Welcome, ${match.name}! Operations Admin CMS unlocked.`);
      window.setTimeout(() => navigate({ to: "/admin" }), 600);
    } else {
      push("success", `Welcome back, ${match.name}! Signed in successfully.`);
      window.setTimeout(() => navigate({ to: "/" }), 600);
    }
  }

  function handleStep1Next(e: React.FormEvent) {
    e.preventDefault();
    if (!regForm.name || !regForm.email || !regForm.phone || !regForm.password) {
      push("error", "Please fill in all required account fields.");
      return;
    }
    setRegStep(2);
    push("info", "Account created! Now complete your volunteer profile & experience details.");
  }

  function handleCompleteRegistration(skipExperience = false) {
    const regionObj = getRegionById(regForm.regionId);

    const user = registerVolunteerUser({
      name: regForm.name.trim(),
      email: regForm.email.trim(),
      phone: regForm.phone.trim(),
      password: regForm.password || "pass123",
      regionId: regForm.regionId,
      city: regForm.city || regionObj?.name || "Delhi NCR",
      basicDetails: skipExperience
        ? undefined
        : {
            dob: profileForm.dob,
            emergencyContactName: profileForm.emergencyContactName || "Guardian",
            emergencyContactRelation: profileForm.emergencyContactRelation,
            emergencyContactPhone: profileForm.emergencyContactPhone || regForm.phone,
            tshirtSize: profileForm.tshirtSize,
            languages: profileForm.languages.split(",").map((s) => s.trim()).filter(Boolean),
          },
      experience: skipExperience
        ? undefined
        : {
            years: profileForm.yearsExperience,
            pastOrganizations: profileForm.pastOrganizations,
            highlights: profileForm.highlights,
          },
    });

    setCurrentUser(user);
    push(
      "success",
      `Welcome to STEP LIVE, ${user.name}! Your volunteer profile is ready. Opening upcoming events...`,
    );

    window.setTimeout(() => {
      navigate({ to: "/" });
    }, 800);
  }

  return (
    <>
      <TopNav />
      <main className="login-wrap">
        <div className="login-card" style={{ maxWidth: tab === "register" && regStep === 2 ? 640 : 440 }}>
          <div className="login-head">
            <img
              src="/logo-white.png"
              alt="STEP LIVE"
              className="login-logo"
              width={170}
              height={73}
            />
            <p style={{ margin: "4px 0 0", color: "#e3e2d7", fontSize: 13 }}>
              {tab === "signin"
                ? "Secure Volunteer & Admin Sign In"
                : regStep === 1
                ? "Step 1: Register to Volunteer"
                : "Step 2: Basic Details & Experience Section"}
            </p>
          </div>

          <div className="login-body">
            {/* Tabs */}
            <div className="login-tabs" role="tablist">
              <button
                role="tab"
                aria-selected={tab === "signin"}
                className={tab === "signin" ? "active" : ""}
                onClick={() => {
                  setTab("signin");
                  setRegStep(1);
                }}
              >
                Sign In
              </button>
              <button
                role="tab"
                aria-selected={tab === "register"}
                className={tab === "register" ? "active" : ""}
                onClick={() => {
                  setTab("register");
                }}
              >
                Register to Volunteer
              </button>
            </div>

            {/* ─── TAB: SECURE SIGN IN ────────────────────────────────── */}
            {tab === "signin" && (
              <>
                <form onSubmit={handleSignIn}>
                  <div className="field">
                    <label htmlFor="email">Email Address</label>
                    <input
                      id="email"
                      name="email"
                      type="email"
                      required
                      value={signInEmail}
                      onChange={(e) => setSignInEmail(e.target.value)}
                      placeholder="e.g. tanishq@steplive.org or admin@steplive.org"
                    />
                  </div>
                  <div className="field">
                    <label htmlFor="password">Password</label>
                    <input
                      id="password"
                      name="password"
                      type="password"
                      required
                      value={signInPassword}
                      onChange={(e) => setSignInPassword(e.target.value)}
                      placeholder="Enter your account password"
                    />
                  </div>

                  <button
                    type="submit"
                    className="btn btn-accent"
                    disabled={isSubmitting}
                    style={{ width: "100%", justifyContent: "center", marginTop: 10 }}
                  >
                    {isSubmitting ? "Authenticating..." : "Sign In Securely"}
                  </button>
                </form>

                <div
                  style={{
                    marginTop: 18,
                    padding: "10px 12px",
                    background: "var(--surface-container)",
                    borderRadius: 8,
                    fontSize: 12,
                    color: "var(--on-surface-variant)",
                    lineHeight: 1.4,
                  }}
                >
                  <strong style={{ color: "var(--charcoal)" }}>Sign-In Assistance:</strong>
                  <br />
                  • <strong>Volunteer Account:</strong> <code>tanishq@steplive.org</code> (pw: <code>password123</code>)
                  <br />
                  • <strong>Admin CMS Portal:</strong> <code>admin@steplive.org</code> (pw: <code>admin2026</code>)
                </div>

                <div className="login-foot">
                  New volunteer?{" "}
                  <button
                    type="button"
                    style={{ background: "none", border: "none", color: "var(--olive)", fontWeight: 700, cursor: "pointer", textDecoration: "underline" }}
                    onClick={() => {
                      setTab("register");
                      setRegStep(1);
                    }}
                  >
                    Register here
                  </button>
                </div>
              </>
            )}

            {/* ─── TAB: REGISTER TO VOLUNTEER ─────────────────────────── */}
            {tab === "register" && (
              <>
                {/* Onboarding progress bar */}
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span
                      style={{
                        width: 24,
                        height: 24,
                        borderRadius: "50%",
                        background: regStep === 1 ? "var(--olive)" : "var(--charcoal)",
                        color: "#fff",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: 12,
                        fontWeight: 700,
                      }}
                    >
                      1
                    </span>
                    <span style={{ fontSize: 13, fontWeight: regStep === 1 ? 800 : 500, color: "var(--charcoal)" }}>
                      Account Info
                    </span>
                  </div>
                  <span style={{ color: "var(--outline)", fontSize: 16 }}>→</span>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span
                      style={{
                        width: 24,
                        height: 24,
                        borderRadius: "50%",
                        background: regStep === 2 ? "var(--olive)" : "var(--surface-container-high)",
                        color: regStep === 2 ? "#fff" : "var(--on-surface-variant)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: 12,
                        fontWeight: 700,
                      }}
                    >
                      2
                    </span>
                    <span style={{ fontSize: 13, fontWeight: regStep === 2 ? 800 : 500, color: "var(--charcoal)" }}>
                      Profile &amp; Experience
                    </span>
                  </div>
                </div>

                {/* Step 1: Account info */}
                {regStep === 1 && (
                  <form onSubmit={handleStep1Next}>
                    <div className="field">
                      <label htmlFor="reg-name">Full Name *</label>
                      <input
                        id="reg-name"
                        required
                        value={regForm.name}
                        onChange={(e) => setRegForm({ ...regForm, name: e.target.value })}
                        placeholder="e.g. Rahul Sharma"
                      />
                    </div>
                    <div className="form-row">
                      <div className="field">
                        <label htmlFor="reg-email">Email Address *</label>
                        <input
                          id="reg-email"
                          type="email"
                          required
                          value={regForm.email}
                          onChange={(e) => setRegForm({ ...regForm, email: e.target.value })}
                          placeholder="rahul@example.com"
                        />
                      </div>
                      <div className="field">
                        <label htmlFor="reg-phone">Phone Number *</label>
                        <input
                          id="reg-phone"
                          type="tel"
                          required
                          value={regForm.phone}
                          onChange={(e) => setRegForm({ ...regForm, phone: e.target.value })}
                          placeholder="9876543210"
                        />
                      </div>
                    </div>
                    <div className="field">
                      <label htmlFor="reg-pass">Create Password *</label>
                      <input
                        id="reg-pass"
                        type="password"
                        required
                        minLength={6}
                        value={regForm.password}
                        onChange={(e) => setRegForm({ ...regForm, password: e.target.value })}
                        placeholder="••••••••"
                      />
                    </div>
                    <div className="form-row">
                      <div className="field">
                        <label htmlFor="reg-region">Primary Hub (India)</label>
                        <select
                          id="reg-region"
                          value={regForm.regionId}
                          onChange={(e) => {
                            const r = getRegionById(e.target.value);
                            setRegForm({ ...regForm, regionId: e.target.value, city: r.name });
                          }}
                        >
                          {REGIONS.map((r) => (
                            <option key={r.id} value={r.id}>
                              {r.name} — {r.state}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="field">
                        <label htmlFor="reg-city">City / Area</label>
                        <input
                          id="reg-city"
                          value={regForm.city}
                          onChange={(e) => setRegForm({ ...regForm, city: e.target.value })}
                          placeholder="e.g. South Delhi / Bandra"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="btn btn-accent"
                      style={{ width: "100%", justifyContent: "center", marginTop: 8 }}
                    >
                      Next: Fill Profile &amp; Experience Section →
                    </button>
                  </form>
                )}

                {/* Step 2: Basic Details & Experience */}
                {regStep === 2 && (
                  <div>
                    <div
                      style={{
                        background: "var(--surface-container)",
                        padding: "10px 14px",
                        borderRadius: 8,
                        marginBottom: 16,
                        fontSize: 13,
                        color: "var(--charcoal)",
                      }}
                    >
                      Registering as: <strong>{regForm.name}</strong> ({regForm.email}) · <em>{regForm.city}</em>
                    </div>

                    {/* Basic Details Section */}
                    <div style={{ marginBottom: 18 }}>
                      <h4 style={{ margin: "0 0 10px", fontSize: 14, textTransform: "uppercase", color: "var(--olive)", fontWeight: 800, display: "flex", alignItems: "center", gap: 6 }}>
                        <Icon name="badge" /> 1. Basic Details &amp; Emergency Contact
                      </h4>
                      <div className="form-row">
                        <div className="field">
                          <label htmlFor="p-dob">Date of Birth</label>
                          <input
                            id="p-dob"
                            type="date"
                            value={profileForm.dob}
                            onChange={(e) => setProfileForm({ ...profileForm, dob: e.target.value })}
                          />
                        </div>
                        <div className="field">
                          <label htmlFor="p-tshirt">T-Shirt Size</label>
                          <select
                            id="p-tshirt"
                            value={profileForm.tshirtSize}
                            onChange={(e) =>
                              setProfileForm({
                                ...profileForm,
                                tshirtSize: e.target.value as "S" | "M" | "L" | "XL" | "XXL",
                              })
                            }
                          >
                            <option value="S">Small (S)</option>
                            <option value="M">Medium (M)</option>
                            <option value="L">Large (L)</option>
                            <option value="XL">Extra Large (XL)</option>
                            <option value="XXL">Double XL (XXL)</option>
                          </select>
                        </div>
                      </div>

                      <div className="form-row">
                        <div className="field">
                          <label htmlFor="p-emg-name">Emergency Contact Person</label>
                          <input
                            id="p-emg-name"
                            value={profileForm.emergencyContactName}
                            onChange={(e) => setProfileForm({ ...profileForm, emergencyContactName: e.target.value })}
                            placeholder="e.g. Sunil Sharma"
                          />
                        </div>
                        <div className="field">
                          <label htmlFor="p-emg-phone">Emergency Phone</label>
                          <input
                            id="p-emg-phone"
                            value={profileForm.emergencyContactPhone}
                            onChange={(e) => setProfileForm({ ...profileForm, emergencyContactPhone: e.target.value })}
                            placeholder="e.g. 9811099881"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Experience Section */}
                    <div style={{ marginBottom: 20 }}>
                      <h4 style={{ margin: "0 0 10px", fontSize: 14, textTransform: "uppercase", color: "var(--olive)", fontWeight: 800, display: "flex", alignItems: "center", gap: 6 }}>
                        <Icon name="history_edu" /> 2. Volunteer Experience Section
                      </h4>

                      <div className="form-row">
                        <div className="field">
                          <label htmlFor="p-years">Years of Experience</label>
                          <select
                            id="p-years"
                            value={profileForm.yearsExperience}
                            onChange={(e) => setProfileForm({ ...profileForm, yearsExperience: e.target.value })}
                          >
                            <option value="Fresh Volunteer (0-1 yr)">Fresh Volunteer (0–1 yr)</option>
                            <option value="1–2 Years">1–2 Years</option>
                            <option value="3+ Years">3+ Years (Senior)</option>
                            <option value="5+ Years Operations Lead">5+ Years Operations Lead</option>
                          </select>
                        </div>
                        <div className="field">
                          <label htmlFor="p-orgs">Past Events / Organizations Worked With</label>
                          <input
                            id="p-orgs"
                            value={profileForm.pastOrganizations}
                            onChange={(e) => setProfileForm({ ...profileForm, pastOrganizations: e.target.value })}
                            placeholder="e.g. Sunburn Festival, Delhi Marathon, College Cultural Fest"
                          />
                        </div>
                      </div>

                      <div className="field">
                        <label htmlFor="p-high">Key Past Volunteer Highlight / Achievement</label>
                        <textarea
                          id="p-high"
                          rows={2}
                          value={profileForm.highlights}
                          onChange={(e) => setProfileForm({ ...profileForm, highlights: e.target.value })}
                          placeholder="e.g. Managed registration desk for 2,000 guests with zero bottlenecks."
                        />
                      </div>
                    </div>

                    <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
                      <button
                        type="button"
                        className="btn btn-outline"
                        onClick={() => setRegStep(1)}
                        style={{ flex: 1, justifyContent: "center" }}
                      >
                        ← Back
                      </button>
                      <button
                        type="button"
                        className="btn btn-accent"
                        onClick={() => handleCompleteRegistration(false)}
                        style={{ flex: 2, justifyContent: "center" }}
                      >
                        Complete Registration &amp; Open Home Page →
                      </button>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
        {host}
      </main>
    </>
  );
}
