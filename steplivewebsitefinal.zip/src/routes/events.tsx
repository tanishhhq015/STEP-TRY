import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { SidebarLayout, StatusPill, Icon, Modal, LocationRegionPill, useToasts } from "@/components/step";
import { REGIONS, type EventStatus } from "@/lib/step-data";
import { useEvents, ExtendedStepEvent } from "@/lib/events-db";
import { useCurrentUser, useUserApplications, submitApplication, withdrawApplication } from "@/lib/user-db";

type Filter = "All" | EventStatus;

export const Route = createFileRoute("/events")({
  validateSearch: (search: Record<string, unknown>): { filter?: Filter; id?: string; region?: string } => ({
    filter: (search.filter as Filter) || undefined,
    id: (search.id as string) || undefined,
    region: (search.region as string) || undefined,
  }),
  head: () => ({
    meta: [
      { title: "Volunteer Events & Deployments — STEP LIVE" },
      {
        name: "description",
        content:
          "Browse STEP LIVE volunteer event assignments across Indian cities: filter by status and region, view event details, and submit your profile for admin review.",
      },
      { property: "og:title", content: "Volunteer Events & Deployments — STEP LIVE" },
      {
        property: "og:description",
        content: "Filterable list of volunteer event assignments and deployments across India.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: EventsPage,
});

const STATUS_FILTERS: Filter[] = ["All", "Approved", "Pending", "Completed"];

const POPULAR_REGIONS = [
  { id: "all", label: "All Regions" },
  { id: "delhi-ncr", label: "Delhi NCR" },
  { id: "mumbai", label: "Mumbai" },
  { id: "kolkata", label: "Kolkata" },
  { id: "bengaluru", label: "Bengaluru" },
  { id: "hyderabad", label: "Hyderabad" },
  { id: "chandigarh", label: "Chandigarh" },
  { id: "chennai", label: "Chennai" },
  { id: "pune", label: "Pune" },
  { id: "jaipur", label: "Jaipur" },
  { id: "goa", label: "Goa" },
  { id: "ahmedabad", label: "Ahmedabad" },
];

function EventsPage() {
  const { filter, id, region } = Route.useSearch();
  const navigate = useNavigate({ from: "/events" });
  const { events } = useEvents();
  const { user } = useCurrentUser();
  const { applications, refresh } = useUserApplications(user.id);
  const { push, host } = useToasts();

  const [selected, setSelected] = useState<ExtendedStepEvent | null>(
    id ? (events.find((e) => e.id === id) ?? null) : null,
  );
  const [eventToApply, setEventToApply] = useState<ExtendedStepEvent | null>(null);

  const activeStatus: Filter = filter ?? "All";
  const activeRegion = region ?? "all";

  const list = events.filter((e) => {
    const matchStatus = activeStatus === "All" || e.status === activeStatus;
    const matchRegion = activeRegion === "all" || e.region === activeRegion;
    return matchStatus && matchRegion;
  });

  function handleConfirmJoin() {
    if (!eventToApply) return;
    submitApplication(user, eventToApply);
    const eventName = eventToApply.title;
    setEventToApply(null);
    refresh();
    push("success", `Your application for ${eventName} has been submitted for admin review.`);
  }

  function handleWithdraw(appId: string, eventTitle: string) {
    if (confirm(`Are you sure you want to withdraw your application for "${eventTitle}"?`)) {
      withdrawApplication(appId);
      refresh();
      push("info", `Application for ${eventTitle} has been withdrawn.`);
    }
  }

  return (
    <SidebarLayout>
      <div className="page-head">
        <div className="page-head-row">
          <div>
            <div className="section-label">Deployments · India</div>
            <h1>Events &amp; Deployments</h1>
            <p>
              Volunteer event assignments across India. Filter by status or regional hubs, and join deployments with your saved profile.
            </p>
          </div>
          <LocationRegionPill />
        </div>
      </div>

      {/* Region Filter Bar */}
      <div className="events-filter-section">
        <div className="filter-group">
          <span className="filter-group-label">
            <Icon name="location_on" /> City / Region:
          </span>
          <div className="chip-row region-chip-row" role="tablist" aria-label="Filter events by Indian Region">
            {POPULAR_REGIONS.map((r) => {
              const isSelected = activeRegion === r.id;
              return (
                <button
                  key={r.id}
                  role="tab"
                  aria-selected={isSelected}
                  className={`chip chip-region ${isSelected ? "active" : ""}`}
                  onClick={() =>
                    navigate({
                      search: {
                        filter: activeStatus === "All" ? undefined : activeStatus,
                        region: r.id === "all" ? undefined : r.id,
                      },
                    })
                  }
                >
                  <span>{r.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Status Filter Bar */}
        <div className="filter-group">
          <span className="filter-group-label">
            <Icon name="filter_list" /> Status:
          </span>
          <div className="chip-row" role="tablist" aria-label="Filter events by Status">
            {STATUS_FILTERS.map((f) => (
              <button
                key={f}
                role="tab"
                aria-selected={activeStatus === f}
                className={`chip${activeStatus === f ? " active" : ""}`}
                onClick={() =>
                  navigate({
                    search: {
                      filter: f === "All" ? undefined : f,
                      region: activeRegion === "all" ? undefined : activeRegion,
                    },
                  })
                }
              >
                {f}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Events Grid */}
      <div className="event-grid" style={{ gridTemplateColumns: "1fr" }}>
        {list.map((ev) => {
          const regObj = REGIONS.find((r) => r.id === ev.region);
          const userApp = applications.find((a) => a.eventId === ev.id);

          return (
            <article key={ev.id} className="event-card">
              <div className="ec-top">
                <div className="ec-title-wrap">
                  <h3>{ev.title}</h3>
                  <div className="ec-badges-row">
                    <span className="region-tag">
                      <Icon name="location_on" /> {regObj?.name || "India"}
                    </span>
                    <span className="tag">{ev.category}</span>
                  </div>
                </div>
                <StatusPill status={ev.status} />
              </div>
              <div className="event-meta">
                <span>
                  <Icon name="calendar_month" /> {ev.date}
                </span>
                <span>
                  <Icon name="location_on" /> {ev.location}
                </span>
                <span>
                  <Icon name="badge" /> Role: {ev.role}
                </span>
                <span>
                  <Icon name="person" /> Volunteer capacity: {ev.teamSize || ev.capacity || 20}
                </span>
              </div>
              <div className="ec-footer">
                <div className="ec-tags">
                  {ev.tags.map((t) => (
                    <span key={t} className="ec-tag-item">
                      #{t}
                    </span>
                  ))}
                </div>
                <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  {userApp ? (
                    <span
                      style={{
                        fontSize: 12,
                        fontWeight: 800,
                        padding: "4px 10px",
                        borderRadius: 6,
                        background: userApp.status === "Approved" ? "#EDE6D8" : userApp.status === "Declined" ? "#FEE2E2" : "#FAF8F2",
                        color: userApp.status === "Approved" ? "var(--olive)" : userApp.status === "Declined" ? "#991B1B" : "var(--charcoal)",
                        border: "1px solid var(--outline)",
                      }}
                    >
                      Application {userApp.status}
                    </span>
                  ) : (
                    <button
                      className="btn btn-accent btn-sm"
                      onClick={() => setEventToApply(ev)}
                    >
                      <Icon name="how_to_reg" /> Join Event
                    </button>
                  )}
                  <button className="btn btn-ghost btn-sm" onClick={() => setSelected(ev)}>
                    View Details →
                  </button>
                </div>
              </div>
            </article>
          );
        })}
        {list.length === 0 && (
          <div className="panel" style={{ textAlign: "center", padding: "36px 20px" }}>
            <span className="ms" style={{ fontSize: 36, color: "var(--outline)", display: "block", marginBottom: 8 }}>
              location_off
            </span>
            <h4>No deployments found in this filter</h4>
            <p style={{ color: "var(--on-surface-variant)", margin: "4px 0 16px" }}>
              Try selecting &quot;All Regions&quot; or adjusting your status filter.
            </p>
            <button
              className="btn btn-outline btn-sm"
              onClick={() => navigate({ search: {} })}
            >
              Reset All Filters
            </button>
          </div>
        )}
      </div>

      {/* Event Details Modal */}
      {selected && (
        <Modal title={selected.title} onClose={() => setSelected(null)}>
          <div style={{ marginBottom: 14, display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
            <StatusPill status={selected.status} />
            <span className="region-tag">
              <Icon name="location_on" /> {REGIONS.find((r) => r.id === selected.region)?.name}
            </span>
            <span className="tag">{selected.category}</span>
          </div>
          <div className="cc-row">
            <span className="k">Dates</span>
            <span className="v">{selected.date}</span>
          </div>
          <div className="cc-row">
            <span className="k">Venue &amp; Location</span>
            <span className="v">{selected.location}</span>
          </div>
          <div className="cc-row">
            <span className="k">Region Hub</span>
            <span className="v">
              {REGIONS.find((r) => r.id === selected.region)?.hubName}
            </span>
          </div>
          <div className="cc-row">
            <span className="k">Role Requirement</span>
            <span className="v">{selected.role}</span>
          </div>
          <div className="cc-row">
            <span className="k">On-Site Coordinator / Lead</span>
            <span className="v">{selected.eventLead || selected.coordinator || "STEP Operations Desk"}</span>
          </div>
          <div className="cc-row">
            <span className="k">Volunteer Capacity</span>
            <span className="v">{selected.teamSize || selected.capacity || 20} Open positions</span>
          </div>

          <div style={{ marginTop: 18, display: "flex", justifyContent: "flex-end", gap: 10 }}>
            {(() => {
              const userApp = applications.find((a) => a.eventId === selected.id);
              if (userApp) {
                return (
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span style={{ fontWeight: 800, fontSize: 13, color: "var(--olive)" }}>
                      Application {userApp.status}
                    </span>
                    {userApp.status === "Pending" && (
                      <button
                        type="button"
                        className="btn btn-outline btn-sm"
                        style={{ color: "#dc2626", borderColor: "#fca5a5" }}
                        onClick={() => {
                          handleWithdraw(userApp.applicationId, selected.title);
                          setSelected(null);
                        }}
                      >
                        Withdraw Application
                      </button>
                    )}
                  </div>
                );
              }
              return (
                <button
                  type="button"
                  className="btn btn-accent"
                  onClick={() => {
                    const ev = selected;
                    setSelected(null);
                    setEventToApply(ev);
                  }}
                >
                  <Icon name="how_to_reg" /> Join Event
                </button>
              );
            })()}
          </div>
        </Modal>
      )}

      {/* Direct Application Confirmation Modal */}
      {eventToApply && (
        <Modal
          title={`Join Event: ${eventToApply.title}`}
          onClose={() => setEventToApply(null)}
        >
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div
              style={{
                background: "var(--surface-container)",
                padding: "14px 16px",
                borderRadius: 8,
                fontSize: 14,
                display: "flex",
                flexDirection: "column",
                gap: 6,
              }}
            >
              <div>
                <strong>Event:</strong> {eventToApply.title}
              </div>
              <div>
                <strong>Date:</strong> {eventToApply.date}
              </div>
              <div>
                <strong>Venue:</strong> {eventToApply.location}
              </div>
            </div>

            <div
              style={{
                background: "var(--surface-low)",
                border: "1px solid var(--outline)",
                padding: "12px 16px",
                borderRadius: 8,
                fontSize: 13.5,
                color: "var(--on-surface)",
              }}
            >
              <Icon name="info" /> Your saved STEP profile will be sent to the admin for review.
            </div>

            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 8 }}>
              <button
                type="button"
                className="btn btn-outline"
                onClick={() => setEventToApply(null)}
              >
                Cancel
              </button>
              <button
                type="button"
                className="btn btn-accent"
                onClick={handleConfirmJoin}
              >
                Confirm &amp; Join Event
              </button>
            </div>
          </div>
        </Modal>
      )}

      {host}
    </SidebarLayout>
  );
}
