import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";

export const Route = createFileRoute("/mobile")({
  head: () => ({
    meta: [
      { title: "Mobile Layout View — STEP LIVE Volunteer Hub" },
      {
        name: "description",
        content:
          "Mobile interface look of the STEP LIVE volunteer website: shifts, SOPs, badge system, and credentials.",
      },
      { property: "og:title", content: "Mobile Layout View — STEP LIVE" },
      { property: "og:type", content: "website" },
    ],
  }),
  component: MobilePreviewPage,
});

type DeviceType = "iphone" | "pixel" | "galaxy" | "fluid";

const PAGES = [
  { path: "/", label: "Home (Overview)", icon: "grid_view" },
  { path: "/events", label: "Events", icon: "event" },
  { path: "/guidelines", label: "Volunteer Guidelines", icon: "menu_book" },
  { path: "/profile", label: "Profile & Badges", icon: "military_tech" },
  { path: "/login", label: "Sign In", icon: "login" },
] as const;

function MobilePreviewPage() {
  const [currentPath, setCurrentPath] = useState<string>("/");
  const [device, setDevice] = useState<DeviceType>("iphone");
  const [scale, setScale] = useState<number>(100);
  const [currentTime, setCurrentTime] = useState("18:30");

  useEffect(() => {
    const update = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false })
      );
    };
    update();
    const timer = setInterval(update, 10000);
    return () => clearInterval(timer);
  }, []);

  const deviceWidths: Record<DeviceType, number> = {
    iphone: 393,
    pixel: 412,
    galaxy: 384,
    fluid: 430,
  };

  const deviceHeights: Record<DeviceType, number> = {
    iphone: 852,
    pixel: 892,
    galaxy: 832,
    fluid: 860,
  };

  return (
    <div className="mob-viewer-layout">
      {/* Top Studio Control Bar */}
      <header className="mob-viewer-toolbar">
        <div className="mvt-left">
          <Link to="/" className="mvt-back-btn" title="Back to Full Desktop Website">
            <span className="ms">arrow_back</span>
            <span>Desktop Site</span>
          </Link>
          <div className="mvt-divider" />
          <div className="mvt-title">
            <span className="mvt-brand">STEP LIVE</span>
            <span className="mvt-tag">📱 Mobile Interface View</span>
          </div>
        </div>

        {/* Page Switcher */}
        <div className="mvt-pages-row">
          {PAGES.map((page) => (
            <button
              key={page.path}
              className={`mvt-page-btn ${currentPath === page.path ? "active" : ""}`}
              onClick={() => setCurrentPath(page.path)}
            >
              <span className="ms">{page.icon}</span>
              <span>{page.label}</span>
            </button>
          ))}
        </div>

        {/* Device & Zoom Controls */}
        <div className="mvt-controls">
          <div className="mvt-device-group">
            <span className="mvt-label">Phone:</span>
            <div className="mvt-btn-pills">
              <button
                className={`mvt-pill ${device === "iphone" ? "active" : ""}`}
                onClick={() => setDevice("iphone")}
              >
                iPhone 15 Pro
              </button>
              <button
                className={`mvt-pill ${device === "pixel" ? "active" : ""}`}
                onClick={() => setDevice("pixel")}
              >
                Pixel 8
              </button>
              <button
                className={`mvt-pill ${device === "galaxy" ? "active" : ""}`}
                onClick={() => setDevice("galaxy")}
              >
                Galaxy S24
              </button>
            </div>
          </div>

          <div className="mvt-zoom-group">
            <span className="mvt-label">Zoom:</span>
            <div className="mvt-btn-pills">
              <button
                className="mvt-pill"
                onClick={() => setScale((s) => Math.max(75, s - 10))}
                title="Zoom Out"
              >
                -
              </button>
              <span className="mvt-zoom-text">{scale}%</span>
              <button
                className="mvt-pill"
                onClick={() => setScale((s) => Math.min(120, s + 10))}
                title="Zoom In"
              >
                +
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Canvas with Mobile Phone Chassis */}
      <main className="mob-viewer-canvas">
        <div
          className={`mob-chassis-shell device-${device}`}
          style={{
            transform: `scale(${scale / 100})`,
            transformOrigin: "top center",
          }}
        >
          {/* Hardware buttons */}
          <div className="mob-chassis-vol-up" />
          <div className="mob-chassis-vol-down" />
          <div className="mob-chassis-power" />

          {/* Screen Box */}
          <div
            className="mob-chassis-screen"
            style={{
              width: `${deviceWidths[device]}px`,
              height: `${deviceHeights[device]}px`,
            }}
          >
            {/* Status Bar */}
            <div className="mob-chassis-statusbar">
              <span className="mob-time">{currentTime}</span>
              {device === "iphone" && (
                <div className="mob-dynamic-island-cutout">
                  <span className="island-lens" />
                  <span className="island-sensor" />
                </div>
              )}
              <div className="mob-icons">
                <span className="ms">signal_cellular_4_bar</span>
                <span className="ms">wifi</span>
                <span className="ms">battery_full</span>
              </div>
            </div>

            {/* Embedded Live Website (Rendered at exact mobile resolution) */}
            <div className="mob-iframe-container">
              <iframe
                key={currentPath}
                src={currentPath}
                title="STEP LIVE Mobile Website View"
                className="mob-live-iframe"
              />
            </div>

            {/* Home Swipe Indicator */}
            <div className="mob-chassis-homebar">
              <div className="mob-gesture-bar" />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
