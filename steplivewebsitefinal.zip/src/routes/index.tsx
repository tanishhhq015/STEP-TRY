import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useRef } from "react";
import {
  TopNav,
  SiteFooter,
  Icon,
  Modal,
  useToasts,
  useActiveRegion,
} from "@/components/step";
import { getRegionById } from "@/lib/step-data";
import { VolunteerBadgePill, VolunteerBadgeRoadmap } from "@/components/BadgeSystem";
import {
  useCurrentUser,
  useUserApplications,
  submitApplication,
  withdrawApplication,
  StepApplication,
} from "@/lib/user-db";
import { useEvents, ExtendedStepEvent, PRESET_EVENT_IMAGES } from "@/lib/events-db";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "STEP LIVE — Volunteer Hub" },
      {
        name: "description",
        content:
          "Register as a volunteer, complete your profile & experience, apply for live events across India, and track your applications directly on your dashboard.",
      },
      { property: "og:title", content: "STEP LIVE — Volunteer Hub" },
      {
        property: "og:description",
        content:
          "Join upcoming Indian festivals and conferences as a STEP LIVE volunteer, and track your applications on the home page.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  const { user, isAdmin } = useCurrentUser();
  const { events } = useEvents();
  const { applications, refresh } = useUserApplications(user.id);
  const { push, host } = useToasts();
  const { currentRegion } = useActiveRegion();

  // Modal state for direct application confirmation
  const [selectedEventForApp, setSelectedEventForApp] = useState<ExtendedStepEvent | null>(null);
  const registeredSectionRef = useRef<HTMLDivElement>(null);

  const upcomingEvents = events.filter((e) => e.status !== "Completed");

  function handleConfirmJoinEvent() {
    if (!selectedEventForApp) return;

    submitApplication(user, selectedEventForApp);
    const eventName = selectedEventForApp.title;
    setSelectedEventForApp(null);
    refresh();

    push(
      "success",
      `Your application for ${eventName} has been submitted for admin review.`
    );

    setTimeout(() => {
      registeredSectionRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 250);
  }

  function handleWithdrawApp(applicationId: string, eventTitle: string) {
    if (confirm(`Are you sure you want to withdraw your application for "${eventTitle}"?`)) {
      withdrawApplication(applicationId);
      refresh();
      push("info", `Application for ${eventTitle} has been withdrawn.`);
    }
  }

  return (
    <>
      <TopNav />

      {/* Admin Quick Notification Banner */}
      {isAdmin && (
        <div
          style={{
            background: "var(--charcoal)",
            color: "#FAF8F2",
            padding: "8px 16px",
            fontSize: 13,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            borderBottom: "2px solid var(--olive)",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ background: "var(--olive)", padding: "1px 6px", borderRadius: 3, fontSize: 11, fontWeight: 800 }}>
              ADMIN
            </span>
            <span>Logged in as Administrator ({user.name}). You can manage events and review volunteer applications.</span>
          </div>
          <Link to="/admin" className="btn btn-accent btn-sm" style={{ padding: "3px 10px", fontSize: 12 }}>
            Open Admin CMS Portal →
          </Link>
        </div>
      )}

      {/* ─── Hero Section ────────────────────────────────────────── */}
      <section className="hero">
        <div className="hero-shape hero-shape-a" aria-hidden="true" />
        <div className="hero-shape hero-shape-b" aria-hidden="true" />
        <div className="hero-index" aria-hidden="true">STEP LIVE</div>
        <div className="hero-inner">
          <div className="hero-copy">
            <h1 className="hero-title">
              <span>STEP</span>
              <span>LIVE</span>
            </h1>
            <p className="hero-lead">
              Welcome, <strong>{user.name}</strong> ({user.roleTitle}) — your operational dashboard
              for event assignments, volunteer applications, verified service hours, and on-ground deployments across India.
            </p>

            <div className="hero-ctas">
              <a
                href="#registered-events-section"
                className="btn btn-primary"
                onClick={(e) => {
                  e.preventDefault();
                  registeredSectionRef.current?.scrollIntoView({ behavior: "smooth" });
                }}
              >
                <Icon name="assignment" /> My Applications ({applications.length})
              </a>
              <a href="#upcoming-events-section" className="btn btn-accent">
                <Icon name="event" /> Join Event
              </a>
              {isAdmin ? (
                <Link to="/admin" className="btn btn-outline">
                  <Icon name="admin_panel_settings" /> Admin CMS Portal
                </Link>
              ) : (
                <Link to="/profile" className="btn btn-outline">
                  <Icon name="badge" /> View Full Profile
                </Link>
              )}
            </div>
          </div>

          <div className="hero-dashboard" aria-label="Volunteer readiness overview">
            <div className="hero-stat-grid">
              <div className="hero-stat hero-stat-1">
                <span className="hero-stat-code">01</span>
                <span className="hero-stat-label">Applications</span>
                <strong>{applications.length}</strong>
              </div>
              <div className="hero-stat hero-stat-2">
                <span className="hero-stat-code">02</span>
                <span className="hero-stat-label">Verified Hours</span>
                <strong>{user.verifiedHours} hrs</strong>
              </div>
              <div className="hero-stat hero-stat-3">
                <span className="hero-stat-code">03</span>
                <span className="hero-stat-label">Deployments</span>
                <strong>{user.eventsCompleted}</strong>
              </div>
              <div className="hero-stat hero-stat-4">
                <span className="hero-stat-code">04</span>
                <span className="hero-stat-label">Experience Tier</span>
                <strong>{user.experience?.years?.split(" ")[0] || "1+ Yr"}</strong>
              </div>
            </div>

            {/* Credential Card */}
            <div className="credential-card hero-card">
              <div className="cc-head">
                <span className="cc-title">Volunteer Profile</span>
                <VolunteerBadgePill tier="Bronze" size="sm" />
              </div>
              <div className="cc-row">
                <span className="k">Volunteer Name</span>
                <span className="v">{user.name}</span>
              </div>
              <div className="cc-row">
                <span className="k">Active Hub</span>
                <span className="v">{currentRegion.name}</span>
              </div>
              <div className="cc-row">
                <span className="k">Emergency Contact</span>
                <span className="v">
                  {user.basicDetails?.emergencyContactName || "On File"} ({user.basicDetails?.emergencyContactRelation || "Family"})
                </span>
              </div>
              <div className="cc-row">
                <span className="k">Latest Status</span>
                <span className="v">
                  {applications.length > 0 ? `${applications[0].eventTitle} (Application ${applications[0].status})` : "No pending applications"}
                </span>
              </div>
              <div className="progress-track" title="Volunteer Progression">
                <div className="progress-fill tier-fill-bronze" style={{ width: "25%" }} />
              </div>
              <Link to="/profile" className="btn btn-primary btn-sm hero-card-btn">
                <Icon name="military_tech" /> Manage Profile &amp; Experience
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Marquee band */}
      <div className="marquee" aria-hidden="true">
        <div className="marquee-track">
          {Array.from({ length: 2 }).flatMap((_, r) =>
            ["On-Ground Operations", "Verified Service", "Volunteer Deployments", "STEP LIVE"].flatMap((word, i) => [
              <span key={`${r}-${i}`} className={i % 2 ? "hollow" : undefined}>
                {word}
              </span>,
              <span key={`${r}-${i}-d`}>✦</span>,
            ]),
          )}
        </div>
      </div>

      {/* ─────────────────────────────────────────────────────────────
          SECTION: VOLUNTEER APPLICATIONS & DEPLOYMENTS
          ───────────────────────────────────────────────────────────── */}
      <section
        id="registered-events-section"
        ref={registeredSectionRef}
        className="page"
        style={{ paddingTop: 36, paddingBottom: 24 }}
        aria-label="Volunteer Applications"
      >
        <div className="section-head-row">
          <div>
            <div className="section-label">Volunteer Dashboard · Deployments</div>
            <h2 className="section-title" style={{ marginBottom: 4 }}>
              My Applications ({applications.length})
            </h2>
            <p style={{ margin: 0, color: "var(--on-surface-variant)", fontSize: 14 }}>
              Track the review status of your event applications across Indian cities.
            </p>
          </div>
          <a href="#upcoming-events-section" className="btn btn-accent btn-sm">
            + Apply for Another Event
          </a>
        </div>

        {applications.length === 0 ? (
          <div
            style={{
              background: "var(--surface)",
              border: "2px dashed var(--outline)",
              borderRadius: 16,
              padding: "40px 24px",
              textAlign: "center",
              marginTop: 16,
            }}
          >
            <div style={{ fontSize: 36, marginBottom: 8 }}>📋</div>
            <h3 style={{ fontSize: 18, margin: "0 0 6px" }}>You haven't applied for any events yet</h3>
            <p style={{ color: "var(--on-surface-variant)", maxWidth: 500, margin: "0 auto 16px", fontSize: 14 }}>
              Explore upcoming events below and click Join Event to send your saved profile for admin review.
            </p>
            <a href="#upcoming-events-section" className="btn btn-primary">
              <Icon name="event" /> Browse Upcoming Events
            </a>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 16, marginTop: 16 }}>
            {applications.map((app) => {
              const isApproved = app.status === "Approved";
              const isDeclined = app.status === "Declined";
              const isPending = app.status === "Pending";

              return (
                <div
                  key={app.applicationId}
                  style={{
                    background: "var(--surface)",
                    border: `1.5px solid ${isApproved ? "var(--olive)" : isDeclined ? "#ef4444" : "var(--outline)"}`,
                    borderRadius: 16,
                    padding: 24,
                    boxShadow: "var(--shadow-md)",
                    display: "flex",
                    flexDirection: "column",
                    gap: 16,
                  }}
                >
                  {/* Header Row */}
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12 }}>
                    <div>
                      <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap", marginBottom: 6 }}>
                        {/* Status badge */}
                        <span
                          style={{
                            background: isApproved ? "#EDE6D8" : isDeclined ? "#FDE8E8" : "#FAF8F2",
                            color: isApproved ? "var(--olive)" : isDeclined ? "#991B1B" : "var(--charcoal)",
                            fontWeight: 800,
                            fontSize: 12,
                            padding: "4px 12px",
                            borderRadius: 12,
                            border: `1.5px solid ${isApproved ? "var(--olive)" : isDeclined ? "#F87171" : "var(--outline)"}`,
                            display: "inline-flex",
                            alignItems: "center",
                            gap: 4,
                          }}
                        >
                          {isApproved && "✓ Application Approved"}
                          {isDeclined && "✕ Application Declined"}
                          {isPending && "⏳ Application Pending"}
                        </span>

                        <span style={{ fontSize: 12, color: "var(--on-surface-variant)" }}>
                          Submitted on {new Date(app.appliedAt).toLocaleDateString("en-IN", { month: "short", day: "numeric", year: "numeric" })}
                        </span>
                      </div>

                      <h3 style={{ fontSize: 22, margin: 0, fontWeight: 900, color: "var(--charcoal)" }}>
                        {app.eventTitle}
                      </h3>
                    </div>

                    <div style={{ display: "flex", gap: 8 }}>
                      {isPending && (
                        <button
                          type="button"
                          className="btn btn-outline btn-sm"
                          style={{ color: "#dc2626", borderColor: "#fca5a5" }}
                          onClick={() => handleWithdrawApp(app.applicationId, app.eventTitle)}
                          title="Withdraw Application"
                        >
                          Withdraw Application
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Declined Notice Banner */}
                  {isDeclined && (
                    <div
                      style={{
                        background: "#fef2f2",
                        borderLeft: "4px solid #ef4444",
                        padding: "12px 16px",
                        borderRadius: 8,
                        fontSize: 13.5,
                        color: "#991b1b",
                      }}
                    >
                      <strong>Status Update:</strong>{" "}
                      {app.adminNotes || "This application was declined for this deployment. You may apply for other upcoming events."}
                    </div>
                  )}

                  {/* Approved Notice Banner */}
                  {isApproved && (
                    <div
                      style={{
                        background: "#EDE6D8",
                        borderLeft: "4px solid var(--olive)",
                        padding: "12px 16px",
                        borderRadius: 8,
                        fontSize: 13.5,
                        color: "var(--charcoal)",
                      }}
                    >
                      <strong>Deployment Selected!</strong> You have been selected for {app.eventTitle}. Please check the event details and report to your assigned POC.
                    </div>
                  )}

                  {/* Grid of registered event details */}
                  <div
                    style={{
                      display: "grid",
                      gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
                      gap: 12,
                      background: "var(--surface-container)",
                      padding: 16,
                      borderRadius: 12,
                    }}
                  >
                    <div>
                      <div style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", color: "var(--on-surface-variant)" }}>
                        Date &amp; Schedule
                      </div>
                      <div style={{ fontWeight: 800, fontSize: 14, color: "var(--charcoal)", marginTop: 2 }}>
                        <Icon name="calendar_month" /> {app.eventDate}
                      </div>
                    </div>

                    <div>
                      <div style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", color: "var(--on-surface-variant)" }}>
                        Location &amp; Venue
                      </div>
                      <div style={{ fontWeight: 800, fontSize: 14, color: "var(--charcoal)", marginTop: 2 }}>
                        <Icon name="location_on" /> {app.eventLocation}
                      </div>
                    </div>

                    <div>
                      <div style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", color: "var(--on-surface-variant)" }}>
                        Volunteer Region
                      </div>
                      <div style={{ fontWeight: 800, fontSize: 14, color: "var(--olive)", marginTop: 2 }}>
                        <Icon name="pin_drop" /> {app.eventRegion}
                      </div>
                    </div>

                    <div>
                      <div style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", color: "var(--on-surface-variant)" }}>
                        Applicant Snapshot
                      </div>
                      <div style={{ fontWeight: 800, fontSize: 13, color: "var(--charcoal)", marginTop: 2 }}>
                        {app.userName} ({app.userPhone})
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* ─────────────────────────────────────────────────────────────
          SECTION: UPCOMING EVENTS OPEN FOR APPLICATION
          ───────────────────────────────────────────────────────────── */}
      <section
        id="upcoming-events-section"
        className="page deployments-section"
        aria-label="Upcoming Events"
        style={{ paddingTop: 20 }}
      >
        <div className="section-head-row">
          <div>
            <div className="section-label">Deployments Across India</div>
            <h2 className="section-title" style={{ marginBottom: 4 }}>
              Upcoming Events
            </h2>
            <p style={{ margin: 0, color: "var(--on-surface-variant)", fontSize: 14 }}>
              Click Join Event on any upcoming deployment to submit your saved profile for review.
            </p>
          </div>
          {isAdmin ? (
            <Link to="/admin" className="btn btn-accent btn-sm">
              <Icon name="add" /> Admin: Add / Edit Events
            </Link>
          ) : (
            <Link to="/events" className="btn btn-ghost">
              View All Events →
            </Link>
          )}
        </div>

        <div className="event-grid">
          {upcomingEvents.map((ev) => {
            const regObj = getRegionById(ev.region);
            const userApp = applications.find((a) => a.eventId === ev.id);

            return (
              <article
                key={ev.id}
                className="event-card"
                style={{
                  borderColor: userApp ? "var(--olive)" : undefined,
                  borderWidth: userApp ? 2 : 1,
                  padding: 0,
                  overflow: "hidden",
                }}
              >
                {/* Event Banner Image */}
                <div style={{ height: 160, position: "relative", background: "var(--charcoal)" }}>
                  <img
                    src={ev.imageUrl || PRESET_EVENT_IMAGES[0].url}
                    alt={ev.title}
                    style={{ width: "100%", height: "100%", objectFit: "cover" }}
                  />
                  <div
                    style={{
                      position: "absolute",
                      inset: 0,
                      background: "linear-gradient(to top, rgba(0,0,0,0.7) 0%, transparent 60%)",
                    }}
                  />
                  <span
                    style={{
                      position: "absolute",
                      top: 10,
                      left: 10,
                      background: "var(--olive)",
                      color: "#FAF8F2",
                      fontSize: 11,
                      fontWeight: 800,
                      padding: "2px 8px",
                      borderRadius: 4,
                      textTransform: "uppercase",
                    }}
                  >
                    {ev.category}
                  </span>

                  {userApp && (
                    <span
                      style={{
                        position: "absolute",
                        top: 10,
                        right: 10,
                        background: userApp.status === "Approved" ? "var(--olive)" : userApp.status === "Declined" ? "#991b1b" : "var(--charcoal)",
                        color: "#FAF8F2",
                        fontSize: 11,
                        fontWeight: 800,
                        padding: "2px 8px",
                        borderRadius: 4,
                      }}
                    >
                      {userApp.status === "Approved" ? "✓ Approved" : userApp.status === "Declined" ? "✕ Declined" : "Pending"}
                    </span>
                  )}
                </div>

                <div style={{ padding: 18 }}>
                  <div className="ec-top" style={{ marginBottom: 10 }}>
                    <div className="ec-title-wrap">
                      <h3 style={{ fontSize: 18 }}>{ev.title}</h3>
                      <div className="ec-badges-row">
                        <span className="region-tag">
                          <Icon name="location_on" /> {regObj?.name || "India"}
                        </span>
                        <span className="tag">Volunteer capacity: {ev.teamSize || ev.capacity || 20}</span>
                      </div>
                    </div>
                  </div>

                  <div className="event-meta">
                    <span>
                      <Icon name="calendar_month" /> {ev.date}
                    </span>
                    <span>
                      <Icon name="location_on" /> {ev.location}
                    </span>
                    <span>
                      <Icon name="badge" /> Role: {ev.role}
                    </span>
                  </div>

                  <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
                    {userApp ? (
                      <div
                        style={{
                          flex: 1,
                          textAlign: "center",
                          padding: "8px 12px",
                          borderRadius: 6,
                          background: "var(--surface-container)",
                          fontWeight: 700,
                          fontSize: 13,
                          color: "var(--charcoal)",
                        }}
                      >
                        Application {userApp.status}
                      </div>
                    ) : (
                      <button
                        type="button"
                        className="btn btn-accent btn-sm"
                        style={{ flex: 1, justifyContent: "center" }}
                        onClick={() => setSelectedEventForApp(ev)}
                      >
                        <Icon name="how_to_reg" /> Join Event
                      </button>
                    )}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* Volunteer Tier & Badge Progression Roadmap */}
      <section className="page badge-system-section" aria-label="Volunteer Tier and Badge Progression">
        <div className="section-head-row">
          <div>
            <div className="section-label">Operational Progression</div>
            <h2 className="section-title" style={{ marginBottom: 0 }}>
              Volunteer Badge System &amp; Roadmap
            </h2>
          </div>
          <VolunteerBadgePill tier="Bronze" size="md" />
        </div>
        <p className="section-desc-lead">
          Level up your volunteer standing with every completed deployment. Your verified profile is currently at{" "}
          <strong>Bronze Tier</strong> with <strong>{user.eventsCompleted} Completed Events</strong>.
        </p>

        <VolunteerBadgeRoadmap initialEvents={user.eventsCompleted} />
      </section>

      <SiteFooter />

      {/* ─────────────────────────────────────────────────────────────
          CONFIRMATION MODAL: JOIN EVENT
          ───────────────────────────────────────────────────────────── */}
      {selectedEventForApp && (
        <Modal
          title={`Join Event: ${selectedEventForApp.title}`}
          onClose={() => setSelectedEventForApp(null)}
        >
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div
              style={{
                background: "var(--surface-container)",
                padding: "14px 16px",
                borderRadius: 8,
                fontSize: 14,
                display: "flex",
                flexDirection: "column",
                gap: 6,
              }}
            >
              <div>
                <strong>Event:</strong> {selectedEventForApp.title}
              </div>
              <div>
                <strong>Date:</strong> {selectedEventForApp.date}
              </div>
              <div>
                <strong>Venue:</strong> {selectedEventForApp.location}
              </div>
            </div>

            <div
              style={{
                background: "var(--surface-low)",
                border: "1px solid var(--outline)",
                padding: "12px 16px",
                borderRadius: 8,
                fontSize: 13.5,
                color: "var(--on-surface)",
              }}
            >
              <Icon name="info" /> Your saved STEP profile will be sent to the admin for review.
            </div>

            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 8 }}>
              <button
                type="button"
                className="btn btn-outline"
                onClick={() => setSelectedEventForApp(null)}
              >
                Cancel
              </button>
              <button
                type="button"
                className="btn btn-accent"
                onClick={handleConfirmJoinEvent}
              >
                Confirm &amp; Join Event
              </button>
            </div>
          </div>
        </Modal>
      )}

      {host}
    </>
  );
}
