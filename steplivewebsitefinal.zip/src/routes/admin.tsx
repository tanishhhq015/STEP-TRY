import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useRef } from "react";
import { TopNav, SiteFooter, Icon, Modal, useToasts, ProfilePhotoLightbox } from "@/components/step";
import { REGIONS, getRegionById } from "@/lib/step-data";
import {
  useEvents,
  createEvent,
  updateEvent,
  deleteEvent,
  ExtendedStepEvent,
  PRESET_EVENT_IMAGES,
} from "@/lib/events-db";
import {
  useCurrentUser,
  useAllApplications,
  approveApplication,
  declineApplication,
  resetApplication,
  StepApplication,
} from "@/lib/user-db";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin CMS Portal — STEP LIVE" },
      {
        name: "description",
        content:
          "Admin management portal: create and edit events with real photo upload, and review volunteer applications.",
      },
      { property: "og:title", content: "Admin CMS Portal — STEP LIVE" },
    ],
  }),
  component: AdminPage,
});

function AdminPage() {
  const { user } = useCurrentUser();
  const { events, refreshEvents } = useEvents();
  const { applications, refresh: refreshApps } = useAllApplications();
  const { push, host } = useToasts();

  // Navigation tab inside Admin
  const [activeTab, setActiveTab] = useState<"events" | "volunteers">("events");

  // Event modal states
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<ExtendedStepEvent | null>(null);

  // Volunteer decline modal state
  const [decliningApp, setDecliningApp] = useState<StepApplication | null>(null);
  const [declineReason, setDeclineReason] = useState(
    "Volunteer capacity reached for this deployment. Please explore other upcoming events.",
  );

  // Expanded profile state for applications
  const [expandedAppId, setExpandedAppId] = useState<string | null>(null);

  // Lightbox state for full-size profile photo viewer
  const [lightboxData, setLightboxData] = useState<{
    isOpen: boolean;
    photoUrl: string;
    volunteerName: string;
  }>({
    isOpen: false,
    photoUrl: "",
    volunteerName: "",
  });

  // Filter states
  const [appFilter, setAppFilter] = useState<"All" | "Pending" | "Approved" | "Declined">("All");
  const [eventSearch, setEventSearch] = useState("");

  // File upload state for event photos
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  // Event form state (used for both create and edit)
  const [eventForm, setEventForm] = useState({
    title: "",
    date: "",
    location: "",
    region: "delhi-ncr",
    role: "Stage Crew",
    category: "Festival",
    teamSize: 20,
    coordinator: "Operations Lead",
    coordinatorPhone: "+91 98101 22345",
    imageUrl: PRESET_EVENT_IMAGES[0].url,
    description: "",
    reportingTime: "45 mins before designated shift",
    musterPoint: "",
    tags: "Outdoor, Production",
  });

  function handleFileSelect(file: File) {
    // Validate file type
    const validTypes = ["image/jpeg", "image/jpg", "image/png", "image/webp"];
    if (!validTypes.includes(file.type)) {
      push("error", "Invalid file format. Please upload JPG, JPEG, PNG, or WebP image.");
      return;
    }

    // Validate size (max 5MB)
    const maxSize = 5 * 1024 * 1024;
    if (file.size > maxSize) {
      push("error", "File is too large. Maximum allowed size is 5MB.");
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      if (typeof e.target?.result === "string") {
        setEventForm((prev) => ({ ...prev, imageUrl: e.target!.result as string }));
        push("success", "Event image uploaded and preview updated!");
      }
    };
    reader.onerror = () => {
      push("error", "Failed to read image file.");
    };
    reader.readAsDataURL(file);
  }

  function openCreateModal() {
    setEventForm({
      title: "",
      date: "Oct 10–12, 2026",
      location: "Pragati Maidan, New Delhi",
      region: "delhi-ncr",
      role: "Stage Crew",
      category: "Festival",
      teamSize: 24,
      coordinator: user.name || "Operations Lead",
      coordinatorPhone: user.phone || "+91 98101 22345",
      imageUrl: PRESET_EVENT_IMAGES[0].url,
      description: "National volunteer deployment for mainstage rigging and audience safety logistics.",
      reportingTime: "06:00 AM",
      musterPoint: "Main Entry Gate 2",
      tags: "Outdoor, Multi-day",
    });
    setIsCreateModalOpen(true);
  }

  function openEditModal(ev: ExtendedStepEvent) {
    setEditingEvent(ev);
    setEventForm({
      title: ev.title,
      date: ev.date,
      location: ev.location,
      region: ev.region,
      role: ev.role,
      category: ev.category,
      teamSize: ev.teamSize || ev.capacity || 20,
      coordinator: ev.coordinator || ev.eventLead || "Operations Desk",
      coordinatorPhone: ev.coordinatorPhone || "+91 98101 22345",
      imageUrl: ev.imageUrl || PRESET_EVENT_IMAGES[0].url,
      description: ev.description || "",
      reportingTime: ev.reportingTime || "45 mins before deployment",
      musterPoint: ev.musterPoint || ev.location,
      tags: ev.tags?.join(", ") || "",
    });
  }

  function handleSaveEvent(e: React.FormEvent) {
    e.preventDefault();
    if (!eventForm.title || !eventForm.location || !eventForm.date) {
      push("error", "Please fill in all mandatory event fields.");
      return;
    }

    const payload = {
      title: eventForm.title.trim(),
      date: eventForm.date.trim(),
      location: eventForm.location.trim(),
      region: eventForm.region,
      role: eventForm.role.trim(),
      category: eventForm.category,
      status: "Approved" as const,
      teamSize: Number(eventForm.teamSize) || 20,
      coordinator: eventForm.coordinator.trim(),
      coordinatorPhone: eventForm.coordinatorPhone.trim(),
      imageUrl: eventForm.imageUrl,
      description: eventForm.description.trim(),
      reportingTime: eventForm.reportingTime.trim(),
      musterPoint: eventForm.musterPoint.trim(),
      tags: eventForm.tags.split(",").map((s) => s.trim()).filter(Boolean),
    };

    if (editingEvent) {
      updateEvent(editingEvent.id, payload);
      push("success", `Event "${payload.title}" updated successfully!`);
      setEditingEvent(null);
    } else {
      createEvent(payload);
      push("success", `New event "${payload.title}" created!`);
      setIsCreateModalOpen(false);
    }
    refreshEvents();
  }

  function handleDeleteEvent(id: string, title: string) {
    if (confirm(`Are you sure you want to delete event "${title}"? This cannot be undone.`)) {
      deleteEvent(id);
      refreshEvents();
      push("info", `Event "${title}" has been deleted.`);
    }
  }

  function handleApprove(app: StepApplication) {
    approveApplication(app.applicationId, "Application approved by Admin.");
    refreshApps();
    push("success", `Volunteer ${app.userName || "applicant"} has been SELECTED for ${app.eventTitle}!`);
  }

  function handleDeclineSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!decliningApp) return;

    declineApplication(decliningApp.applicationId, declineReason);
    refreshApps();
    push("warning", `Application from ${decliningApp.userName} has been DECLINED.`);
    setDecliningApp(null);
  }

  // Filtered lists
  const filteredEvents = events.filter((ev) =>
    ev.title.toLowerCase().includes(eventSearch.toLowerCase()) ||
    ev.location.toLowerCase().includes(eventSearch.toLowerCase()) ||
    ev.region.toLowerCase().includes(eventSearch.toLowerCase()),
  );

  const filteredApps = applications.filter((a) => {
    if (appFilter === "All") return true;
    return a.status === appFilter;
  });

  const pendingCount = applications.filter((a) => a.status === "Pending").length;
  const approvedCount = applications.filter((a) => a.status === "Approved").length;
  const declinedCount = applications.filter((a) => a.status === "Declined").length;

  return (
    <>
      <TopNav />

      {/* Admin header */}
      <section
        style={{
          background: "var(--charcoal)",
          color: "#FAF8F2",
          padding: "36px 24px 28px",
          borderBottom: "3px solid var(--olive)",
        }}
      >
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 16 }}>
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                <span
                  style={{
                    background: "var(--olive)",
                    color: "#FAF8F2",
                    fontWeight: 800,
                    fontSize: 11,
                    textTransform: "uppercase",
                    padding: "3px 10px",
                    borderRadius: 4,
                    letterSpacing: 1,
                  }}
                >
                  Admin CMS Portal
                </span>
                <span style={{ color: "#D7CDBB", fontSize: 13 }}>
                  • Operational Console
                </span>
              </div>
              <h1 style={{ fontSize: 32, margin: 0, fontWeight: 900, color: "#FAF8F2", letterSpacing: "-0.5px" }}>
                STEP LIVE Operations CMS
              </h1>
              <p style={{ margin: "6px 0 0", color: "#D7CDBB", fontSize: 14 }}>
                Logged in as <strong>{user.name}</strong> ({user.email}) · Manage national deployments and review volunteer applications.
              </p>
            </div>

            {/* Quick Actions */}
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
              <button
                type="button"
                className="btn btn-accent"
                onClick={openCreateModal}
                style={{ display: "flex", alignItems: "center", gap: 6 }}
              >
                <Icon name="add_circle" /> Add New Event
              </button>
              <Link to="/" className="btn btn-outline" style={{ color: "#FAF8F2", borderColor: "#D7CDBB" }}>
                <Icon name="visibility" /> View Public Site
              </Link>
            </div>
          </div>

          {/* Quick Metrics Bar */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
              gap: 12,
              marginTop: 24,
              background: "rgba(255,255,255,0.06)",
              padding: 16,
              borderRadius: 12,
            }}
          >
            <div>
              <div style={{ fontSize: 11, textTransform: "uppercase", color: "#D7CDBB", fontWeight: 700 }}>Total Deployments</div>
              <div style={{ fontSize: 24, fontWeight: 900, color: "#FAF8F2" }}>{events.length} Events</div>
            </div>
            <div>
              <div style={{ fontSize: 11, textTransform: "uppercase", color: "#EDE6D8", fontWeight: 700 }}>Pending Review</div>
              <div style={{ fontSize: 24, fontWeight: 900, color: "#EDE6D8" }}>{pendingCount} Pending</div>
            </div>
            <div>
              <div style={{ fontSize: 11, textTransform: "uppercase", color: "#86efac", fontWeight: 700 }}>Approved Volunteers</div>
              <div style={{ fontSize: 24, fontWeight: 900, color: "#86efac" }}>{approvedCount} Selected</div>
            </div>
            <div>
              <div style={{ fontSize: 11, textTransform: "uppercase", color: "#fca5a5", fontWeight: 700 }}>Declined</div>
              <div style={{ fontSize: 24, fontWeight: 900, color: "#fca5a5" }}>{declinedCount} Declined</div>
            </div>
          </div>

          {/* CMS Tabs */}
          <div style={{ display: "flex", gap: 8, marginTop: 20 }}>
            <button
              type="button"
              className={`btn btn-sm ${activeTab === "events" ? "btn-primary" : "btn-ghost"}`}
              style={{
                color: activeTab === "events" ? "#FAF8F2" : "#D7CDBB",
                background: activeTab === "events" ? "var(--olive)" : "transparent",
                fontWeight: 700,
              }}
              onClick={() => setActiveTab("events")}
            >
              <Icon name="event" /> Manage Events ({events.length})
            </button>
            <button
              type="button"
              className={`btn btn-sm ${activeTab === "volunteers" ? "btn-primary" : "btn-ghost"}`}
              style={{
                color: activeTab === "volunteers" ? "#FAF8F2" : "#D7CDBB",
                background: activeTab === "volunteers" ? "var(--olive)" : "transparent",
                fontWeight: 700,
              }}
              onClick={() => setActiveTab("volunteers")}
            >
              <Icon name="assignment" /> Volunteer Applications ({applications.length})
              {pendingCount > 0 && (
                <span
                  style={{
                    background: "#eab308",
                    color: "#000",
                    borderRadius: "50%",
                    padding: "1px 6px",
                    fontSize: 10,
                    fontWeight: 900,
                  }}
                >
                  {pendingCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </section>

      {/* Main CMS Workspace */}
      <main className="page" style={{ paddingTop: 28, paddingBottom: 60 }}>
        {/* ─────────────────────────────────────────────────────────────
            TAB 1: EVENTS CMS (LIST, ADD, EDIT, DELETE WITH IMAGES)
            ───────────────────────────────────────────────────────────── */}
        {activeTab === "events" && (
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18, flexWrap: "wrap", gap: 12 }}>
              <div>
                <h2 style={{ fontSize: 20, margin: 0, fontWeight: 800 }}>Event Deployments Roster</h2>
                <p style={{ margin: "2px 0 0", color: "var(--on-surface-variant)", fontSize: 13 }}>
                  Create and manage active festival and conference deployments with banner photo upload.
                </p>
              </div>

              <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                <input
                  type="text"
                  placeholder="Search events, cities, venues..."
                  value={eventSearch}
                  onChange={(e) => setEventSearch(e.target.value)}
                  style={{
                    padding: "7px 12px",
                    borderRadius: 8,
                    border: "1px solid var(--outline)",
                    fontSize: 13,
                    minWidth: 260,
                  }}
                />
                <button type="button" className="btn btn-accent btn-sm" onClick={openCreateModal}>
                  <Icon name="add" /> New Event
                </button>
              </div>
            </div>

            {/* Events Grid */}
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fill, minmax(340px, 1fr))",
                gap: 20,
              }}
            >
              {filteredEvents.map((ev) => {
                const regObj = getRegionById(ev.region);
                return (
                  <div
                    key={ev.id}
                    style={{
                      background: "var(--surface)",
                      border: "1.5px solid var(--outline)",
                      borderRadius: 14,
                      overflow: "hidden",
                      display: "flex",
                      flexDirection: "column",
                      boxShadow: "var(--shadow-sm)",
                    }}
                  >
                    {/* Event Banner Image */}
                    <div style={{ position: "relative", height: 160, background: "var(--charcoal)" }}>
                      <img
                        src={ev.imageUrl || PRESET_EVENT_IMAGES[0].url}
                        alt={ev.title}
                        style={{ width: "100%", height: "100%", objectFit: "cover" }}
                      />
                      <div
                        style={{
                          position: "absolute",
                          inset: 0,
                          background: "linear-gradient(to top, rgba(0,0,0,0.7) 0%, transparent 60%)",
                        }}
                      />
                      <span
                        style={{
                          position: "absolute",
                          bottom: 10,
                          left: 12,
                          background: "var(--olive)",
                          color: "#FAF8F2",
                          fontSize: 11,
                          fontWeight: 800,
                          padding: "2px 8px",
                          borderRadius: 4,
                          textTransform: "uppercase",
                        }}
                      >
                        {ev.category}
                      </span>
                      <span
                        style={{
                          position: "absolute",
                          bottom: 10,
                          right: 12,
                          background: "rgba(0,0,0,0.6)",
                          color: "#FAF8F2",
                          fontSize: 11,
                          fontWeight: 700,
                          padding: "2px 8px",
                          borderRadius: 4,
                        }}
                      >
                        Volunteer capacity: {ev.teamSize || ev.capacity || 20}
                      </span>
                    </div>

                    {/* Event Content */}
                    <div style={{ padding: 18, flex: 1, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
                      <div>
                        <h3 style={{ fontSize: 18, margin: "0 0 6px", fontWeight: 800, color: "var(--charcoal)" }}>
                          {ev.title}
                        </h3>
                        <div style={{ display: "flex", flexDirection: "column", gap: 4, fontSize: 13, color: "var(--on-surface-variant)" }}>
                          <div>
                            <Icon name="calendar_month" /> <strong>{ev.date}</strong>
                          </div>
                          <div>
                            <Icon name="location_on" /> {ev.location} ({regObj?.name})
                          </div>
                          <div>
                            <Icon name="badge" /> Duty: <strong>{ev.role}</strong>
                          </div>
                          <div>
                            <Icon name="person" /> Lead: {ev.coordinator || ev.eventLead} ({ev.coordinatorPhone})
                          </div>
                        </div>
                      </div>

                      {/* Card Action Controls */}
                      <div style={{ display: "flex", gap: 8, marginTop: 16, borderTop: "1px solid var(--outline)", paddingTop: 12 }}>
                        <button
                          type="button"
                          className="btn btn-outline btn-sm"
                          style={{ flex: 1, justifyContent: "center" }}
                          onClick={() => openEditModal(ev)}
                        >
                          <Icon name="edit" /> Edit Event
                        </button>
                        <button
                          type="button"
                          className="btn btn-outline btn-sm"
                          style={{ color: "#dc2626", borderColor: "#fca5a5" }}
                          onClick={() => handleDeleteEvent(ev.id, ev.title)}
                          title="Delete event"
                        >
                          <Icon name="delete" /> Delete
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ─────────────────────────────────────────────────────────────
            TAB 2: VOLUNTEER APPLICATIONS (MANUAL REVIEW & APPROVALS)
            ───────────────────────────────────────────────────────────── */}
        {activeTab === "volunteers" && (
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18, flexWrap: "wrap", gap: 12 }}>
              <div>
                <h2 style={{ fontSize: 20, margin: 0, fontWeight: 800 }}>Volunteer Applications</h2>
                <p style={{ margin: "2px 0 0", color: "var(--on-surface-variant)", fontSize: 13 }}>
                  Review volunteer submissions with their saved profiles. Approve or decline applicants with instant in-app notification.
                </p>
              </div>

              {/* Status Filter Tabs */}
              <div className="chip-row">
                {(["All", "Pending", "Approved", "Declined"] as const).map((st) => (
                  <button
                    key={st}
                    type="button"
                    className={`chip ${appFilter === st ? "active" : ""}`}
                    onClick={() => setAppFilter(st)}
                    style={{ cursor: "pointer" }}
                  >
                    {st === "All" && `All (${applications.length})`}
                    {st === "Pending" && `Pending (${pendingCount})`}
                    {st === "Approved" && `Approved (${approvedCount})`}
                    {st === "Declined" && `Declined (${declinedCount})`}
                  </button>
                ))}
              </div>
            </div>

            {filteredApps.length === 0 ? (
              <div
                style={{
                  background: "var(--surface)",
                  border: "1.5px dashed var(--outline)",
                  borderRadius: 14,
                  padding: 40,
                  textAlign: "center",
                }}
              >
                <h3>No applications found</h3>
                <p style={{ color: "var(--on-surface-variant)", fontSize: 14 }}>
                  No volunteer applications match the current filter "{appFilter}".
                </p>
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                {filteredApps.map((app) => {
                  const isApproved = app.status === "Approved";
                  const isDeclined = app.status === "Declined";
                  const isPending = app.status === "Pending";
                  const isExpanded = expandedAppId === app.applicationId;

                  return (
                    <div
                      key={app.applicationId}
                      style={{
                        background: "var(--surface)",
                        border: `1.5px solid ${isApproved ? "var(--olive)" : isDeclined ? "#ef4444" : "var(--outline)"}`,
                        borderRadius: 14,
                        padding: 20,
                        boxShadow: "var(--shadow-sm)",
                      }}
                    >
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12 }}>
                        <div style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
                          {/* Avatar */}
                          {app.userAvatarUrl ? (
                            <button
                              type="button"
                              onClick={() =>
                                setLightboxData({
                                  isOpen: true,
                                  photoUrl: app.userAvatarUrl!,
                                  volunteerName: app.userName || "Volunteer",
                                })
                              }
                              title="Click to view full-size profile photo"
                              aria-label={`View ${app.userName || "Volunteer"} profile photo`}
                              style={{
                                width: 52,
                                height: 52,
                                borderRadius: "50%",
                                padding: 0,
                                border: "2px solid var(--deep-teal)",
                                cursor: "pointer",
                                overflow: "hidden",
                                flexShrink: 0,
                                background: "var(--olive)",
                                position: "relative",
                                display: "block",
                              }}
                            >
                              <img
                                src={app.userAvatarUrl}
                                alt={`${app.userName || "Volunteer"} profile photo`}
                                style={{
                                  width: "100%",
                                  height: "100%",
                                  objectFit: "cover",
                                  display: "block",
                                }}
                              />
                            </button>
                          ) : (
                            <div
                              style={{
                                width: 52,
                                height: 52,
                                borderRadius: "50%",
                                background: "var(--olive)",
                                color: "#FAF8F2",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                fontWeight: 900,
                                fontSize: 18,
                                flexShrink: 0,
                              }}
                            >
                              {(app.userName || "VO").slice(0, 2).toUpperCase()}
                            </div>
                          )}

                          <div>
                            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                              <span
                                style={{
                                  background: isApproved ? "#EDE6D8" : isDeclined ? "#FEE2E2" : "#FAF8F2",
                                  color: isApproved ? "var(--olive)" : isDeclined ? "#991B1B" : "var(--charcoal)",
                                  fontWeight: 800,
                                  fontSize: 12,
                                  padding: "2px 10px",
                                  borderRadius: 12,
                                  border: `1px solid ${isApproved ? "var(--olive)" : isDeclined ? "#FCA5A5" : "var(--outline)"}`,
                                }}
                              >
                                {isApproved ? "✓ Approved" : isDeclined ? "✕ Declined" : "⏳ Pending Review"}
                              </span>

                              <span style={{ fontSize: 12, color: "var(--on-surface-variant)" }}>
                                Applied on {new Date(app.appliedAt).toLocaleDateString("en-IN", { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" })}
                              </span>
                            </div>

                            <h3 style={{ fontSize: 18, margin: "2px 0 4px", fontWeight: 800 }}>
                              {app.userName || "Volunteer"}{" "}
                              <span style={{ fontSize: 14, fontWeight: 500, color: "var(--on-surface-variant)" }}>
                                ({app.userCity || "India"} · {app.userEmail} · {app.userPhone})
                              </span>
                            </h3>
                            <div style={{ fontSize: 14, color: "var(--charcoal)" }}>
                              Applied for: <strong>{app.eventTitle}</strong> ({app.eventDate} · {app.eventLocation})
                            </div>
                          </div>
                        </div>

                        {/* Decision buttons */}
                        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                          <button
                            type="button"
                            className="btn btn-sm btn-ghost"
                            onClick={() => setExpandedAppId(isExpanded ? null : app.applicationId)}
                          >
                            {isExpanded ? "Hide Profile" : "View Full Profile"}
                          </button>

                          {!isApproved && (
                            <button
                              type="button"
                              className="btn btn-sm"
                              style={{ background: "var(--olive)", color: "#FAF8F2", border: "none" }}
                              onClick={() => handleApprove(app)}
                            >
                              <Icon name="check_circle" /> Approve Volunteer
                            </button>
                          )}

                          {!isDeclined && (
                            <button
                              type="button"
                              className="btn btn-sm btn-outline"
                              style={{ color: "#dc2626", borderColor: "#fca5a5" }}
                              onClick={() => setDecliningApp(app)}
                            >
                              <Icon name="cancel" /> Decline
                            </button>
                          )}

                          {(isApproved || isDeclined) && (
                            <button
                              type="button"
                              className="btn btn-sm btn-ghost"
                              onClick={() => {
                                resetApplication(app.applicationId);
                                refreshApps();
                                push("info", `Application reset to pending.`);
                              }}
                              title="Reset back to pending"
                            >
                              Reset
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Volunteer Profile Snapshot Grid */}
                      <div
                        style={{
                          display: "grid",
                          gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
                          gap: 10,
                          background: "var(--surface-container)",
                          padding: 12,
                          borderRadius: 8,
                          marginTop: 12,
                          fontSize: 13,
                        }}
                      >
                        <div>
                          <span style={{ color: "var(--on-surface-variant)", fontSize: 11, fontWeight: 700 }}>YEARS OF VOLUNTEERING:</span>
                          <div><strong>{app.userExperienceYears || "1+ Year"}</strong></div>
                        </div>
                        <div>
                          <span style={{ color: "var(--on-surface-variant)", fontSize: 11, fontWeight: 700 }}>PAST ORGANIZATIONS / EVENTS:</span>
                          <div><strong>{app.userPastOrganizations || "None listed"}</strong></div>
                        </div>
                        <div>
                          <span style={{ color: "var(--on-surface-variant)", fontSize: 11, fontWeight: 700 }}>KEY HIGHLIGHT:</span>
                          <div>{app.userHighlights || "Active deployment team member"}</div>
                        </div>
                      </div>

                      {/* Expandable full profile section */}
                      {isExpanded && (
                        <div
                          style={{
                            marginTop: 12,
                            padding: 14,
                            background: "var(--surface-low)",
                            border: "1px solid var(--outline)",
                            borderRadius: 8,
                            fontSize: 13,
                            display: "flex",
                            flexDirection: "column",
                            gap: 8,
                          }}
                        >
                          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                            <h4 style={{ margin: 0, fontSize: 13, textTransform: "uppercase", color: "var(--olive)" }}>
                              Full Volunteer Profile Details
                            </h4>
                            {app.userAvatarUrl && (
                              <button
                                type="button"
                                className="btn btn-outline btn-sm"
                                onClick={() =>
                                  setLightboxData({
                                    isOpen: true,
                                    photoUrl: app.userAvatarUrl!,
                                    volunteerName: app.userName || "Volunteer",
                                  })
                                }
                                style={{ fontSize: 11, padding: "2px 8px" }}
                              >
                                <Icon name="zoom_in" /> View Full Photo
                              </button>
                            )}
                          </div>
                          <div><strong>Name:</strong> {app.userName}</div>
                          <div><strong>Phone:</strong> {app.userPhone}</div>
                          <div><strong>Email:</strong> {app.userEmail}</div>
                          <div><strong>City / Region:</strong> {app.userCity} ({app.eventRegion})</div>
                          <div><strong>Experience:</strong> {app.userExperienceYears}</div>
                          <div><strong>Past Organizations:</strong> {app.userPastOrganizations}</div>
                          <div><strong>Key Highlight / Achievement:</strong> {app.userHighlights}</div>
                        </div>
                      )}

                      {/* Feedback notes if reviewed */}
                      {app.adminNotes && (
                        <div
                          style={{
                            marginTop: 10,
                            padding: "8px 12px",
                            borderRadius: 6,
                            background: isApproved ? "#EDE6D8" : "#fef2f2",
                            borderLeft: `4px solid ${isApproved ? "var(--olive)" : "#ef4444"}`,
                            fontSize: 12.5,
                            color: isApproved ? "var(--charcoal)" : "#991b1b",
                          }}
                        >
                          <strong>Admin Feedback Note:</strong> {app.adminNotes}
                          {app.reviewedAt && (
                            <span style={{ opacity: 0.8, marginLeft: 8 }}>
                              ({new Date(app.reviewedAt).toLocaleDateString()} {new Date(app.reviewedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })})
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </main>

      <SiteFooter />

      {/* Lightbox full-size photo viewer for volunteer applications */}
      <ProfilePhotoLightbox
        isOpen={lightboxData.isOpen}
        photoUrl={lightboxData.photoUrl}
        volunteerName={lightboxData.volunteerName}
        onClose={() => setLightboxData({ isOpen: false, photoUrl: "", volunteerName: "" })}
      />

      {/* ─────────────────────────────────────────────────────────────
          MODAL: CREATE OR EDIT EVENT WITH BANNER IMAGE UPLOAD
          ───────────────────────────────────────────────────────────── */}
      {(isCreateModalOpen || editingEvent) && (
        <Modal
          title={editingEvent ? `Edit Deployment: ${editingEvent.title}` : "Add New Event Deployment"}
          onClose={() => {
            setIsCreateModalOpen(false);
            setEditingEvent(null);
          }}
        >
          <form onSubmit={handleSaveEvent} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div className="field">
              <label htmlFor="ev-title">Event Title *</label>
              <input
                id="ev-title"
                required
                value={eventForm.title}
                onChange={(e) => setEventForm({ ...eventForm, title: e.target.value })}
                placeholder="e.g. Sunburn Beach Arena Goa 2027"
              />
            </div>

            <div className="form-row">
              <div className="field">
                <label htmlFor="ev-cat">Category *</label>
                <select
                  id="ev-cat"
                  value={eventForm.category}
                  onChange={(e) => setEventForm({ ...eventForm, category: e.target.value })}
                >
                  <option>Festival</option>
                  <option>Sports</option>
                  <option>Conference</option>
                  <option>Fundraiser</option>
                  <option>Cultural</option>
                  <option>Community</option>
                </select>
              </div>

              <div className="field">
                <label htmlFor="ev-reg">Indian Hub / Region *</label>
                <select
                  id="ev-reg"
                  value={eventForm.region}
                  onChange={(e) => setEventForm({ ...eventForm, region: e.target.value })}
                >
                  {REGIONS.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.name} — {r.state}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="form-row">
              <div className="field">
                <label htmlFor="ev-date">Dates / Schedule *</label>
                <input
                  id="ev-date"
                  required
                  value={eventForm.date}
                  onChange={(e) => setEventForm({ ...eventForm, date: e.target.value })}
                  placeholder="e.g. Nov 14–16, 2026"
                />
              </div>

              <div className="field">
                <label htmlFor="ev-loc">Venue &amp; Location *</label>
                <input
                  id="ev-loc"
                  required
                  value={eventForm.location}
                  onChange={(e) => setEventForm({ ...eventForm, location: e.target.value })}
                  placeholder="e.g. Vagator Beach Arena, North Goa"
                />
              </div>
            </div>

            <div className="form-row">
              <div className="field">
                <label htmlFor="ev-role">Primary Volunteer Duty *</label>
                <input
                  id="ev-role"
                  required
                  value={eventForm.role}
                  onChange={(e) => setEventForm({ ...eventForm, role: e.target.value })}
                  placeholder="e.g. Stage Rigging &amp; Safety"
                />
              </div>

              <div className="field">
                <label htmlFor="ev-size">Volunteer Capacity</label>
                <input
                  id="ev-size"
                  type="number"
                  min={2}
                  max={200}
                  value={eventForm.teamSize}
                  onChange={(e) => setEventForm({ ...eventForm, teamSize: Number(e.target.value) })}
                />
              </div>
            </div>

            <div className="form-row">
              <div className="field">
                <label htmlFor="ev-coord">Lead / Coordinator Name</label>
                <input
                  id="ev-coord"
                  value={eventForm.coordinator}
                  onChange={(e) => setEventForm({ ...eventForm, coordinator: e.target.value })}
                  placeholder="e.g. D. D'Souza"
                />
              </div>

              <div className="field">
                <label htmlFor="ev-phone">Coordinator Phone</label>
                <input
                  id="ev-phone"
                  value={eventForm.coordinatorPhone}
                  onChange={(e) => setEventForm({ ...eventForm, coordinatorPhone: e.target.value })}
                  placeholder="+91 98765 43210"
                />
              </div>
            </div>

            {/* ─── Direct Event Photo Upload ─── */}
            <div className="field">
              <label>Event Photo / Banner Image</label>
              
              {/* File upload dropzone */}
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragging(true);
                }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setIsDragging(false);
                  if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                    handleFileSelect(e.dataTransfer.files[0]);
                  }
                }}
                onClick={() => fileInputRef.current?.click()}
                style={{
                  border: `2px dashed ${isDragging ? "var(--olive)" : "var(--outline)"}`,
                  background: isDragging ? "var(--surface-container)" : "var(--surface-low)",
                  borderRadius: 10,
                  padding: "20px 16px",
                  textAlign: "center",
                  cursor: "pointer",
                  transition: "all 0.2s ease",
                  marginBottom: 10,
                }}
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/jpeg,image/png,image/webp,image/jpg"
                  style={{ display: "none" }}
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      handleFileSelect(e.target.files[0]);
                    }
                  }}
                />
                <Icon name="cloud_upload" />
                <div style={{ fontWeight: 700, fontSize: 13, marginTop: 4, color: "var(--charcoal)" }}>
                  Click to choose file or drag &amp; drop event photo
                </div>
                <div style={{ fontSize: 11, color: "var(--on-surface-variant)", marginTop: 2 }}>
                  Supports JPG, JPEG, PNG, WebP (max 5MB)
                </div>
              </div>

              {/* Preset selection option */}
              <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4, color: "var(--on-surface-variant)" }}>
                Or select from preset images:
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 8 }}>
                {PRESET_EVENT_IMAGES.map((img) => (
                  <button
                    key={img.label}
                    type="button"
                    className={`chip ${eventForm.imageUrl === img.url ? "active" : ""}`}
                    onClick={() => setEventForm({ ...eventForm, imageUrl: img.url })}
                    style={{ fontSize: 11, cursor: "pointer" }}
                  >
                    {eventForm.imageUrl === img.url ? "✓ " : ""}
                    {img.label}
                  </button>
                ))}
              </div>

              {/* Image Preview */}
              {eventForm.imageUrl && (
                <div style={{ marginTop: 8, height: 140, borderRadius: 8, overflow: "hidden", border: "1px solid var(--outline)", position: "relative" }}>
                  <img
                    src={eventForm.imageUrl}
                    alt="Preview"
                    style={{ width: "100%", height: "100%", objectFit: "cover" }}
                  />
                  <span
                    style={{
                      position: "absolute",
                      bottom: 6,
                      right: 6,
                      background: "rgba(0,0,0,0.7)",
                      color: "#fff",
                      fontSize: 10,
                      padding: "2px 6px",
                      borderRadius: 4,
                    }}
                  >
                    Current Image Preview
                  </span>
                </div>
              )}
            </div>

            <div className="field">
              <label htmlFor="ev-desc">Brief Description</label>
              <textarea
                id="ev-desc"
                rows={2}
                value={eventForm.description}
                onChange={(e) => setEventForm({ ...eventForm, description: e.target.value })}
                placeholder="Key volunteer responsibilities, perks, briefing..."
              />
            </div>

            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 8 }}>
              <button
                type="button"
                className="btn btn-outline"
                onClick={() => {
                  setIsCreateModalOpen(false);
                  setEditingEvent(null);
                }}
              >
                Cancel
              </button>
              <button type="submit" className="btn btn-accent">
                {editingEvent ? "Save Event Changes" : "Create Event Deployment"}
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* ─────────────────────────────────────────────────────────────
          MODAL: DECLINE APPLICATION WITH REASON
          ───────────────────────────────────────────────────────────── */}
      {decliningApp && (
        <Modal
          title={`Decline Application: ${decliningApp.userName}`}
          onClose={() => setDecliningApp(null)}
        >
          <form onSubmit={handleDeclineSubmit}>
            <div
              style={{
                background: "var(--surface-container)",
                padding: "10px 14px",
                borderRadius: 8,
                marginBottom: 14,
                fontSize: 13,
              }}
            >
              <div><strong>Applicant:</strong> {decliningApp.userName} ({decliningApp.userEmail})</div>
              <div><strong>Event:</strong> {decliningApp.eventTitle}</div>
            </div>

            <div className="field">
              <label htmlFor="dis-reason">Reason / Feedback Note for Volunteer</label>
              <textarea
                id="dis-reason"
                rows={3}
                required
                value={declineReason}
                onChange={(e) => setDeclineReason(e.target.value)}
                placeholder="Explain why the application cannot be accepted (e.g. volunteer quota full, scheduling conflict)..."
              />
              <small style={{ color: "var(--on-surface-variant)", display: "block", marginTop: 4 }}>
                This reason will be included in the volunteer's notification.
              </small>
            </div>

            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 14 }}>
              <button
                type="button"
                className="btn btn-outline"
                onClick={() => setDecliningApp(null)}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn"
                style={{ background: "#dc2626", color: "#FAF8F2", border: "none" }}
              >
                Confirm Decline
              </button>
            </div>
          </form>
        </Modal>
      )}

      {host}
    </>
  );
}
