import { createFileRoute } from "@tanstack/react-router";
import { SidebarLayout, Icon } from "@/components/step";
import { SOPS, RULES_AND_REGULATIONS } from "@/lib/step-data";

export const Route = createFileRoute("/guidelines")({
  head: () => ({
    meta: [
      { title: "Volunteer Guidelines & Rules — STEP LIVE" },
      {
        name: "description",
        content:
          "Official guidelines, conduct standards, rules and regulations for STEP LIVE event volunteers and participants across India.",
      },
      { property: "og:title", content: "Volunteer Guidelines & Rules — STEP LIVE" },
      {
        property: "og:description",
        content: "Official conduct guidelines, rules and regulations for STEP LIVE volunteers.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: GuidelinesPage,
});

function GuidelinesPage() {
  return (
    <SidebarLayout>
      {/* ─── SECTION 1: STEP VOLUNTEER GUIDELINES ────────────────── */}
      <div className="page-head">
        <div className="section-label">Official Conduct &amp; Protocols</div>
        <h1>STEP VOLUNTEER GUIDELINES</h1>
        <p>
          Standard Operating Procedures and conduct guidelines for every STEP volunteer deployment.
          Please read and follow these rules strictly during all assignments.
        </p>
      </div>

      <div className="sop-section">
        {SOPS.map((sop, i) => (
          <details key={sop.title} className="sop-item" open={i === 0}>
            <summary>
              <span className="num">{i + 1}</span>
              <Icon name={sop.icon} />
              {sop.title}
            </summary>
            <div className="sop-body">
              <ul>
                {sop.points.map((p) => (
                  <li key={p}>{p}</li>
                ))}
              </ul>
            </div>
          </details>
        ))}
      </div>

      {/* ─── SECTION 2: RULES AND REGULATIONS ────────────────────── */}
      <div className="page-head" style={{ marginTop: 54, paddingTop: 28, borderTop: "1px solid var(--outline)" }}>
        <div className="section-label">Legal &amp; Operational Framework</div>
        <h1>RULES AND REGULATIONS</h1>
        <p>
          Binding terms, eligibility standards, and regulatory compliance governing use of the platform and event participation.
        </p>
      </div>

      <div className="sop-section" style={{ marginBottom: 40 }}>
        {RULES_AND_REGULATIONS.map((rule, i) => (
          <details key={rule.title} className="sop-item" open={i === 0}>
            <summary>
              <span className="num">{i + 1}</span>
              <Icon name={rule.icon} />
              {rule.title}
            </summary>
            <div className="sop-body">
              {rule.points && (
                <ul>
                  {rule.points.map((p) => (
                    <li key={p}>{p}</li>
                  ))}
                </ul>
              )}
              {rule.intro && (
                <div>
                  <p style={{ margin: "0 0 8px", fontWeight: 600 }}>{rule.intro}</p>
                  {rule.subPoints && (
                    <ul style={{ listStyleType: "none", paddingLeft: 4 }}>
                      {rule.subPoints.map((sp) => (
                        <li key={sp} style={{ marginBottom: 6, lineHeight: 1.55 }}>
                          {sp}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
            </div>
          </details>
        ))}
      </div>
    </SidebarLayout>
  );
}
